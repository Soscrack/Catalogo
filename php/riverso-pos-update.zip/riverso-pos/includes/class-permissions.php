<?php
/**
 * Gestión de permisos y roles para Riverso POS/ERP
 */

if (!defined('ABSPATH')) {
    exit;
}

class Riverso_POS_Permissions {
    
    /**
     * Todas las capacidades del plugin organizadas por módulo
     */
    const CAPABILITIES = [
        // === SISTEMA ===
        'riverso_access_portal'      => 'Acceder al portal interno',
        'riverso_manage_system'      => 'Administrar sistema completo',
        'riverso_manage_settings'    => 'Gestionar configuración',
        'riverso_manage_users'       => 'Gestionar usuarios empleados',
        'riverso_view_audit'         => 'Ver auditoría',
        
        // === PRODUCTOS / CATÁLOGO ===
        'riverso_view_products'      => 'Ver productos',
        'riverso_edit_products'      => 'Editar productos',
        'riverso_edit_skus'          => 'Editar SKUs internos',
        
        // === STOCK / BODEGA ===
        'riverso_view_stock'         => 'Ver stock',
        'riverso_edit_stock'         => 'Ajustar stock',
        'riverso_view_warehouse'     => 'Ver ubicaciones bodega',
        'riverso_edit_warehouse'     => 'Editar ubicaciones bodega',
        
        // === COTIZACIONES EMITIDAS (a clientes) ===
        'riverso_view_quotes'        => 'Ver cotizaciones clientes',
        'riverso_create_quotes'      => 'Crear cotizaciones clientes',
        'riverso_approve_quotes'     => 'Aprobar cotizaciones clientes',
        
        // === VENTAS / POS ===
        'riverso_use_pos'            => 'Usar POS interno',
        'riverso_create_sales'       => 'Crear ventas',
        'riverso_view_sales'         => 'Ver ventas',
        'riverso_apply_discounts'    => 'Aplicar descuentos',
        
        // === COMPRAS / ABASTECIMIENTO ===
        'riverso_view_received_quotes'    => 'Ver cotizaciones recibidas',
        'riverso_create_received_quotes'  => 'Ingresar cotizaciones recibidas',
        'riverso_edit_received_quotes'    => 'Editar cotizaciones recibidas',
        'riverso_approve_received_quotes' => 'Aprobar cotizaciones recibidas',
        
        // === FACTURAS RECIBIDAS ===
        'riverso_view_invoices'      => 'Ver facturas recibidas',
        'riverso_create_invoices'    => 'Ingresar facturas',
        'riverso_process_invoices'   => 'Procesar facturas',
        'riverso_approve_invoices'   => 'Aprobar facturas',
        
        // === RECEPCIÓN FÍSICA ===
        'riverso_receive_items'      => 'Registrar recepción física',
        'riverso_approve_reception'  => 'Aprobar recepción',
        
        // === TAREAS ===
        'riverso_view_tasks'         => 'Ver tareas',
        'riverso_create_tasks'       => 'Crear tareas',
        'riverso_complete_tasks'     => 'Completar tareas propias',
        'riverso_assign_tasks'       => 'Asignar tareas a otros',
        'riverso_approve_tasks'      => 'Aprobar tareas',
        
        // === CÓDIGOS / PROVEEDORES ===
        'riverso_manage_codes'       => 'Gestionar códigos proveedor',
        'riverso_view_suppliers'     => 'Ver proveedores',
        'riverso_edit_suppliers'     => 'Editar proveedores',
        
        // === COSTOS ===
        'riverso_view_costs'         => 'Ver historial de costos',
        'riverso_approve_price_alerts' => 'Aprobar alertas de precio',
        
        // === CÓDIGOS DE BARRA ===
        'riverso_scan_barcodes'      => 'Escanear códigos de barra',
        'riverso_assign_barcodes'    => 'Asignar códigos de barra',
        
        // === REPORTES ===
        'riverso_view_reports'       => 'Ver reportes',
        'riverso_export_reports'     => 'Exportar reportes',
    ];
    
    /**
     * Roles del plugin con sus capacidades
     */
    const ROLES = [
        // Administrador Riverso - acceso total
        'riverso_admin' => [
            'name' => 'Administrador Riverso',
            'description' => 'Acceso total al sistema ERP',
            'capabilities' => 'ALL', // Todas las capacidades
        ],
        
        // Ventas - POS, cotizaciones, clientes
        'riverso_ventas' => [
            'name' => 'Vendedor',
            'description' => 'Ventas POS y cotizaciones a clientes',
            'capabilities' => [
                'riverso_access_portal',
                'riverso_view_products',
                'riverso_view_stock',
                'riverso_view_warehouse',
                'riverso_use_pos',
                'riverso_create_sales',
                'riverso_view_sales',
                'riverso_apply_discounts',
                'riverso_view_quotes',
                'riverso_create_quotes',
                'riverso_view_tasks',
                'riverso_complete_tasks',
                'riverso_scan_barcodes',
            ]
        ],
        
        // Bodega - operaciones físicas
        'riverso_bodega' => [
            'name' => 'Operador Bodega',
            'description' => 'Etiquetado, bodegaje, recepción física',
            'capabilities' => [
                'riverso_access_portal',
                'riverso_view_products',
                'riverso_view_stock',
                'riverso_view_warehouse',
                'riverso_edit_warehouse',
                'riverso_receive_items',
                'riverso_view_tasks',
                'riverso_complete_tasks',
                'riverso_scan_barcodes',
                'riverso_assign_barcodes',
            ]
        ],
        
        // Compras - documentos de entrada
        'riverso_compras' => [
            'name' => 'Operador Compras',
            'description' => 'Cotizaciones y facturas de proveedores',
            'capabilities' => [
                'riverso_access_portal',
                'riverso_view_products',
                'riverso_view_stock',
                'riverso_view_received_quotes',
                'riverso_create_received_quotes',
                'riverso_edit_received_quotes',
                'riverso_approve_received_quotes',
                'riverso_view_invoices',
                'riverso_create_invoices',
                'riverso_process_invoices',
                'riverso_view_suppliers',
                'riverso_edit_suppliers',
                'riverso_manage_codes',
                'riverso_view_costs',
                'riverso_view_tasks',
                'riverso_create_tasks',
                'riverso_complete_tasks',
            ]
        ],
        
        // Recepciones - validación física
        'riverso_recepciones' => [
            'name' => 'Recepcionista',
            'description' => 'Recepción y validación de mercadería',
            'capabilities' => [
                'riverso_access_portal',
                'riverso_view_products',
                'riverso_view_stock',
                'riverso_view_invoices',
                'riverso_receive_items',
                'riverso_approve_reception',
                'riverso_view_warehouse',
                'riverso_view_tasks',
                'riverso_complete_tasks',
                'riverso_scan_barcodes',
            ]
        ],
        
        // Editor - catálogo y datos maestros
        'riverso_editor' => [
            'name' => 'Editor Catálogo',
            'description' => 'Edición de productos, SKUs, códigos',
            'capabilities' => [
                'riverso_access_portal',
                'riverso_view_products',
                'riverso_edit_products',
                'riverso_edit_skus',
                'riverso_view_stock',
                'riverso_edit_stock',
                'riverso_view_warehouse',
                'riverso_edit_warehouse',
                'riverso_manage_codes',
                'riverso_view_suppliers',
                'riverso_assign_barcodes',
                'riverso_view_tasks',
                'riverso_create_tasks',
                'riverso_complete_tasks',
                'riverso_view_reports',
            ]
        ],
        
        // Cotizador - solo cotizaciones (rol legacy)
        'riverso_cotizador' => [
            'name' => 'Cotizador',
            'description' => 'Solo crear cotizaciones a clientes',
            'capabilities' => [
                'riverso_access_portal',
                'riverso_view_products',
                'riverso_view_stock',
                'riverso_view_quotes',
                'riverso_create_quotes',
            ]
        ],
    ];
    
    /**
     * Verifica si un usuario es empleado interno (tiene rol riverso_*)
     */
    public static function is_employee($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        $user = get_userdata($user_id);
        if (!$user) return false;
        
        foreach ($user->roles as $role) {
            if (strpos($role, 'riverso_') === 0 || $role === 'administrator') {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Obtiene el rol Riverso principal del usuario
     */
    public static function get_riverso_role($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        $user = get_userdata($user_id);
        if (!$user) return null;
        
        foreach ($user->roles as $role) {
            if (strpos($role, 'riverso_') === 0) {
                return $role;
            }
        }
        return $user->has_cap('administrator') ? 'administrator' : null;
    }
    
    /**
     * Verifica si el usuario actual tiene una capacidad
     */
    public static function current_user_can($capability) {
        return current_user_can($capability);
    }
    
    /**
     * Verifica múltiples capacidades (AND)
     */
    public static function current_user_can_all(array $capabilities) {
        foreach ($capabilities as $cap) {
            if (!current_user_can($cap)) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Verifica múltiples capacidades (OR)
     */
    public static function current_user_can_any(array $capabilities) {
        foreach ($capabilities as $cap) {
            if (current_user_can($cap)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Obtiene usuarios con un rol específico
     */
    public static function get_users_with_role($role) {
        return get_users(['role' => $role]);
    }
    
    /**
     * Obtiene todos los empleados (usuarios con roles riverso_*)
     */
    public static function get_all_employees() {
        $employees = [];
        foreach (array_keys(self::ROLES) as $role) {
            $users = get_users(['role' => $role]);
            $employees = array_merge($employees, $users);
        }
        // También incluir administradores
        $admins = get_users(['role' => 'administrator']);
        $employees = array_merge($employees, $admins);
        
        // Eliminar duplicados por ID
        $unique = [];
        foreach ($employees as $user) {
            $unique[$user->ID] = $user;
        }
        return array_values($unique);
    }
    
    /**
     * Obtiene usuarios que pueden completar tareas
     */
    public static function get_task_workers() {
        return self::get_all_employees();
    }
    
    /**
     * Crea o actualiza todos los roles del plugin
     */
    public static function setup_roles() {
        $base_caps = ['read' => true];
        $all_caps = array_keys(self::CAPABILITIES);
        
        foreach (self::ROLES as $role_key => $role_config) {
            // Remover rol si existe para recrearlo
            remove_role($role_key);
            
            // Determinar capacidades
            $caps = $base_caps;
            if ($role_config['capabilities'] === 'ALL') {
                foreach ($all_caps as $cap) {
                    $caps[$cap] = true;
                }
            } else {
                foreach ($role_config['capabilities'] as $cap) {
                    $caps[$cap] = true;
                }
            }
            
            // Crear rol
            add_role($role_key, $role_config['name'], $caps);
        }
        
        // Agregar todas las capacidades al administrador
        $admin = get_role('administrator');
        if ($admin) {
            foreach ($all_caps as $cap) {
                $admin->add_cap($cap);
            }
        }
    }
    
    /**
     * Elimina todos los roles del plugin
     */
    public static function remove_roles() {
        foreach (array_keys(self::ROLES) as $role) {
            remove_role($role);
        }
        
        // Remover capacidades del admin
        $admin = get_role('administrator');
        if ($admin) {
            foreach (array_keys(self::CAPABILITIES) as $cap) {
                $admin->remove_cap($cap);
            }
        }
    }
    
    /**
     * Obtiene la URL de redirección según el rol del usuario
     */
    public static function get_redirect_url($user_id = null) {
        if (self::is_employee($user_id)) {
            return home_url('/interno/');
        }
        return wc_get_page_permalink('myaccount');
    }
    
    /**
     * Obtiene los módulos accesibles según los permisos del usuario
     */
    public static function get_accessible_modules($user_id = null) {
        $modules = [];
        
        // Dashboard siempre visible para empleados
        if (current_user_can('riverso_access_portal')) {
            $modules['dashboard'] = ['icon' => 'dashboard', 'label' => 'Dashboard'];
        }
        
        // POS
        if (current_user_can('riverso_use_pos')) {
            $modules['pos'] = ['icon' => 'cart', 'label' => 'Punto de Venta'];
        }
        
        // Cotizaciones a clientes
        if (current_user_can('riverso_view_quotes')) {
            $modules['quotes'] = ['icon' => 'media-document', 'label' => 'Cotizaciones'];
        }
        
        // Tareas
        if (current_user_can('riverso_view_tasks')) {
            $modules['tasks'] = ['icon' => 'clipboard', 'label' => 'Tareas'];
        }
        
        // Bodega
        if (current_user_can('riverso_view_warehouse')) {
            $modules['warehouse'] = ['icon' => 'store', 'label' => 'Bodega'];
        }
        
        // Facturas recibidas
        if (current_user_can('riverso_view_invoices')) {
            $modules['invoices'] = ['icon' => 'media-spreadsheet', 'label' => 'Facturas'];
        }
        
        // Proveedores
        if (current_user_can('riverso_view_suppliers')) {
            $modules['suppliers'] = ['icon' => 'groups', 'label' => 'Proveedores'];
        }
        
        // Reportes
        if (current_user_can('riverso_view_reports')) {
            $modules['reports'] = ['icon' => 'chart-bar', 'label' => 'Reportes'];
        }
        
        // Configuración
        if (current_user_can('riverso_manage_settings')) {
            $modules['settings'] = ['icon' => 'admin-generic', 'label' => 'Configuración'];
        }
        
        return $modules;
    }
}
