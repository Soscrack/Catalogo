#!/bin/bash
# Cron Plesk (chroot del dominio): importación Inbox FACTO últimos 3 días, 03:00 America/Santiago
export PATH=/opt/plesk/php/8.4/bin:/usr/local/bin:/usr/bin:/bin
export TZ=America/Santiago
LOG="httpdocs/wp-content/uploads/riverso-logs/facto-inbox.log"
PHP="/opt/plesk/php/8.4/bin/php"
SCRIPT="httpdocs/wp-content/plugins/riverso-pos/cli/facto-inbox-import.php"
mkdir -p "$(dirname "$LOG")"
exec "$PHP" "$SCRIPT" --days=3 >>"$LOG" 2>&1
