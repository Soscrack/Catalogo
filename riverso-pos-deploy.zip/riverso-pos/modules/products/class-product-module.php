<?php
/**
 * Módulo de gestión del dominio canónico de productos.
 *
 * Este módulo administra `producto_base` como fuente interna de verdad. No borra
 * físicamente datos: usa `deleted_at` y `archived_at`.
 *
 * @package Riverso_POS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Riverso_Product_Module {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function create_tables() {
        return true;
    }

    public function init() {
        add_action('wp_ajax_riverso_products_list', [$this, 'ajax_list']);
        add_action('wp_ajax_riverso_products_get', [$this, 'ajax_get']);
        add_action('wp_ajax_riverso_products_save', [$this, 'ajax_save']);
        add_action('wp_ajax_riverso_products_archive', [$this, 'ajax_archive']);
        add_action('wp_ajax_riverso_products_restore', [$this, 'ajax_restore']);
        add_action('wp_ajax_riverso_products_soft_delete', [$this, 'ajax_soft_delete']);
        add_action('wp_ajax_riverso_products_approve_gate', [$this, 'ajax_approve_gate']);
        add_action('wp_ajax_riverso_products_search_code', [$this, 'ajax_search_code']);
        add_action('wp_ajax_riverso_products_link_supplier', [$this, 'ajax_link_supplier']);
        add_action('wp_ajax_riverso_products_search_woo', [$this, 'ajax_search_woo']);
        add_action('wp_ajax_riverso_products_set_online', [$this, 'ajax_set_online']);
        add_action('wp_ajax_riverso_products_get_barcodes', [$this, 'ajax_get_barcodes']);
        add_action('wp_ajax_riverso_products_add_barcode', [$this, 'ajax_add_barcode']);
        add_action('wp_ajax_riverso_products_remove_barcode', [$this, 'ajax_remove_barcode']);
        add_action('wp_ajax_riverso_products_get_tasks', [$this, 'ajax_get_tasks']);
        add_action('wp_ajax_riverso_products_create_online', [$this, 'ajax_create_online']);
        add_action('wp_ajax_riverso_products_suggest_variable_parents', [$this, 'ajax_suggest_variable_parents']);
        add_action('wp_ajax_riverso_products_get_variable_attributes', [$this, 'ajax_get_variable_attributes']);
        add_action('wp_ajax_riverso_products_get_variable_parent_details', [$this, 'ajax_get_variable_parent_details']);
        add_action('wp_ajax_riverso_products_search_catalog', [$this, 'ajax_search_catalog_products']);
    }

    private function get_completeness_category($product) {
        $has_local = !empty($product['canonical_sku']) && !empty($product['nombre_canonico']);
        $has_online = !empty($product['woocommerce_product_id']) || 
                     (!empty($product['match_estado_online']) && $product['match_estado_online'] === 'CONFIRMED');
        $has_codigo = (int) ($product['proveedores_count'] ?? 0) > 0;
        $is_published = !empty($product['publication_stage']) && 
                       in_array($product['publication_stage'], ['approved_for_publication', 'published'], true);

        if (!$has_local && $has_online) {
            return $is_published ? 'solo_online_publicado' : 'solo_online';
        }
        if ($has_local && !$has_online) {
            return 'falta_online';
        }
        if ($has_online && !$has_codigo) {
            return 'falta_codigo';
        }
        if ($has_local && $has_online && $has_codigo) {
            return $is_published ? 'publicado' : 'completo';
        }
        return 'incompleto';
    }

    public function list_products($args = []) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $status = sanitize_text_field($args['status'] ?? 'active');
        $search = sanitize_text_field($args['search'] ?? '');
        $completeness = sanitize_text_field($args['completeness'] ?? 'todos');
        $catalog_id = absint($args['catalog_id'] ?? 0);
        $offset = intval($args['offset'] ?? 0);
        $limit = min(200, max(1, intval($args['limit'] ?? 50)));

        $where = [];
        $params = [];

        if ($status === 'archived') {
            $where[] = 'pb.archived_at IS NOT NULL AND pb.deleted_at IS NULL';
        } elseif ($status === 'deleted') {
            $where[] = 'pb.deleted_at IS NOT NULL';
        } else {
            $where[] = 'pb.archived_at IS NULL AND pb.deleted_at IS NULL';
        }

        // JOIN proveedor: con catálogo forzar INNER (sin exigir activo=1:
        // en Mamut histórico muchos PP vienen con activo=0 y el filtro quedaba vacío).
        if ($catalog_id > 0) {
            $pp_join = $wpdb->prepare(
                "INNER JOIN {$prefix}producto_proveedor pp ON pp.producto_base_id = pb.id AND pp.catalogo_id = %d",
                $catalog_id
            );
        } else {
            $pp_join = "LEFT JOIN {$prefix}producto_proveedor pp ON pp.producto_base_id = pb.id AND pp.activo = 1";
        }

        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $prefix_like = $wpdb->esc_like($search) . '%';
            $sku_compact = preg_replace('/[^A-Za-z0-9]/', '', $search);
            $sku_compact_like = $sku_compact !== ''
                ? '%' . $wpdb->esc_like($sku_compact) . '%'
                : $like;

            // Prioriza SKU de catálogo (codigo_proveedor) + nombre catálogo + SKU local
            $where[] = '(
                pp.codigo_proveedor LIKE %s
                OR pp.codigo_proveedor LIKE %s
                OR REPLACE(REPLACE(REPLACE(pp.codigo_proveedor, "-", ""), " ", ""), "/", "") LIKE %s
                OR pp.nombre_proveedor LIKE %s
                OR pb.canonical_sku LIKE %s
                OR pb.nombre_canonico LIKE %s
                OR cb.codigo LIKE %s
            )';
            $params[] = $like;
            $params[] = $prefix_like;
            $params[] = $sku_compact_like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode(' AND ', $where);

        $having = '';
        if ($completeness !== '' && $completeness !== 'todos') {
            $having = $this->get_completeness_having_clause($completeness);
        }

        $order_sql = 'ORDER BY pb.updated_at DESC, pb.id DESC';
        if ($search !== '') {
            $order_sql = $wpdb->prepare(
                "ORDER BY
                    CASE
                        WHEN pp.codigo_proveedor = %s THEN 0
                        WHEN pp.codigo_proveedor LIKE %s THEN 1
                        WHEN pp.codigo_proveedor LIKE %s THEN 2
                        WHEN pp.nombre_proveedor LIKE %s THEN 3
                        ELSE 4
                    END ASC,
                    pb.updated_at DESC, pb.id DESC",
                $search,
                $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%'
            );
        }

        $sql = "SELECT pb.*,
                       COUNT(DISTINCT pp.id) AS proveedores_count,
                       COUNT(DISTINCT em.id) AS equivalencias_count,
                       GROUP_CONCAT(DISTINCT pp.codigo_proveedor SEPARATOR ', ') AS codigos_proveedor,
                       GROUP_CONCAT(DISTINCT CASE
                           WHEN pp.catalogo_id IS NOT NULL AND pp.catalogo_id > 0
                           THEN pp.codigo_proveedor
                           ELSE NULL
                       END SEPARATOR ', ') AS codigos_catalogo
                FROM {$prefix}producto_base pb
                {$pp_join}
                LEFT JOIN {$prefix}equivalence_members em ON em.producto_base_id = pb.id AND em.activo = 1
                LEFT JOIN {$prefix}codigo_barra cb ON cb.producto_base_id = pb.id
                WHERE {$where_sql}
                GROUP BY pb.id
                {$having}
                {$order_sql}
                LIMIT %d OFFSET %d";

        $query_params = $params;
        $query_params[] = $limit;
        $query_params[] = $offset;

        $results = $wpdb->get_results($wpdb->prepare($sql, $query_params), ARRAY_A);
        if (!is_array($results)) {
            $results = [];
        }

        foreach ($results as &$item) {
            $item['sku_local'] = (string) ($item['canonical_sku'] ?? '');
            $item['sku_online'] = $this->resolve_online_sku($item);
            $item['codigos_proveedor'] = (string) ($item['codigos_proveedor'] ?? '');
            $item['codigos_catalogo'] = (string) ($item['codigos_catalogo'] ?? '');
            $item['completeness_category'] = $this->get_completeness_category($item);
        }
        unset($item);

        if ($having !== '') {
            $count_sql = "SELECT COUNT(*) FROM (
                SELECT pb.id
                FROM {$prefix}producto_base pb
                {$pp_join}
                LEFT JOIN {$prefix}equivalence_members em ON em.producto_base_id = pb.id AND em.activo = 1
                LEFT JOIN {$prefix}codigo_barra cb ON cb.producto_base_id = pb.id
                WHERE {$where_sql}
                GROUP BY pb.id
                {$having}
            ) AS filtered";
        } else {
            $count_sql = "SELECT COUNT(DISTINCT pb.id) as total
                          FROM {$prefix}producto_base pb
                          {$pp_join}
                          LEFT JOIN {$prefix}equivalence_members em ON em.producto_base_id = pb.id AND em.activo = 1
                          LEFT JOIN {$prefix}codigo_barra cb ON cb.producto_base_id = pb.id
                          WHERE {$where_sql}";
        }

        $total = (int) $wpdb->get_var($wpdb->prepare($count_sql, $params));

        return [
            'items' => array_values($results),
            'total' => $total,
            'offset' => $offset,
            'limit' => $limit,
            'pages' => $limit > 0 ? (int) ceil($total / $limit) : 0,
        ];
    }

    /**
     * SKU Online (WooCommerce) a partir de product_id / variation_id locales.
     */
    private function resolve_online_sku(array $item) {
        if (!function_exists('wc_get_product')) {
            return '';
        }
        $variation_id = (int) ($item['woocommerce_variation_id'] ?? 0);
        $product_id = (int) ($item['woocommerce_product_id'] ?? 0);
        $woo_id = $variation_id > 0 ? $variation_id : $product_id;
        if ($woo_id <= 0) {
            return '';
        }
        $product = wc_get_product($woo_id);
        if (!$product) {
            return '';
        }
        return (string) ($product->get_sku() ?: '');
    }

    /**
     * Genera cláusula HAVING para filtro de completeness
     */
    private function get_completeness_having_clause($completeness) {
        switch ($completeness) {
            case 'completo':
                return "HAVING MAX(pb.canonical_sku) != '' AND MAX(pb.nombre_canonico) != '' AND MAX(pb.woocommerce_product_id) IS NOT NULL AND COUNT(DISTINCT pp.id) > 0";
            case 'publicado':
                return "HAVING MAX(pb.canonical_sku) != '' AND MAX(pb.nombre_canonico) != '' AND MAX(pb.woocommerce_product_id) IS NOT NULL AND COUNT(DISTINCT pp.id) > 0 AND MAX(pb.publication_stage) IN ('approved_for_publication', 'published')";
            case 'falta_online':
                return "HAVING MAX(pb.canonical_sku) != '' AND MAX(pb.nombre_canonico) != '' AND MAX(pb.woocommerce_product_id) IS NULL";
            case 'falta_codigo':
                return "HAVING MAX(pb.canonical_sku) != '' AND MAX(pb.nombre_canonico) != '' AND MAX(pb.woocommerce_product_id) IS NOT NULL AND COUNT(DISTINCT pp.id) = 0";
            case 'solo_online':
                return "HAVING (MAX(pb.canonical_sku) = '' OR MAX(pb.nombre_canonico) = '') AND MAX(pb.woocommerce_product_id) IS NOT NULL";
            case 'solo_online_publicado':
                return "HAVING (MAX(pb.canonical_sku) = '' OR MAX(pb.nombre_canonico) = '') AND MAX(pb.woocommerce_product_id) IS NOT NULL AND MAX(pb.publication_stage) IN ('approved_for_publication', 'published')";
            case 'incompleto':
                return "HAVING (MAX(pb.canonical_sku) = '' OR MAX(pb.nombre_canonico) = '')";
            default:
                return '';
        }
    }

    public function get_product($id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        $id = absint($id);

        $product = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$prefix}producto_base WHERE id = %d",
            $id
        ), ARRAY_A);
        if (!$product) {
            return null;
        }

        $product['proveedores'] = $wpdb->get_results($wpdb->prepare(
            "SELECT pp.*, p.nombre AS proveedor_nombre
             FROM {$prefix}producto_proveedor pp
             LEFT JOIN {$prefix}proveedores p ON p.id = pp.proveedor_id
             WHERE pp.producto_base_id = %d
             ORDER BY pp.es_preferido DESC, pp.id DESC",
            $id
        ), ARRAY_A);

        $product['barcodes'] = $this->get_product_barcodes($id);
        $product['tasks'] = $this->get_product_tasks($id);
        $product['completeness_category'] = $this->get_completeness_category($product);
        $product['proveedores_count'] = count($product['proveedores']);

        return $product;
    }

    private function get_product_barcodes($product_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        
        $barcodes = [];
        if (class_exists('Riverso_Barcode_Model')) {
            $barcodes = Riverso_Barcode_Model::get_by_product($product_id);
        }
        return is_array($barcodes) ? $barcodes : [];
    }

    private function get_product_tasks($product_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT id, tipo, titulo, estado, prioridad, fecha_limite
             FROM {$prefix}tareas
             WHERE referencia_tipo = 'producto_base' AND referencia_id = %d
             AND estado IN ('pendiente', 'asignado')
             ORDER BY prioridad DESC, id DESC
             LIMIT 10",
            $product_id
        ), ARRAY_A) ?: [];
    }

    public function save_product($data) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        $table = "{$prefix}producto_base";

        $id = absint($data['id'] ?? 0);
        $old = $id ? $this->get_product($id) : null;
        $now = current_time('mysql');

        $payload = [
            'canonical_sku' => sanitize_text_field($data['canonical_sku'] ?? ''),
            'nombre_canonico' => sanitize_text_field($data['nombre_canonico'] ?? ''),
            'unidad_base' => sanitize_text_field($data['unidad_base'] ?? 'unidad'),
            'permite_decimal' => !empty($data['permite_decimal']) ? 1 : 0,
            'permite_ean13_personalizado' => !empty($data['permite_ean13_personalizado']) ? 1 : 0,
            'stock_abierto_habilitado' => !empty($data['stock_abierto_habilitado']) ? 1 : 0,
            'codigo_abierto' => sanitize_text_field($data['codigo_abierto'] ?? ''),
            'estado' => sanitize_text_field($data['estado'] ?? 'activo'),
            'requires_human_review' => !empty($data['requires_human_review']) ? 1 : 0,
        ];

        if ($payload['canonical_sku'] === '') {
            // Permitir vacío: productos de catálogo pendientes de SKU Local
            $payload['canonical_sku'] = null;
        }
        if ($payload['nombre_canonico'] === '') {
            return new WP_Error('missing_name', 'Nombre canónico requerido');
        }
        if ($payload['codigo_abierto'] === '') {
            $payload['codigo_abierto'] = null;
        }

        if ($id) {
            $payload['updated_at'] = $now;
            $result = $wpdb->update($table, $payload, ['id' => $id]);
            $action = 'product_updated';
        } else {
            $payload['created_by_system'] = 0;
            $payload['review_status'] = 'pendiente';
            $payload['publication_stage'] = 'human_verified';
            $payload['created_at'] = $now;
            $payload['updated_at'] = $now;
            $result = $wpdb->insert($table, $payload);
            $id = (int) $wpdb->insert_id;
            $action = 'product_created';
        }

        if ($result === false) {
            return new WP_Error('db_error', $wpdb->last_error ?: 'Error guardando producto');
        }

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log($action, 'producto_base', $id, [
                'actor_type' => 'human',
                'old_value' => $old,
                'new_value' => $this->get_product($id),
            ]);
        }

        $product = $this->get_product($id);
        $this->trigger_counterpart_tasks($id);

        return $product;
    }

    public function set_lifecycle($id, $action) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        $id = absint($id);
        $old = $this->get_product($id);
        if (!$old) {
            return new WP_Error('not_found', 'Producto no encontrado');
        }

        $now = current_time('mysql');
        $payload = ['updated_at' => $now];
        $audit_action = 'product_updated';

        if ($action === 'archive') {
            $payload['archived_at'] = $now;
            $payload['estado'] = 'archivado';
            $audit_action = 'product_archived';
        } elseif ($action === 'delete') {
            $payload['deleted_at'] = $now;
            $payload['estado'] = 'eliminado';
            $audit_action = 'product_deleted';
        } elseif ($action === 'restore') {
            $payload['archived_at'] = null;
            $payload['deleted_at'] = null;
            $payload['estado'] = 'activo';
            $audit_action = 'product_restored';
        } else {
            return new WP_Error('invalid_action', 'Acción de ciclo de vida inválida');
        }

        $wpdb->update("{$prefix}producto_base", $payload, ['id' => $id]);

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log($audit_action, 'producto_base', $id, [
                'actor_type' => 'human',
                'old_value' => $old,
                'new_value' => $this->get_product($id),
            ]);
        }

        return $this->get_product($id);
    }

    public function approve_gate($id, $gate, $status = 'approved') {
        global $wpdb;
        $allowed = ['human_product_review', 'human_price_review', 'human_category_review', 'human_attribute_review'];
        $status = in_array($status, ['pending', 'approved', 'rejected'], true) ? $status : 'approved';
        if (!in_array($gate, $allowed, true)) {
            return new WP_Error('invalid_gate', 'Gate inválido');
        }

        $prefix = $wpdb->prefix . 'riverso_';
        $id = absint($id);
        $old = $this->get_product($id);
        if (!$old) {
            return new WP_Error('not_found', 'Producto no encontrado');
        }

        $wpdb->update(
            "{$prefix}producto_base",
            [$gate => $status, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%s', '%s'],
            ['%d']
        );

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log('product_updated', 'producto_base', $id, [
                'actor_type' => 'human',
                'old_value' => [$gate => $old[$gate] ?? null],
                'new_value' => [$gate => $status],
                'details' => 'Aprobación humana de gate de publicación',
            ]);
        }

        return $this->get_product($id);
    }

    public function ajax_list() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_view_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }
        $result = $this->list_products([
            'status' => sanitize_text_field($_POST['status'] ?? 'active'),
            'search' => sanitize_text_field($_POST['search'] ?? ''),
            'completeness' => sanitize_text_field($_POST['completeness'] ?? 'todos'),
            'catalog_id' => absint($_POST['catalog_id'] ?? 0),
            'offset' => intval($_POST['offset'] ?? 0),
            'limit' => intval($_POST['limit'] ?? 50),
        ]);
        wp_send_json_success($result);
    }

    public function ajax_get() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_view_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }
        $item = $this->get_product(absint($_POST['id'] ?? 0));
        if (!$item) {
            wp_send_json_error(['message' => 'Producto no encontrado']);
        }
        wp_send_json_success(['item' => $item]);
    }

    public function ajax_save() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }
        $result = $this->save_product($_POST);
        $this->send_result($result, 'Producto guardado');
    }

    public function ajax_archive() {
        $this->ajax_lifecycle('archive');
    }

    public function ajax_restore() {
        $this->ajax_lifecycle('restore');
    }

    public function ajax_soft_delete() {
        $this->ajax_lifecycle('delete');
    }

    private function ajax_lifecycle($action) {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }
        $result = $this->set_lifecycle(absint($_POST['id'] ?? 0), $action);
        $this->send_result($result, 'Estado actualizado');
    }

    public function ajax_approve_gate() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_review_products') && !current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }
        $result = $this->approve_gate(
            absint($_POST['id'] ?? 0),
            sanitize_text_field($_POST['gate'] ?? ''),
            sanitize_text_field($_POST['status'] ?? 'approved')
        );
        $this->send_result($result, 'Gate actualizado');
    }

    private function send_result($result, $message) {
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }
        wp_send_json_success(['message' => $message, 'item' => $result]);
    }

    public function ajax_search_code() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        $code = sanitize_text_field($_POST['code'] ?? '');
        if (empty($code)) {
            wp_send_json_error(['message' => 'Código requerido']);
        }

        if (!class_exists('Riverso_Supplier_Links_Module')) {
            wp_send_json_error(['message' => 'Módulo de proveedores no disponible']);
        }

        $links = Riverso_Supplier_Links_Module::get_instance()->lookup_by_code($code);
        wp_send_json_success([
            'results' => is_array($links) ? $links : (is_wp_error($links) ? [] : [$links]),
        ]);
    }

    public function ajax_link_supplier() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $supplier_code = sanitize_text_field($_POST['supplier_code'] ?? '');
        $supplier_id = absint($_POST['supplier_id'] ?? 0);
        $audit_reason = sanitize_textarea_field($_POST['audit_reason'] ?? '');

        if (!$product_id || !$supplier_code || !$supplier_id) {
            wp_send_json_error(['message' => 'Parámetros inválidos']);
        }

        if (!class_exists('Riverso_Supplier_Links_Module')) {
            wp_send_json_error(['message' => 'Módulo de proveedores no disponible']);
        }

        $result = Riverso_Supplier_Links_Module::get_instance()->create_link([
            'proveedor_id' => $supplier_id,
            'codigo_proveedor' => $supplier_code,
            'producto_base_id' => $product_id,
            'audit_reason' => $audit_reason,
        ]);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $this->close_counterpart_task($product_id, 'relacionar_producto_proveedor');
        $product = $this->get_product($product_id);
        $this->trigger_counterpart_tasks($product_id);

        wp_send_json_success(['message' => 'Código proveedor vinculado', 'item' => $product]);
    }

    public function ajax_search_woo() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        $search = sanitize_text_field($_POST['s'] ?? '');
        if (strlen($search) < 2) {
            wp_send_json_success(['results' => []]);
        }

        if (!function_exists('wc_get_products')) {
            wp_send_json_success(['results' => []]);
        }

        $products = wc_get_products([
            's' => $search,
            'limit' => 20,
            'return' => 'objects',
        ]);

        $results = [];
        foreach ($products as $wc_product) {
            $results[] = [
                'id' => $wc_product->get_id(),
                'name' => $wc_product->get_name(),
                'sku' => $wc_product->get_sku(),
                'type' => $wc_product->get_type(),
            ];
        }

        wp_send_json_success(['results' => $results]);
    }

    public function ajax_set_online() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $woo_id = absint($_POST['woo_id'] ?? 0);

        if (!$product_id || !$woo_id) {
            wp_send_json_error(['message' => 'Parámetros inválidos']);
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $result = $wpdb->update(
            "{$prefix}producto_base",
            [
                'woocommerce_product_id' => $woo_id,
                'match_estado_online' => 'CONFIRMED',
                'updated_at' => current_time('mysql'),
            ],
            ['id' => $product_id],
            ['%d', '%s', '%s'],
            ['%d']
        );

        if ($result === false) {
            wp_send_json_error(['message' => $wpdb->last_error ?: 'Error guardando vínculo Woo']);
        }

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log('product_online_linked', 'producto_base', $product_id, [
                'actor_type' => 'human',
                'woocommerce_product_id' => $woo_id,
            ]);
        }

        $this->close_counterpart_task($product_id, 'crear_contraparte_online');
        $product = $this->get_product($product_id);
        $this->trigger_counterpart_tasks($product_id);

        wp_send_json_success(['message' => 'Producto online vinculado', 'item' => $product]);
    }

    public function ajax_get_barcodes() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_view_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        if (!$product_id) {
            wp_send_json_error(['message' => 'ID de producto requerido']);
        }

        $barcodes = $this->get_product_barcodes($product_id);
        wp_send_json_success(['barcodes' => $barcodes]);
    }

    public function ajax_add_barcode() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $barcode = sanitize_text_field($_POST['barcode'] ?? '');
        $audit_reason = sanitize_textarea_field($_POST['audit_reason'] ?? '');

        if (!$product_id || !$barcode) {
            wp_send_json_error(['message' => 'Parámetros inválidos']);
        }

        if (!class_exists('Riverso_Barcode_Model')) {
            wp_send_json_error(['message' => 'Módulo de barcodes no disponible']);
        }

        $result = Riverso_Barcode_Model::create($barcode, 'ean13', $product_id, 1, 'unidad');

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log('barcode_assigned', 'codigo_barra', (int) ($result['id'] ?? 0), [
                'actor_type' => 'human',
                'producto_base_id' => $product_id,
                'codigo' => $barcode,
                'razon' => $audit_reason,
            ]);
        }

        wp_send_json_success(['message' => 'Código de barra agregado', 'barcode' => $result]);
    }

    public function ajax_remove_barcode() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $barcode_code = sanitize_text_field($_POST['barcode'] ?? '');
        $audit_reason = sanitize_textarea_field($_POST['audit_reason'] ?? '');

        if (!$product_id || !$barcode_code) {
            wp_send_json_error(['message' => 'Parámetros inválidos']);
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $barcode = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$prefix}codigo_barra WHERE codigo = %s AND producto_base_id = %d",
            $barcode_code,
            $product_id
        ));

        if (!$barcode) {
            wp_send_json_error(['message' => 'Código de barra no encontrado']);
        }

        $result = $wpdb->update(
            "{$prefix}codigo_barra",
            [
                'estado' => 'en_desuso',
                'motivo_estado' => $audit_reason ?: 'Removido por usuario',
            ],
            ['id' => (int) $barcode->id],
            ['%s', '%s'],
            ['%d']
        );

        if ($result === false) {
            wp_send_json_error(['message' => 'Error removiendo código de barra']);
        }

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log('barcode_removed', 'codigo_barra', (int) $barcode->id, [
                'actor_type' => 'human',
                'producto_base_id' => $product_id,
                'codigo' => $barcode_code,
                'razon' => $audit_reason,
            ]);
        }

        wp_send_json_success(['message' => 'Código de barra marcado como en desuso']);
    }

    public function ajax_get_tasks() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_view_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        if (!$product_id) {
            wp_send_json_error(['message' => 'ID de producto requerido']);
        }

        $tasks = $this->get_product_tasks($product_id);
        wp_send_json_success(['tasks' => $tasks]);
    }

    /**
     * Disparar tareas de contraparte cuando se crea/actualiza un producto
     */
    public function trigger_counterpart_tasks($product_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $product = $this->get_product($product_id);
        if (!$product) {
            return;
        }

        $has_local = !empty($product['canonical_sku']) && !empty($product['nombre_canonico']);
        $has_online = !empty($product['woocommerce_product_id']) || 
                     (!empty($product['match_estado_online']) && $product['match_estado_online'] === 'CONFIRMED');
        $has_codigo = (int) ($product['proveedores_count'] ?? 0) > 0;
        $match_online_unmatched = !empty($product['match_estado_online']) && $product['match_estado_online'] === 'UNMATCHED';

        if (class_exists('Riverso_Task_Module')) {
            $task_module = Riverso_Task_Module::get_instance();

            // Si es local sin online confirmada, crear tarea
            if ($has_local && !$has_online && $match_online_unmatched) {
                $task_module->create_review_task(
                    'crear_contraparte_online',
                    sprintf('Crear o asignar contraparte online para "%s"', $product['nombre_canonico']),
                    'producto_base',
                    $product_id,
                    [
                        'descripcion' => sprintf(
                            'Producto local "%s" (SKU %s) sin vínculo WooCommerce. Crear nuevo producto online o asignar uno existente.',
                            $product['nombre_canonico'],
                            $product['canonical_sku']
                        ),
                        'prioridad' => 'normal',
                    ]
                );
            }

            // Si es local+online sin código, crear tarea
            if ($has_local && $has_online && !$has_codigo) {
                $task_module->create_review_task(
                    'relacionar_producto_proveedor',
                    sprintf('Asignar código proveedor a "%s"', $product['nombre_canonico']),
                    'producto_base',
                    $product_id,
                    [
                        'descripcion' => sprintf(
                            'Producto "%s" (SKU %s) ya tiene contraparte online, pero falta código proveedor.',
                            $product['nombre_canonico'],
                            $product['canonical_sku']
                        ),
                        'prioridad' => 'normal',
                    ]
                );
            }
        }
    }

    /**
     * Cerrar/marcar tareas completadas al vincular
     */
    public function close_counterpart_task($product_id, $task_tipo) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $wpdb->update(
            "{$prefix}tareas",
            ['estado' => 'completada'],
            [
                'referencia_tipo' => 'producto_base',
                'referencia_id' => (int) $product_id,
                'tipo' => $task_tipo,
            ],
            ['%s'],
            ['%s', '%d', '%s']
        );
    }

    public function ajax_create_online() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $product_id = absint($_POST['product_id'] ?? 0);
        $product_type = sanitize_text_field($_POST['product_type'] ?? 'simple');
        $woo_name = sanitize_text_field($_POST['woo_name'] ?? '');
        $woo_sku = sanitize_text_field($_POST['woo_sku'] ?? '');

        if (!$product_id || !$woo_name || !$woo_sku) {
            wp_send_json_error(['message' => 'Datos incompletos']);
        }

        if (!class_exists('Riverso_Woo_Publisher_Module')) {
            wp_send_json_error(['message' => 'Módulo publisher no disponible']);
        }

        $publisher = Riverso_Woo_Publisher_Module::get_instance();
        
        if ($product_type === 'variable') {
            // Atributos dinámicos desde el array JSON
            $attributes = isset($_POST['attributes']) ? json_decode(stripslashes($_POST['attributes']), true) : [];
            if (!is_array($attributes)) {
                $attributes = [];
            }
            $result = $publisher->create_woo_variable_from_base($product_id, $woo_name, $woo_sku, $attributes);
        } elseif ($product_type === 'child') {
            // Asignar como hijo a un padre existente
            $parent_id = absint($_POST['parent_id'] ?? 0);
            $attach_mode = sanitize_text_field($_POST['attach_mode'] ?? 'create');
            
            if (!$parent_id) {
                wp_send_json_error(['message' => 'Padre variable no especificado']);
            }
            
            $result = $publisher->attach_base_to_variable_parent($product_id, $parent_id, $woo_sku, $attach_mode);
        } else {
            $result = $publisher->create_woo_simple_from_base($product_id, $woo_name, $woo_sku);
        }

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        // Cerrar tarea de crear contraparte
        $this->close_counterpart_task($product_id, 'crear_contraparte_online');

        // Disparar tareas de relacionar proveedor si corresponde
        $this->trigger_counterpart_tasks($product_id);

        // Obtener producto actualizado
        $updated_product = $this->get_product($product_id);

        wp_send_json_success([
            'message' => 'Producto WooCommerce creado',
            'item' => $updated_product,
            'result' => $result,
        ]);
    }

    /**
     * Resuelve el ID WooCommerce del padre variable a partir de un producto_base
     * (puede ser el padre mismo o un hijo/variación).
     *
     * @param object $pb Fila producto_base (woocommerce_product_id, woocommerce_variation_id)
     * @return int
     */
    private function resolve_variable_parent_id($pb) {
        if (!$pb) {
            return 0;
        }

        $variation_id = (int) ($pb->woocommerce_variation_id ?? 0);
        if ($variation_id > 0) {
            $variation = wc_get_product($variation_id);
            if ($variation && $variation->is_type('variation')) {
                return (int) $variation->get_parent_id();
            }
        }

        $product_id = (int) ($pb->woocommerce_product_id ?? 0);
        if ($product_id > 0) {
            $product = wc_get_product($product_id);
            if (!$product) {
                return 0;
            }
            if ($product->is_type('variable')) {
                return $product_id;
            }
            if ($product->is_type('variation')) {
                return (int) $product->get_parent_id();
            }
        }

        return 0;
    }

    /**
     * Enriquece una sugerencia de padre variable con metadatos locales.
     */
    private function build_parent_suggestion($parent_id, $match_hint = '', $source = 'local') {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $product = wc_get_product($parent_id);
        if (!$product || !$product->is_type('variable')) {
            return null;
        }

        $child_ids = array_map('intval', $product->get_children() ?: []);
        $lookup_ids = array_values(array_unique(array_filter(array_merge([$parent_id], $child_ids))));
        $in = implode(',', $lookup_ids);

        $meta = $wpdb->get_row(
            "SELECT
                MAX(CASE WHEN pb.woocommerce_product_id = {$parent_id}
                    AND (pb.woocommerce_variation_id IS NULL OR pb.woocommerce_variation_id = 0)
                    THEN pb.canonical_sku END) AS canonical_sku,
                GROUP_CONCAT(DISTINCT pp.codigo_proveedor SEPARATOR ', ') AS codigos,
                MAX(c.nombre) AS catalogo_nombre
             FROM {$prefix}producto_base pb
             LEFT JOIN {$prefix}producto_proveedor pp
                ON pp.producto_base_id = pb.id
             LEFT JOIN {$prefix}catalogos c ON c.id = pp.catalogo_id
             WHERE pb.deleted_at IS NULL
               AND (
                    pb.woocommerce_product_id = {$parent_id}
                    OR pb.woocommerce_variation_id IN ({$in})
               )"
        );

        return [
            'id' => (int) $parent_id,
            'name' => $product->get_name(),
            'sku' => $product->get_sku() ?: ($meta->canonical_sku ?? ''),
            'sku_online' => $product->get_sku() ?: '',
            'sku_local' => $meta->canonical_sku ?? '',
            'child_count' => count($child_ids),
            'catalogo' => $meta->catalogo_nombre ?? 'Sin catálogo',
            'codigo_catalogo' => $meta->codigos ?? '',
            'match_hint' => $match_hint,
            'source' => $source,
        ];
    }

    /**
     * AJAX: Sugerir padres variables (por nombre y por SKU de hijos / catálogo)
     */
    public function ajax_suggest_variable_parents() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $search = sanitize_text_field($_POST['search'] ?? '');
        $catalog_id = absint($_POST['catalog_id'] ?? 0);

        if (strlen($search) < 1) {
            wp_send_json_success(['suggestions' => []]);
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        $like = '%' . $wpdb->esc_like($search) . '%';
        $sku_compact = preg_replace('/[^A-Za-z0-9]/', '', $search);
        $sku_compact_like = $sku_compact !== ''
            ? '%' . $wpdb->esc_like($sku_compact) . '%'
            : $like;

        $suggestions_by_id = [];

        // 1) Buscar por hijos / catálogo: codigo_proveedor, nombre proveedor, SKU local, nombre
        $where = [
            'pb.deleted_at IS NULL',
            '(
                pp.codigo_proveedor LIKE %s
                OR REPLACE(REPLACE(REPLACE(pp.codigo_proveedor, "-", ""), " ", ""), "/", "") LIKE %s
                OR pp.nombre_proveedor LIKE %s
                OR pb.canonical_sku LIKE %s
                OR pb.nombre_canonico LIKE %s
            )',
        ];
        $params = [$like, $sku_compact_like, $like, $like, $like];

        if ($catalog_id > 0) {
            $where[] = 'pp.catalogo_id = %d';
            $params[] = $catalog_id;
        }

        $pp_activo_sql = ($catalog_id > 0) ? '1=1' : 'pp.activo = 1';

        $where_sql = implode(' AND ', $where);
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT pb.id, pb.nombre_canonico, pb.canonical_sku,
                        pb.woocommerce_product_id, pb.woocommerce_variation_id,
                        pp.codigo_proveedor, pp.nombre_proveedor,
                        c.nombre AS catalogo_nombre
                 FROM {$prefix}producto_base pb
                 INNER JOIN {$prefix}producto_proveedor pp
                    ON pp.producto_base_id = pb.id AND {$pp_activo_sql}
                 LEFT JOIN {$prefix}catalogos c ON c.id = pp.catalogo_id
                 WHERE {$where_sql}
                 ORDER BY
                    CASE
                        WHEN pp.codigo_proveedor = %s THEN 0
                        WHEN pp.codigo_proveedor LIKE %s THEN 1
                        ELSE 2
                    END ASC
                 LIMIT 80",
                array_merge($params, [$search, $wpdb->esc_like($search) . '%'])
            )
        );

        foreach ($rows ?: [] as $row) {
            $parent_id = $this->resolve_variable_parent_id($row);
            if ($parent_id <= 0 || isset($suggestions_by_id[$parent_id])) {
                continue;
            }

            $hint_parts = [];
            if (!empty($row->codigo_proveedor) && stripos((string) $row->codigo_proveedor, $search) !== false) {
                $hint_parts[] = 'SKU Catálogo hijo: ' . $row->codigo_proveedor;
            } elseif (!empty($row->canonical_sku) && stripos((string) $row->canonical_sku, $search) !== false) {
                $hint_parts[] = 'SKU Local hijo: ' . $row->canonical_sku;
            } elseif (!empty($row->nombre_proveedor) && stripos((string) $row->nombre_proveedor, $search) !== false) {
                $hint_parts[] = 'Nombre catálogo: ' . $row->nombre_proveedor;
            } else {
                $hint_parts[] = 'Coincide en familia';
            }

            $suggestion = $this->build_parent_suggestion($parent_id, implode(' | ', $hint_parts), 'local_child');
            if ($suggestion) {
                if ($catalog_id > 0 && empty($suggestion['codigo_catalogo']) && !empty($row->codigo_proveedor)) {
                    $suggestion['codigo_catalogo'] = $row->codigo_proveedor;
                    $suggestion['catalogo'] = $row->catalogo_nombre ?: $suggestion['catalogo'];
                }
                $suggestions_by_id[$parent_id] = $suggestion;
            }

            if (count($suggestions_by_id) >= 10) {
                break;
            }
        }

        // 2) Ampliar: padres Woo cuyo nombre/SKU coincide, con hijos en el catálogo filtrado
        if (count($suggestions_by_id) < 10) {
            $woo_product_ids = wc_get_products([
                'type' => 'variable',
                'status' => ['publish', 'draft', 'private'],
                's' => $search,
                'limit' => 20,
                'return' => 'ids',
            ]);

            foreach ($woo_product_ids as $pid) {
                if (isset($suggestions_by_id[$pid])) {
                    continue;
                }

                if ($catalog_id > 0) {
                    $product = wc_get_product($pid);
                    if (!$product) {
                        continue;
                    }
                    $ids = array_map('intval', array_merge([$pid], $product->get_children() ?: []));
                    $ids = array_filter($ids);
                    if (!$ids) {
                        continue;
                    }
                    $in = implode(',', $ids);
                    $in_catalog = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(*)
                             FROM {$prefix}producto_base pb
                             INNER JOIN {$prefix}producto_proveedor pp
                                ON pp.producto_base_id = pb.id AND pp.catalogo_id = %d
                             WHERE pb.deleted_at IS NULL
                               AND (
                                    pb.woocommerce_product_id IN ({$in})
                                    OR pb.woocommerce_variation_id IN ({$in})
                               )",
                            $catalog_id
                        )
                    );
                    if ($in_catalog < 1) {
                        continue;
                    }
                }

                $suggestion = $this->build_parent_suggestion(
                    (int) $pid,
                    $catalog_id > 0 ? 'Nombre padre + familia en catálogo' : 'Búsqueda WooCommerce',
                    'woocommerce'
                );
                if ($suggestion) {
                    $suggestions_by_id[$pid] = $suggestion;
                }
                if (count($suggestions_by_id) >= 10) {
                    break;
                }
            }
        }

        wp_send_json_success(['suggestions' => array_values($suggestions_by_id)]);
    }

    /**
     * AJAX: Obtener atributos de variación de un padre
     */
    public function ajax_get_variable_attributes() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $parent_id = absint($_POST['parent_id'] ?? 0);
        if (!$parent_id) {
            wp_send_json_error(['message' => 'ID de padre no válido']);
        }

        $product = wc_get_product($parent_id);
        if (!$product || $product->get_type() !== 'variable') {
            wp_send_json_error(['message' => 'Producto no es variable']);
        }

        $attributes = [];
        foreach ($product->get_attributes() as $attr) {
            if ($attr->get_variation()) {
                $attributes[] = [
                    'name' => $attr->get_name(),
                    'options' => $attr->get_options(),
                ];
            }
        }

        wp_send_json_success(['attributes' => $attributes]);
    }

    /**
     * AJAX: Detalle de padre variable: atributos + hijos con SKU Local/Online/Catálogo
     */
    public function ajax_get_variable_parent_details() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $parent_id = absint($_POST['parent_id'] ?? 0);
        if (!$parent_id) {
            wp_send_json_error(['message' => 'ID de padre no válido']);
        }

        $product = wc_get_product($parent_id);
        if (!$product || !$product->is_type('variable')) {
            wp_send_json_error(['message' => 'Producto no es variable']);
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $attributes = [];
        foreach ($product->get_attributes() as $attr) {
            if ($attr->get_variation()) {
                $label = $attr->get_name();
                if (strpos($label, 'pa_') === 0) {
                    $tax = $attr->get_taxonomy_object();
                    $label = $tax && !empty($tax->attribute_label) ? $tax->attribute_label : $label;
                }
                $options = $attr->get_options();
                if ($attr->is_taxonomy()) {
                    $options = array_map(function ($term_id) {
                        $term = get_term($term_id);
                        return ($term && !is_wp_error($term)) ? $term->name : (string) $term_id;
                    }, $options);
                }
                $attributes[] = [
                    'name' => $label,
                    'slug' => $attr->get_name(),
                    'options' => array_values($options),
                ];
            }
        }

        $child_ids = $product->get_children();
        $children = [];

        foreach ($child_ids as $variation_id) {
            $variation = wc_get_product($variation_id);
            if (!$variation) {
                continue;
            }

            $var_attrs = [];
            foreach ($variation->get_attributes() as $slug => $value) {
                $label = $slug;
                if (strpos($slug, 'pa_') === 0) {
                    $tax = get_taxonomy($slug);
                    $label = ($tax && !empty($tax->labels->singular_name))
                        ? $tax->labels->singular_name
                        : wc_attribute_label($slug);
                    if ($value) {
                        $term = get_term_by('slug', $value, $slug);
                        $value = ($term && !is_wp_error($term)) ? $term->name : $value;
                    }
                } else {
                    $label = wc_attribute_label($slug, $product);
                }
                $var_attrs[] = [
                    'name' => $label,
                    'slug' => $slug,
                    'value' => $value,
                ];
            }

            $pb = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id, canonical_sku, nombre_canonico, woocommerce_product_id, woocommerce_variation_id
                     FROM {$prefix}producto_base
                     WHERE deleted_at IS NULL
                       AND (
                            woocommerce_variation_id = %d
                            OR (woocommerce_product_id = %d AND (woocommerce_variation_id IS NULL OR woocommerce_variation_id = 0))
                       )
                     ORDER BY CASE WHEN woocommerce_variation_id = %d THEN 0 ELSE 1 END
                     LIMIT 1",
                    $variation_id,
                    $variation_id,
                    $variation_id
                )
            );

            // Fallback: match por SKU online = canonical_sku
            if (!$pb) {
                $woo_sku = $variation->get_sku();
                if ($woo_sku !== '') {
                    $pb = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT id, canonical_sku, nombre_canonico, woocommerce_product_id, woocommerce_variation_id
                             FROM {$prefix}producto_base
                             WHERE deleted_at IS NULL AND canonical_sku = %s
                             LIMIT 1",
                            $woo_sku
                        )
                    );
                }
            }

            $catalog_codes = [];
            $sku_local = '';
            $producto_base_id = null;
            if ($pb) {
                $producto_base_id = (int) $pb->id;
                $sku_local = (string) ($pb->canonical_sku ?? '');
                $pp_rows = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT pp.codigo_proveedor, pp.nombre_proveedor, c.nombre AS catalogo_nombre
                         FROM {$prefix}producto_proveedor pp
                         LEFT JOIN {$prefix}catalogos c ON c.id = pp.catalogo_id
                         WHERE pp.producto_base_id = %d
                         ORDER BY pp.id ASC",
                        $producto_base_id
                    )
                );
                foreach ($pp_rows ?: [] as $pp) {
                    if ($pp->codigo_proveedor === null || $pp->codigo_proveedor === '') {
                        continue;
                    }
                    $catalog_codes[] = [
                        'codigo' => $pp->codigo_proveedor,
                        'nombre' => $pp->nombre_proveedor ?: '',
                        'catalogo' => $pp->catalogo_nombre ?: '',
                    ];
                }
            }

            $sku_online = (string) ($variation->get_sku() ?: '');
            $sku_labels = [];
            if ($sku_local !== '') {
                $sku_labels[] = [
                    'type' => 'local',
                    'label' => 'SKU Local',
                    'value' => $sku_local,
                ];
            }
            if ($sku_online !== '') {
                $sku_labels[] = [
                    'type' => 'online',
                    'label' => 'SKU Online',
                    'value' => $sku_online,
                ];
            }
            foreach ($catalog_codes as $cc) {
                $sku_labels[] = [
                    'type' => 'catalogo',
                    'label' => 'SKU Catálogo',
                    'value' => $cc['codigo'],
                    'catalogo' => $cc['catalogo'],
                ];
            }
            if (empty($sku_labels)) {
                $sku_labels[] = [
                    'type' => 'otro',
                    'label' => 'Sin SKU',
                    'value' => '',
                ];
            }

            $children[] = [
                'variation_id' => (int) $variation_id,
                'name' => $variation->get_name(),
                'attributes' => $var_attrs,
                'attributes_text' => implode(' · ', array_map(function ($a) {
                    return $a['name'] . ': ' . $a['value'];
                }, $var_attrs)),
                'sku_local' => $sku_local,
                'sku_online' => $sku_online,
                'sku_catalogo' => array_map(function ($c) {
                    return $c['codigo'];
                }, $catalog_codes),
                'sku_labels' => $sku_labels,
                'has_local_sku' => $sku_local !== '',
                'producto_base_id' => $producto_base_id,
                'status' => $variation->get_status(),
            ];
        }

        // Orden: primero sin SKU local, luego con SKU local
        usort($children, function ($a, $b) {
            if ($a['has_local_sku'] === $b['has_local_sku']) {
                return strcmp($a['attributes_text'], $b['attributes_text']);
            }
            return $a['has_local_sku'] ? 1 : -1;
        });

        $with_local = count(array_filter($children, function ($c) {
            return $c['has_local_sku'];
        }));

        wp_send_json_success([
            'parent' => [
                'id' => (int) $parent_id,
                'name' => $product->get_name(),
                'sku_online' => $product->get_sku() ?: '',
                'child_count' => count($children),
                'with_local_sku' => $with_local,
                'without_local_sku' => count($children) - $with_local,
            ],
            'attributes' => $attributes,
            'children' => $children,
        ]);
    }

    /**
     * AJAX: Buscar productos dentro de un catálogo con sugerencias fuzzy.
     * Prioriza SKU de catálogo (codigo_proveedor) y nombres parecidos.
     */
    public function ajax_search_catalog_products() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_view_products')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }

        $catalog_id = absint($_POST['catalog_id'] ?? 0);
        $search = sanitize_text_field($_POST['search'] ?? '');
        $limit = min(20, max(1, absint($_POST['limit'] ?? 10)));

        if (strlen($search) < 1) {
            wp_send_json_success(['products' => []]);
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        $like = '%' . $wpdb->esc_like($search) . '%';
        $prefix_like = $wpdb->esc_like($search) . '%';
        $sku_compact = preg_replace('/[^A-Za-z0-9]/', '', $search);
        $sku_compact_like = $sku_compact !== ''
            ? '%' . $wpdb->esc_like($sku_compact) . '%'
            : $like;

        $where = [
            '(
                pp.codigo_proveedor LIKE %s
                OR pp.codigo_proveedor LIKE %s
                OR REPLACE(REPLACE(REPLACE(pp.codigo_proveedor, "-", ""), " ", ""), "/", "") LIKE %s
                OR pp.nombre_proveedor LIKE %s
                OR pb.canonical_sku LIKE %s
            )',
        ];
        $params = [$like, $prefix_like, $sku_compact_like, $like, $like];

        if ($catalog_id > 0) {
            $where[] = 'pp.catalogo_id = %d';
            $params[] = $catalog_id;
        } else {
            $where[] = 'pp.activo = 1';
        }

        $where_sql = implode(' AND ', $where);
        $fetch_limit = max($limit * 5, 40);
        $query_params = array_merge($params, [$search, $prefix_like, $sku_compact_like, $fetch_limit]);

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT pp.id, pp.codigo_proveedor, pp.nombre_proveedor,
                        pb.id as producto_base_id, pb.canonical_sku,
                        c.nombre as catalogo_nombre
                 FROM {$prefix}producto_proveedor pp
                 LEFT JOIN {$prefix}producto_base pb ON pb.id = pp.producto_base_id
                 LEFT JOIN {$prefix}catalogos c ON c.id = pp.catalogo_id
                 WHERE {$where_sql}
                 ORDER BY
                    CASE
                        WHEN pp.codigo_proveedor = %s THEN 0
                        WHEN pp.codigo_proveedor LIKE %s THEN 1
                        WHEN REPLACE(REPLACE(REPLACE(pp.codigo_proveedor, '-', ''), ' ', ''), '/', '') LIKE %s THEN 2
                        ELSE 3
                    END ASC,
                    pp.codigo_proveedor ASC
                 LIMIT %d",
                $query_params
            )
        );

        if (!is_array($results)) {
            $results = [];
        }

        if (count($results) < $limit) {
            $extra_clauses = [];
            $extra_params = [];

            $tokens = preg_split('/\s+/', $search, -1, PREG_SPLIT_NO_EMPTY);
            if (count($tokens) > 1) {
                foreach ($tokens as $token) {
                    if (strlen($token) < 2) {
                        continue;
                    }
                    $tlike = '%' . $wpdb->esc_like($token) . '%';
                    $extra_clauses[] = '(pp.codigo_proveedor LIKE %s OR pp.nombre_proveedor LIKE %s)';
                    $extra_params[] = $tlike;
                    $extra_params[] = $tlike;
                }
            }

            if (strlen($sku_compact) >= 2) {
                $short = substr($sku_compact, 0, min(4, strlen($sku_compact)));
                $extra_clauses[] = 'REPLACE(REPLACE(REPLACE(pp.codigo_proveedor, "-", ""), " ", ""), "/", "") LIKE %s';
                $extra_params[] = $wpdb->esc_like($short) . '%';
            }

            if ($extra_clauses) {
                $extra_where = ['(' . implode(' OR ', $extra_clauses) . ')'];
                if ($catalog_id > 0) {
                    $extra_where[] = 'pp.catalogo_id = %d';
                    $extra_params[] = $catalog_id;
                } else {
                    $extra_where[] = 'pp.activo = 1';
                }
                $extra_params[] = $fetch_limit;
                $extra = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT pp.id, pp.codigo_proveedor, pp.nombre_proveedor,
                                pb.id as producto_base_id, pb.canonical_sku,
                                c.nombre as catalogo_nombre
                         FROM {$prefix}producto_proveedor pp
                         LEFT JOIN {$prefix}producto_base pb ON pb.id = pp.producto_base_id
                         LEFT JOIN {$prefix}catalogos c ON c.id = pp.catalogo_id
                         WHERE " . implode(' AND ', $extra_where) . "
                         LIMIT %d",
                        $extra_params
                    )
                );
                $seen = [];
                foreach ($results as $row) {
                    $seen[(int) $row->id] = true;
                }
                foreach ((array) $extra as $row) {
                    if (empty($seen[(int) $row->id])) {
                        $results[] = $row;
                    }
                }
            }
        }

        if ($results) {
            $search_lower = strtolower($search);
            $compact_lower = strtolower($sku_compact);
            usort($results, function ($a, $b) use ($search_lower, $compact_lower) {
                $score = function ($row) use ($search_lower, $compact_lower) {
                    $code = strtolower((string) ($row->codigo_proveedor ?? ''));
                    $name = strtolower((string) ($row->nombre_proveedor ?? ''));
                    $code_compact = preg_replace('/[^a-z0-9]/', '', $code);
                    $s = 0;
                    if ($code === $search_lower) {
                        $s += 10000;
                    }
                    if ($compact_lower !== '' && $code_compact === $compact_lower) {
                        $s += 8000;
                    }
                    if (strpos($code, $search_lower) === 0) {
                        $s += 5000;
                    }
                    if ($compact_lower !== '' && strpos($code_compact, $compact_lower) === 0) {
                        $s += 4000;
                    }
                    if (strpos($code, $search_lower) !== false) {
                        $s += 2000;
                    }
                    similar_text($search_lower, $code, $pct_code);
                    similar_text($search_lower, $name, $pct_name);
                    $s += (int) ($pct_code * 100);
                    $s += (int) ($pct_name * 40);
                    if ($compact_lower !== '') {
                        similar_text($compact_lower, $code_compact, $pct_compact);
                        $s += (int) ($pct_compact * 80);
                    }
                    return $s;
                };
                return $score($b) <=> $score($a);
            });
        }

        wp_send_json_success(['products' => array_slice($results, 0, $limit)]);
    }
}
