<?php
/**
 * Módulo de Precios - Riverso POS
 *
 * Motor de precios LOCAL y ONLINE sobre el dominio canónico (producto_base /
 * producto_proveedor / lotes / equivalencias).
 *
 * PRECIO LOCAL (explorador):
 *   c_ref / p_ref / p_asignado se muestran como BRUTO comercial.
 *   neto = bruto / 1.19 (afecto; 4 decimales). Margen = P bruto / C bruto.
 *
 * Persistencia histórica y alertas internas pueden seguir usando bases mixtas;
 * el Centro de Precios → Buscar usa la convención bruto anterior.
 *
 * PRECIO ONLINE (WooCommerce):
 *   c_ref = costo_unitario del envase/lote específico (sin agrupación).
 *   p_ref = factor_objetivo * c_ref
 *
 * @package Riverso_POS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Riverso_Pricing_Module {

    private static $instance = null;

    const CANAL_LOCAL  = 'local';
    const CANAL_ONLINE = 'online';

    const FACTOR_MINIMO_DEFAULT  = 1.30;
    const FACTOR_OBJETIVO_DEFAULT = 1.80;
    const FACTOR_MAXIMO_DEFAULT  = 3.00;
    const IVA_FACTOR = 1.19;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Inicializa hooks AJAX y de recálculo automático.
     */
    public function init() {
        add_action('wp_ajax_riverso_pricing_list', [$this, 'ajax_list']);
        add_action('wp_ajax_riverso_pricing_recalc', [$this, 'ajax_recalc']);
        add_action('wp_ajax_riverso_pricing_set_assigned', [$this, 'ajax_set_assigned']);
        add_action('wp_ajax_riverso_pricing_approve', [$this, 'ajax_approve']);
        add_action('wp_ajax_riverso_pricing_alerts', [$this, 'ajax_alerts']);
        add_action('wp_ajax_riverso_pricing_sync_online', [$this, 'ajax_sync_online']);

        // Recálculo automático al aprobar factura (nuevos lotes/costos).
        add_action('riverso_pos_invoice_approved', [$this, 'on_invoice_approved'], 10, 1);
        // Recálculo cuando un proceso registra un lote.
        add_action('riverso_pos_lote_registrado', [$this, 'on_lote_registrado'], 10, 1);

        // Cargar e inicializar el submódulo de reglas de precio (misma carpeta).
        require_once __DIR__ . '/class-price-rules-module.php';
        Riverso_Price_Rules_Module::get_instance()->init();
    }

    /**
     * Crea las tablas de precios (incluye las de reglas de precio).
     */
    public static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $prefix = $wpdb->prefix . 'riverso_';

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $sql = "CREATE TABLE {$prefix}precios (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            producto_base_id BIGINT UNSIGNED NOT NULL,
            canal VARCHAR(10) NOT NULL DEFAULT 'local',
            woocommerce_variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            c_ref DECIMAL(12,4) DEFAULT NULL,
            p_ref DECIMAL(12,3) DEFAULT NULL,
            p_asignado DECIMAL(12,3) DEFAULT NULL,
            factor_minimo DECIMAL(5,2) NOT NULL DEFAULT 1.30,
            factor_objetivo DECIMAL(5,2) NOT NULL DEFAULT 1.80,
            factor_maximo_referencia DECIMAL(5,2) NOT NULL DEFAULT 3.00,
            estado_aprobacion VARCHAR(20) NOT NULL DEFAULT 'pendiente',
            alerta_margen TINYINT(1) NOT NULL DEFAULT 0,
            regla_id BIGINT UNSIGNED DEFAULT NULL,
            aprobado_por BIGINT UNSIGNED DEFAULT NULL,
            aprobado_at DATETIME DEFAULT NULL,
            created_by_system TINYINT(1) NOT NULL DEFAULT 0,
            requires_human_review TINYINT(1) NOT NULL DEFAULT 0,
            en_uso TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY ux_precio_canal (producto_base_id, canal, woocommerce_variation_id),
            KEY idx_canal (canal),
            KEY idx_alerta (alerta_margen),
            KEY idx_estado (estado_aprobacion)
        ) $charset_collate;";
        dbDelta($sql);

        self::ensure_en_uso_column();

        // Tablas del submódulo de reglas de precio.
        require_once __DIR__ . '/class-price-rules-module.php';
        Riverso_Price_Rules_Module::create_tables();
    }

    /**
     * Asegura la columna en_uso en instalaciones ya existentes.
     */
    public static function ensure_en_uso_column() {
        global $wpdb;
        $table = $wpdb->prefix . 'riverso_precios';
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'en_uso'",
            DB_NAME,
            $table
        ));
        if ((int) $exists === 0) {
            $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN en_uso TINYINT(1) NOT NULL DEFAULT 1");
        }
    }

    /**
     * Persiste un cambio de precio en precio_historial.
     *
     * @param array $data
     * @return int|false
     */
    public function record_price_change($data) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $producto_base_id = intval($data['producto_base_id'] ?? 0);
        if (!$producto_base_id) {
            return false;
        }

        $canal = ($data['canal'] ?? self::CANAL_LOCAL) === self::CANAL_ONLINE
            ? self::CANAL_ONLINE
            : self::CANAL_LOCAL;
        $c_ref = isset($data['c_ref']) && $data['c_ref'] !== null && $data['c_ref'] !== ''
            ? (float) $data['c_ref']
            : null;
        $nuevo = isset($data['p_asignado_nuevo']) && $data['p_asignado_nuevo'] !== null && $data['p_asignado_nuevo'] !== ''
            ? (float) $data['p_asignado_nuevo']
            : null;
        $margen = ($nuevo !== null && $c_ref !== null) ? round($nuevo - $c_ref, 3) : null;

        $row_data = [
            'producto_base_id' => $producto_base_id,
            'canal' => $canal,
            'woocommerce_variation_id' => intval($data['woocommerce_variation_id'] ?? 0),
            'precio_sugerido' => isset($data['precio_sugerido']) ? $data['precio_sugerido'] : null,
            'precio_aprobado' => isset($data['precio_aprobado']) ? $data['precio_aprobado'] : null,
            'precio_online' => $canal === self::CANAL_ONLINE ? $nuevo : null,
            'precio_local' => $canal === self::CANAL_LOCAL ? $nuevo : null,
            'c_ref' => $c_ref,
            'p_asignado_anterior' => isset($data['p_asignado_anterior']) && $data['p_asignado_anterior'] !== ''
                ? (float) $data['p_asignado_anterior']
                : null,
            'p_asignado_nuevo' => $nuevo,
            'margen_unitario' => $margen,
            'source_type' => sanitize_key($data['source_type'] ?? 'manual'),
            'source_document_id' => !empty($data['source_document_id']) ? intval($data['source_document_id']) : null,
            'notas' => isset($data['notas']) ? sanitize_textarea_field($data['notas']) : null,
            'usuario_id' => intval($data['usuario_id'] ?? get_current_user_id()),
        ];
        $formats = ['%d', '%s', '%d', '%f', '%f', '%f', '%f', '%f', '%f', '%f', '%f', '%s', '%d', '%s', '%d'];
        if (!empty($data['emparejamiento_id'])) {
            $row_data['emparejamiento_id'] = intval($data['emparejamiento_id']);
            $formats[] = '%d';
        }
        $ok = $wpdb->insert("{$prefix}precio_historial", $row_data, $formats);

        return $ok ? (int) $wpdb->insert_id : false;
    }

    /* ===================== Cálculo de costo de referencia ===================== */

    /**
     * Devuelve los IDs de producto_base equivalentes (incluyéndose a sí mismo)
     * que comparten algún grupo de equivalencia activo.
     *
     * @param int $producto_base_id
     * @return int[]
     */
    public function get_equivalent_base_ids($producto_base_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $producto_base_id = intval($producto_base_id);
        $ids = [$producto_base_id];

        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT em2.producto_base_id
             FROM {$prefix}equivalence_members em1
             INNER JOIN {$prefix}equivalence_groups g ON g.id = em1.grupo_id
             INNER JOIN {$prefix}equivalence_members em2 ON em2.grupo_id = em1.grupo_id
             WHERE em1.producto_base_id = %d
               AND em1.activo = 1
               AND em2.activo = 1
               AND g.activo = 1",
            $producto_base_id
        ));

        if ($rows) {
            foreach ($rows as $id) {
                $ids[] = intval($id);
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * c_ref LOCAL: MAX(costo_unitario) entre lotes de los producto_proveedor del
     * producto_base y sus equivalentes activos.
     *
     * @param int $producto_base_id
     * @return float|null
     */
    public function calculate_c_ref_local($producto_base_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $base_ids = $this->get_equivalent_base_ids($producto_base_id);
        if (empty($base_ids)) {
            return null;
        }

        $placeholders = implode(',', array_fill(0, count($base_ids), '%d'));

        $max = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(l.costo_unitario)
             FROM {$prefix}lotes l
             INNER JOIN {$prefix}producto_proveedor pp ON pp.id = l.producto_proveedor_id
             WHERE pp.producto_base_id IN ($placeholders)
               AND l.costo_unitario IS NOT NULL
               AND l.estado <> 'bloqueado'",
            ...$base_ids
        ));

        return $max !== null ? (float) $max : null;
    }

    /**
     * c_ref unitario: MAX(coste/unidades) de miembros de la familia del producto.
     *
     * @param int $producto_base_id
     * @return float|null
     */
    public function calculate_c_ref_unitario($producto_base_id) {
        if (!class_exists('Riverso_Unit_Product_Service')) {
            return null;
        }
        $svc = Riverso_Unit_Product_Service::get_instance();
        $ctx = $svc->resolve_family_unit_for_base(intval($producto_base_id));
        if (!$ctx || empty($ctx['grupo_id'])) {
            return null;
        }
        $result = $svc->calculate_coste_unitario(intval($ctx['grupo_id']));
        return $result['coste'];
    }

    /**
     * c_ref ONLINE: costo_unitario del envase/lote específico (por variación
     * WooCommerce). Toma el lote más reciente con costo para esa variación.
     *
     * @param int $producto_base_id
     * @param int $woocommerce_variation_id
     * @return float|null
     */
    public function calculate_c_ref_online($producto_base_id, $woocommerce_variation_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $woocommerce_variation_id = intval($woocommerce_variation_id);

        if ($woocommerce_variation_id > 0) {
            $cost = $wpdb->get_var($wpdb->prepare(
                "SELECT l.costo_unitario
                 FROM {$prefix}lotes l
                 WHERE l.variation_id = %d
                   AND l.costo_unitario IS NOT NULL
                   AND l.estado <> 'bloqueado'
                 ORDER BY l.fecha_recepcion DESC
                 LIMIT 1",
                $woocommerce_variation_id
            ));
            if ($cost !== null) {
                return (float) $cost;
            }
        }

        // Sin variación: último costo del producto_base por su producto_proveedor.
        $cost = $wpdb->get_var($wpdb->prepare(
            "SELECT l.costo_unitario
             FROM {$prefix}lotes l
             INNER JOIN {$prefix}producto_proveedor pp ON pp.id = l.producto_proveedor_id
             WHERE pp.producto_base_id = %d
               AND l.costo_unitario IS NOT NULL
               AND l.estado <> 'bloqueado'
             ORDER BY l.fecha_recepcion DESC
             LIMIT 1",
            intval($producto_base_id)
        ));

        return $cost !== null ? (float) $cost : null;
    }

    /**
     * @param mixed $iva_tipo
     * @return string afecto|exento
     */
    public static function normalize_iva_tipo($iva_tipo) {
        $iva_tipo = strtolower(trim((string) $iva_tipo));
        return $iva_tipo === 'exento' ? 'exento' : 'afecto';
    }

    /**
     * Precio de venta neto a partir del bruto comercial (p_asignado / TPV precio).
     *
     * @param float|int|string|null $bruto
     * @param string                $iva_tipo
     * @return float|null
     */
    public static function net_from_gross($bruto, $iva_tipo = 'afecto') {
        if ($bruto === null || $bruto === '') {
            return null;
        }
        $bruto = (float) $bruto;
        if (self::normalize_iva_tipo($iva_tipo) === 'exento') {
            return round($bruto, 4);
        }
        return round($bruto / self::IVA_FACTOR, 4);
    }

    /**
     * Bruto a partir de neto. En el explorador de precios los montos de
     * referencia (c_ref, p_ref, p_asignado) se tratan como BRUTO comercial;
     * esta helper queda para conversiones puntuales.
     *
     * @param float|int|string|null $neto
     * @param string                $iva_tipo
     * @return float|null
     */
    public static function gross_from_net($neto, $iva_tipo = 'afecto') {
        if ($neto === null || $neto === '') {
            return null;
        }
        $neto = (float) $neto;
        if (self::normalize_iva_tipo($iva_tipo) === 'exento') {
            return round($neto, 4);
        }
        return round($neto * self::IVA_FACTOR, 4);
    }

    /**
     * Etiqueta humana para source_type de precio_historial / origen inferido.
     *
     * @param string $key
     * @return string
     */
    public static function source_type_label($key) {
        $key = sanitize_key((string) $key);
        $map = [
            'manual'     => 'Manual',
            'folio'      => 'Revisión de folio',
            'recalc'     => 'Costo',
            'import'     => 'TPV',
            'legacy'     => 'Legacy',
            'costo'      => 'Costo',
            'copy_local' => 'Copia local',
            'system'     => 'Sistema',
            'tpv'        => 'TPV',
            'regla'      => 'Regla de precios',
        ];
        $label = $map[$key] ?? ($key !== '' ? $key : '—');
        return $label;
    }

    /**
     * Etiqueta de origen incluyendo marca de emparejamiento si aplica.
     *
     * @param string   $key
     * @param int|null $emparejamiento_id
     * @return string
     */
    public static function source_type_label_with_pairing($key, $emparejamiento_id = null) {
        $label = self::source_type_label($key);
        if (!empty($emparejamiento_id)) {
            $label .= ' (Emparejamiento)';
        }
        return $label;
    }

    /**
     * @param int $producto_base_id
     * @return string afecto|exento
     */
    public function get_iva_tipo_for_product($producto_base_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        $tipo = $wpdb->get_var($wpdb->prepare(
            "SELECT facto_iva_tipo FROM {$prefix}producto_base WHERE id = %d",
            intval($producto_base_id)
        ));
        return self::normalize_iva_tipo($tipo);
    }

    /**
     * Alerta si el neto de venta queda bajo factor_minimo × c_ref (ambos netos).
     *
     * @param float|null $p_asignado_bruto
     * @param float|null $c_ref_neto
     * @param float      $factor_minimo
     * @param string     $iva_tipo
     * @return int 0|1
     */
    public static function is_margin_alert($p_asignado_bruto, $c_ref_neto, $factor_minimo, $iva_tipo = 'afecto') {
        if ($p_asignado_bruto === null || $c_ref_neto === null) {
            return 0;
        }
        $neto = self::net_from_gross($p_asignado_bruto, $iva_tipo);
        if ($neto === null) {
            return 0;
        }
        return ($neto < ((float) $factor_minimo * (float) $c_ref_neto)) ? 1 : 0;
    }

    /* ===================== Recálculo y persistencia ===================== */

    /**
     * Recalcula c_ref y p_ref para un producto_base/canal y hace upsert.
     * Mantiene p_asignado si ya existe y recalcula alerta de margen.
     *
     * @param int    $producto_base_id
     * @param string $canal
     * @param int    $woocommerce_variation_id
     * @return array|WP_Error  Fila resultante
     */
    public function recalc_price($producto_base_id, $canal = self::CANAL_LOCAL, $woocommerce_variation_id = 0) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $producto_base_id = intval($producto_base_id);
        $woocommerce_variation_id = intval($woocommerce_variation_id);
        $canal = $canal === self::CANAL_ONLINE ? self::CANAL_ONLINE : self::CANAL_LOCAL;

        if (!$producto_base_id) {
            return new WP_Error('invalid', 'producto_base_id requerido');
        }

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$prefix}precios
             WHERE producto_base_id = %d AND canal = %s AND woocommerce_variation_id = %d",
            $producto_base_id,
            $canal,
            $woocommerce_variation_id
        ), ARRAY_A);

        $factor_objetivo = $existing ? (float) $existing['factor_objetivo'] : self::FACTOR_OBJETIVO_DEFAULT;
        $factor_minimo   = $existing ? (float) $existing['factor_minimo'] : self::FACTOR_MINIMO_DEFAULT;

        $c_ref = $canal === self::CANAL_ONLINE
            ? $this->calculate_c_ref_online($producto_base_id, $woocommerce_variation_id)
            : $this->calculate_c_ref_local($producto_base_id);

        $p_ref = ($c_ref !== null) ? round($c_ref * $factor_objetivo, 2) : null;

        $p_asignado = $existing ? ($existing['p_asignado'] !== null ? (float) $existing['p_asignado'] : null) : null;
        $iva_tipo = $this->get_iva_tipo_for_product($producto_base_id);
        $alerta = self::is_margin_alert($p_asignado, $c_ref, $factor_minimo, $iva_tipo);

        if ($existing) {
            $wpdb->update(
                "{$prefix}precios",
                [
                    'c_ref' => $c_ref,
                    'p_ref' => $p_ref,
                    'alerta_margen' => $alerta,
                ],
                ['id' => $existing['id']],
                ['%f', '%f', '%d'],
                ['%d']
            );
            $id = (int) $existing['id'];

            $old_c_ref = $existing['c_ref'] !== null ? (float) $existing['c_ref'] : null;
            if ($old_c_ref !== $c_ref) {
                $this->record_price_change([
                    'producto_base_id' => $producto_base_id,
                    'canal' => $canal,
                    'woocommerce_variation_id' => $woocommerce_variation_id,
                    'c_ref' => $c_ref,
                    'precio_sugerido' => $p_ref,
                    'p_asignado_anterior' => $p_asignado,
                    'p_asignado_nuevo' => $p_asignado,
                    'source_type' => 'recalc',
                ]);
            }
        } else {
            $en_uso_default = $canal === self::CANAL_ONLINE ? 0 : 1;
            $wpdb->insert(
                "{$prefix}precios",
                [
                    'producto_base_id' => $producto_base_id,
                    'canal' => $canal,
                    'woocommerce_variation_id' => $woocommerce_variation_id,
                    'c_ref' => $c_ref,
                    'p_ref' => $p_ref,
                    'p_asignado' => null,
                    'factor_minimo' => self::FACTOR_MINIMO_DEFAULT,
                    'factor_objetivo' => self::FACTOR_OBJETIVO_DEFAULT,
                    'factor_maximo_referencia' => self::FACTOR_MAXIMO_DEFAULT,
                    'estado_aprobacion' => 'pendiente',
                    'alerta_margen' => $alerta,
                    'created_by_system' => 1,
                    'requires_human_review' => 1,
                    'en_uso' => $en_uso_default,
                ],
                ['%d', '%s', '%d', '%f', '%f', '%s', '%f', '%f', '%f', '%s', '%d', '%d', '%d', '%d']
            );
            $id = (int) $wpdb->insert_id;

            if (class_exists('Riverso_POS_Audit')) {
                Riverso_POS_Audit::log_system('price_created', 'precio', $id, [
                    'new_value' => ['canal' => $canal, 'c_ref' => $c_ref, 'p_ref' => $p_ref],
                    'details' => 'Precio de referencia generado automáticamente',
                ]);
            }
        }

        // Si se levanta alerta de margen, encolar tarea de revisión.
        if ($alerta && function_exists('riverso_create_review_task')) {
            riverso_create_review_task(
                'aprobar_lista_precios',
                'Revisar margen bajo en precio del producto base #' . $producto_base_id,
                'precio',
                $id,
                [
                    'prioridad' => 'alta',
                    'descripcion' => 'El precio asignado quedó por debajo del margen mínimo permitido.',
                ]
            );
        }

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$prefix}precios WHERE id = %d", $id), ARRAY_A);
    }

    /**
     * Asigna p_asignado (precio comercial) y recalcula alerta de margen.
     *
     * @param int   $precio_id
     * @param float $p_asignado
     * @param array $meta source_type, notas, en_uso, source_document_id
     * @return array|WP_Error
     */
    public function set_assigned_price($precio_id, $p_asignado, $meta = []) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $precio_id = intval($precio_id);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$prefix}precios WHERE id = %d", $precio_id), ARRAY_A);
        if (!$row) {
            return new WP_Error('not_found', 'Precio no encontrado');
        }

        $p_asignado = (float) $p_asignado;
        $c_ref = $row['c_ref'] !== null ? (float) $row['c_ref'] : null;
        $factor_minimo = (float) $row['factor_minimo'];
        $iva_tipo = $this->get_iva_tipo_for_product((int) $row['producto_base_id']);
        $alerta = self::is_margin_alert($p_asignado, $c_ref, $factor_minimo, $iva_tipo);

        $update = [
            'p_asignado' => $p_asignado,
            'alerta_margen' => $alerta,
            'estado_aprobacion' => 'pendiente',
        ];
        $formats = ['%f', '%d', '%s'];
        if (array_key_exists('en_uso', $meta)) {
            $update['en_uso'] = intval($meta['en_uso']) ? 1 : 0;
            $formats[] = '%d';
        }

        $wpdb->update(
            "{$prefix}precios",
            $update,
            ['id' => $precio_id],
            $formats,
            ['%d']
        );

        $emp_id = !empty($meta['emparejamiento_id']) ? intval($meta['emparejamiento_id']) : null;
        if (!$emp_id && class_exists('Riverso_Emparejamiento_Module')) {
            $emp_mod = Riverso_Emparejamiento_Module::get_instance();
            if (!$emp_mod->is_syncing_prices()) {
                $emp_row = $emp_mod->get_of_product((int) $row['producto_base_id']);
                if ($emp_row && !empty($emp_row['emparejar_precios'])) {
                    $emp_id = (int) $emp_row['id'];
                }
            } elseif (!empty($meta['emparejamiento_id'])) {
                $emp_id = intval($meta['emparejamiento_id']);
            }
        }

        $this->record_price_change([
            'producto_base_id' => $row['producto_base_id'],
            'canal' => $row['canal'],
            'woocommerce_variation_id' => $row['woocommerce_variation_id'] ?? 0,
            'c_ref' => $c_ref,
            'precio_sugerido' => $row['p_ref'],
            'p_asignado_anterior' => $row['p_asignado'],
            'p_asignado_nuevo' => $p_asignado,
            'source_type' => $meta['source_type'] ?? 'manual',
            'source_document_id' => $meta['source_document_id'] ?? null,
            'notas' => $meta['notas'] ?? null,
            'emparejamiento_id' => $emp_id,
        ]);

        // Propagar a miembros emparejados (solo si no estamos ya en sync y el canal es local).
        if ($emp_id
            && ($row['canal'] ?? '') === self::CANAL_LOCAL
            && class_exists('Riverso_Emparejamiento_Module')
            && empty($meta['skip_emparejamiento_propagate'])
        ) {
            $emp_mod = Riverso_Emparejamiento_Module::get_instance();
            if (!$emp_mod->is_syncing_prices()) {
                $emp_mod->maybe_propagate_price((int) $row['producto_base_id'], $p_asignado, [
                    'source_type' => $meta['source_type'] ?? 'manual',
                    'source_document_id' => $meta['source_document_id'] ?? null,
                    'notas' => $meta['notas'] ?? null,
                    'emparejamiento_id' => $emp_id,
                ]);
            }
        }

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log('price_changed', 'precio', $precio_id, [
                'old_value' => ['p_asignado' => $row['p_asignado']],
                'new_value' => ['p_asignado' => $p_asignado],
            ]);
        }

        if ($alerta && function_exists('riverso_create_review_task')) {
            riverso_create_review_task(
                'aprobar_lista_precios',
                'Margen bajo: precio asignado bajo el mínimo (precio #' . $precio_id . ')',
                'precio',
                $precio_id,
                ['prioridad' => 'alta']
            );
        }

        // FACTO export solo encola por sync_state=pendiente_excel; TPV detecta diffs
        // por hash. Un cambio de precio local (folios, explorador, Productos) debe
        // marcar el mapa para que aparezca en «Solo pendientes».
        $canal = (string) ($row['canal'] ?? '');
        $prev = $row['p_asignado'];
        $price_changed = ($prev === null || $prev === '')
            ? true
            : abs((float) $prev - $p_asignado) > 0.000001;
        if ($canal === self::CANAL_LOCAL && $price_changed) {
            $producto_base_id = (int) ($row['producto_base_id'] ?? 0);
            if ($producto_base_id > 0 && class_exists('Riverso_Product_Module')) {
                Riverso_Product_Module::get_instance()->mark_facto_pending_export($producto_base_id);
            }
        }

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$prefix}precios WHERE id = %d", $precio_id), ARRAY_A);
    }

    /**
     * Aprueba el precio asignado manualmente.
     */
    public function approve_price($precio_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $precio_id = intval($precio_id);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$prefix}precios WHERE id = %d", $precio_id), ARRAY_A);
        if (!$row) {
            return new WP_Error('not_found', 'Precio no encontrado');
        }
        if ($row['p_asignado'] === null) {
            return new WP_Error('no_assigned', 'Debe asignar un precio antes de aprobar');
        }

        $this->mark_price_approved($row, 'Aprobación de precio');
        $this->approve_paired_on_same_folio($row);

        return true;
    }

    /**
     * Deja la fila de precio en aprobado y deja constancia en historial.
     *
     * @param array  $row  Fila de riverso_precios
     * @param string $notas
     */
    private function mark_price_approved(array $row, $notas) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        $precio_id = (int) $row['id'];
        if ($precio_id <= 0 || $row['p_asignado'] === null || $row['p_asignado'] === '') {
            return;
        }
        if (($row['estado_aprobacion'] ?? '') === 'aprobado') {
            return;
        }

        $wpdb->update(
            "{$prefix}precios",
            [
                'estado_aprobacion' => 'aprobado',
                'requires_human_review' => 0,
                'aprobado_por' => get_current_user_id(),
                'aprobado_at' => current_time('mysql'),
            ],
            ['id' => $precio_id],
            ['%s', '%d', '%d', '%s'],
            ['%d']
        );

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log('price_approved', 'precio', $precio_id, [
                'new_value' => ['p_asignado' => $row['p_asignado']],
                'details' => $notas,
            ]);
        }

        $this->record_price_change([
            'producto_base_id' => $row['producto_base_id'],
            'canal' => $row['canal'],
            'woocommerce_variation_id' => $row['woocommerce_variation_id'] ?? 0,
            'c_ref' => $row['c_ref'],
            'precio_sugerido' => $row['p_ref'],
            'precio_aprobado' => $row['p_asignado'],
            'p_asignado_anterior' => $row['p_asignado'],
            'p_asignado_nuevo' => $row['p_asignado'],
            'source_type' => 'system',
            'notas' => $notas,
        ]);
    }

    /**
     * Al aprobar un precio local, aprueba también a los emparejados de precio
     * que están en el mismo folio del que salió ese precio.
     *
     * El guardado del folio ya copia p_asignado a todos los miembros y los deja
     * en pendiente. Esta aprobación solo replica el estado, no el monto.
     *
     * @param array $row Fila de riverso_precios recién aprobada
     */
    private function approve_paired_on_same_folio(array $row) {
        if (($row['canal'] ?? '') !== self::CANAL_LOCAL) {
            return;
        }
        $producto_base_id = (int) ($row['producto_base_id'] ?? 0);
        if ($producto_base_id <= 0 || !class_exists('Riverso_Emparejamiento_Module')) {
            return;
        }

        $emp_mod = Riverso_Emparejamiento_Module::get_instance();
        $emp = $emp_mod->get_of_product($producto_base_id);
        if (!$emp || empty($emp['emparejar_precios'])) {
            return;
        }

        $factura_id = $this->latest_folio_id_for_product($producto_base_id);
        if ($factura_id <= 0) {
            return;
        }

        $on_folio = $this->product_ids_on_folio($factura_id);
        if (!$on_folio) {
            return;
        }

        $notas = 'Aprobación por emparejamiento en el mismo folio';
        foreach ($emp_mod->get_members((int) $emp['id']) as $member) {
            $pid = (int) ($member['producto_base_id'] ?? 0);
            if ($pid <= 0 || $pid === $producto_base_id || empty($on_folio[$pid])) {
                continue;
            }
            $local = $this->get_local_price($pid);
            if (!$local || $local['p_asignado'] === null || $local['p_asignado'] === '') {
                continue;
            }
            $this->mark_price_approved($local, $notas);
        }
    }

    /**
     * Último folio que escribió el precio local de este producto.
     *
     * @param int $producto_base_id
     * @return int
     */
    private function latest_folio_id_for_product($producto_base_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT source_document_id
             FROM {$prefix}precio_historial
             WHERE producto_base_id = %d
               AND canal = %s
               AND source_type = 'folio'
               AND source_document_id IS NOT NULL
               AND source_document_id > 0
             ORDER BY id DESC
             LIMIT 1",
            (int) $producto_base_id,
            self::CANAL_LOCAL
        ));
    }

    /**
     * Productos (línea y target de precio) presentes en un folio.
     *
     * @param int $factura_id
     * @return array<int, true>
     */
    private function product_ids_on_folio($factura_id) {
        if (!class_exists('Riverso_Folio_Price_Process_Service')) {
            $path = dirname(__FILE__, 3) . '/modules/pricing/class-folio-price-process-service.php';
            if (is_readable($path)) {
                require_once $path;
            }
        }
        if (!class_exists('Riverso_Folio_Price_Process_Service')) {
            return [];
        }

        return Riverso_Folio_Price_Process_Service::get_instance()->price_product_ids((int) $factura_id);
    }

    /**
     * Resuelve el producto_base_id a partir de un producto/variación WooCommerce.
     *
     * @param int $product_id
     * @param int $variation_id
     * @return int 0 si no existe
     */
    public function get_base_id_by_wc($product_id, $variation_id = 0) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $product_id = intval($product_id);
        $variation_id = intval($variation_id);

        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$prefix}producto_base
             WHERE woocommerce_product_id = %d AND woocommerce_variation_id = %d
             LIMIT 1",
            $product_id,
            $variation_id
        ));

        if (!$id && $variation_id) {
            $id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$prefix}producto_base
                 WHERE woocommerce_product_id = %d AND woocommerce_variation_id = 0
                 LIMIT 1",
                $product_id
            ));
        }

        return $id ? intval($id) : 0;
    }

    /**
     * Devuelve el precio LOCAL aprobado de un producto_base (o null).
     *
     * @param int $producto_base_id
     * @return array|null
     */
    public function get_local_price($producto_base_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$prefix}precios
             WHERE producto_base_id = %d AND canal = %s AND woocommerce_variation_id = 0",
            intval($producto_base_id),
            self::CANAL_LOCAL
        ), ARRAY_A);
    }

    /**
     * Obtener precio ONLINE aprobado de un producto_base para una variación WooCommerce.
     *
     * @param int $producto_base_id
     * @param int $woocommerce_variation_id ID de variación Woo (0 si es producto simple)
     * @return array|null
     */
    public function get_online_price($producto_base_id, $woocommerce_variation_id = 0, $only_in_use = true) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $sql = "SELECT * FROM {$prefix}precios
             WHERE producto_base_id = %d AND canal = %s AND woocommerce_variation_id = %d";
        $params = [
            intval($producto_base_id),
            self::CANAL_ONLINE,
            intval($woocommerce_variation_id),
        ];
        if ($only_in_use) {
            $sql .= ' AND COALESCE(en_uso, 1) = 1';
        }

        return $wpdb->get_row($wpdb->prepare($sql, $params), ARRAY_A);
    }

    /**
     * Fila online incluyendo precios guardados pero inactivos.
     */
    public function get_online_price_row($producto_base_id, $woocommerce_variation_id = 0) {
        return $this->get_online_price($producto_base_id, $woocommerce_variation_id, false);
    }

    /**
     * Copia p_asignado local hacia online y deja el online inactivo (en_uso=0).
     *
     * @param int $producto_base_id
     * @param int $woocommerce_variation_id
     * @return array|WP_Error
     */
    public function copy_local_to_online($producto_base_id, $woocommerce_variation_id = 0) {
        $local = $this->get_local_price($producto_base_id);
        if (!$local || $local['p_asignado'] === null) {
            return new WP_Error('no_local', 'No hay precio local asignado para copiar');
        }

        $this->recalc_price($producto_base_id, self::CANAL_ONLINE, $woocommerce_variation_id);
        $online = $this->get_online_price_row($producto_base_id, $woocommerce_variation_id);
        if (!$online) {
            return new WP_Error('no_online', 'No se pudo crear el precio online');
        }

        return $this->set_assigned_price((int) $online['id'], (float) $local['p_asignado'], [
            'en_uso' => 0,
            'source_type' => 'copy_local',
            'notas' => 'Copia de precio local a online (inactivo)',
        ]);
    }

    /**
     * Activa el precio online para uso (POS / Woo). No sincroniza Woo por sí solo.
     *
     * @param int  $producto_base_id
     * @param int  $woocommerce_variation_id
     * @param bool $sync_woo
     * @return array|WP_Error
     */
    public function set_online_active($producto_base_id, $woocommerce_variation_id = 0, $sync_woo = false) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $row = $this->get_online_price_row($producto_base_id, $woocommerce_variation_id);
        if (!$row) {
            return new WP_Error('not_found', 'No hay precio online guardado');
        }
        if ($row['p_asignado'] === null) {
            return new WP_Error('no_assigned', 'Debe asignar un precio online antes de activarlo');
        }

        $wpdb->update(
            "{$prefix}precios",
            ['en_uso' => 1],
            ['id' => intval($row['id'])],
            ['%d'],
            ['%d']
        );

        $this->record_price_change([
            'producto_base_id' => $producto_base_id,
            'canal' => self::CANAL_ONLINE,
            'woocommerce_variation_id' => $woocommerce_variation_id,
            'c_ref' => $row['c_ref'],
            'p_asignado_anterior' => $row['p_asignado'],
            'p_asignado_nuevo' => $row['p_asignado'],
            'source_type' => 'system',
            'notas' => 'Activación de precio online',
        ]);

        if ($sync_woo) {
            $sync = $this->sync_online_to_woocommerce($producto_base_id, $woocommerce_variation_id);
            if (is_wp_error($sync)) {
                return $sync;
            }
        }

        return $this->get_online_price_row($producto_base_id, $woocommerce_variation_id);
    }

    /**
     * Upsert de p_asignado por producto/canal (crea fila si no existe).
     *
     * @param int    $producto_base_id
     * @param string $canal
     * @param float  $p_asignado
     * @param int    $woocommerce_variation_id
     * @param array  $meta
     * @return array|WP_Error
     */
    public function upsert_assigned_price($producto_base_id, $canal, $p_asignado, $woocommerce_variation_id = 0, $meta = []) {
        $canal = $canal === self::CANAL_ONLINE ? self::CANAL_ONLINE : self::CANAL_LOCAL;
        $this->recalc_price($producto_base_id, $canal, $woocommerce_variation_id);
        $row = $canal === self::CANAL_ONLINE
            ? $this->get_online_price_row($producto_base_id, $woocommerce_variation_id)
            : $this->get_local_price($producto_base_id);
        if (!$row) {
            return new WP_Error('not_found', 'No se pudo crear el registro de precio');
        }
        if ($canal === self::CANAL_ONLINE && !array_key_exists('en_uso', $meta)) {
            $meta['en_uso'] = 0;
        }
        return $this->set_assigned_price((int) $row['id'], (float) $p_asignado, $meta);
    }

    /**
     * Sincroniza el precio ONLINE de un producto_base a WooCommerce vía API
     * (WC_Product::set_regular_price), nunca por SQL directo.
     *
     * Usa p_asignado online aprobado si existe; en su defecto p_ref online.
     *
     * @param int $producto_base_id
     * @param int $woocommerce_variation_id
     * @return array|WP_Error
     */
    public function sync_online_to_woocommerce($producto_base_id, $woocommerce_variation_id = 0) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $producto_base_id = intval($producto_base_id);
        $woocommerce_variation_id = intval($woocommerce_variation_id);

        if (!function_exists('wc_get_product')) {
            return new WP_Error('no_wc', 'WooCommerce no disponible');
        }

        // Asegurar precio online calculado.
        $row = $this->recalc_price($producto_base_id, self::CANAL_ONLINE, $woocommerce_variation_id);
        if (is_wp_error($row)) {
            return $row;
        }

        if (empty($row['en_uso'])) {
            return new WP_Error('online_inactive', 'El precio online está guardado pero no está en uso. Actívalo antes de sincronizar.');
        }

        $precio = null;
        if (!empty($row['p_asignado']) && $row['estado_aprobacion'] === 'aprobado') {
            $precio = (float) $row['p_asignado'];
        } elseif (!empty($row['p_ref'])) {
            $precio = (float) $row['p_ref'];
        }
        if ($precio === null) {
            return new WP_Error('no_price', 'Sin precio online calculable');
        }

        $base = $wpdb->get_row($wpdb->prepare(
            "SELECT woocommerce_product_id, woocommerce_variation_id FROM {$prefix}producto_base WHERE id = %d",
            $producto_base_id
        ), ARRAY_A);
        if (!$base) {
            return new WP_Error('not_found', 'Producto base no encontrado');
        }

        $wc_id = $woocommerce_variation_id
            ?: intval($base['woocommerce_variation_id'])
            ?: intval($base['woocommerce_product_id']);
        if (!$wc_id) {
            return new WP_Error('no_wc_product', 'Producto sin referencia WooCommerce');
        }

        $product = wc_get_product($wc_id);
        if (!$product) {
            return new WP_Error('no_wc_product', 'Producto WooCommerce no encontrado');
        }

        $old_price = $product->get_regular_price();
        $product->set_regular_price((string) $precio);
        if (!$product->get_sale_price()) {
            $product->set_price((string) $precio);
        }
        $product->save();

        if (class_exists('Riverso_POS_Audit')) {
            Riverso_POS_Audit::log('online_price_synced', 'product', $wc_id, [
                'old_value' => ['regular_price' => $old_price],
                'new_value' => ['regular_price' => $precio],
                'details' => 'Sincronización de precio online a WooCommerce',
            ]);
        }

        return ['product_id' => $wc_id, 'price' => $precio];
    }

    /* ===================== Hooks automáticos ===================== */

    /**
     * Al aprobar una factura, recalcula precios de los producto_base afectados.
     */
    public function on_invoice_approved($factura_id) {
        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $base_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT pp.producto_base_id
             FROM {$prefix}lotes l
             INNER JOIN {$prefix}producto_proveedor pp ON pp.id = l.producto_proveedor_id
             WHERE l.documento_tipo = 'factura' AND l.documento_id = %d",
            intval($factura_id)
        ));

        foreach ($base_ids as $base_id) {
            $this->recalc_price($base_id, self::CANAL_LOCAL, 0);
        }
    }

    /**
     * Al registrar un lote, recalcula el precio local de su producto_base.
     */
    public function on_lote_registrado($producto_base_id) {
        if ($producto_base_id) {
            $this->recalc_price($producto_base_id, self::CANAL_LOCAL, 0);
        }
    }

    /* ===================== AJAX ===================== */

    public function ajax_list() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_view_prices')) {
            wp_send_json_error(['message' => 'Sin permisos']);
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $canal = sanitize_text_field($_POST['canal'] ?? self::CANAL_LOCAL);
        $canal = $canal === self::CANAL_ONLINE ? self::CANAL_ONLINE : self::CANAL_LOCAL;
        $limit = min(200, max(1, intval($_POST['limit'] ?? 100)));
        $offset = max(0, intval($_POST['offset'] ?? 0));

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT pr.*, pb.canonical_sku, pb.nombre_canonico
             FROM {$prefix}precios pr
             INNER JOIN {$prefix}producto_base pb ON pb.id = pr.producto_base_id
             WHERE pr.canal = %s
             ORDER BY pr.alerta_margen DESC, pr.updated_at DESC
             LIMIT %d OFFSET %d",
            $canal,
            $limit,
            $offset
        ), ARRAY_A);

        wp_send_json_success(['items' => $rows]);
    }

    public function ajax_recalc() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_prices')) {
            wp_send_json_error(['message' => 'Sin permisos']);
        }

        $producto_base_id = intval($_POST['producto_base_id'] ?? 0);
        $canal = sanitize_text_field($_POST['canal'] ?? self::CANAL_LOCAL);
        $variation_id = intval($_POST['woocommerce_variation_id'] ?? 0);

        if (!$producto_base_id) {
            wp_send_json_error(['message' => 'producto_base_id requerido']);
        }

        $result = $this->recalc_price($producto_base_id, $canal, $variation_id);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['price' => $result]);
    }

    public function ajax_set_assigned() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_prices')) {
            wp_send_json_error(['message' => 'Sin permisos']);
        }

        $precio_id = intval($_POST['precio_id'] ?? 0);
        $p_asignado = floatval($_POST['p_asignado'] ?? 0);

        if (!$precio_id || $p_asignado <= 0) {
            wp_send_json_error(['message' => 'Datos inválidos']);
        }

        $result = $this->set_assigned_price($precio_id, $p_asignado);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['price' => $result]);
    }

    public function ajax_approve() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_approve_prices')) {
            wp_send_json_error(['message' => 'Sin permisos']);
        }

        $precio_id = intval($_POST['precio_id'] ?? 0);
        if (!$precio_id) {
            wp_send_json_error(['message' => 'precio_id requerido']);
        }

        $result = $this->approve_price($precio_id);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['message' => 'Precio aprobado']);
    }

    public function ajax_sync_online() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_manage_prices')) {
            wp_send_json_error(['message' => 'Sin permisos']);
        }
        $result = $this->sync_online_to_woocommerce(
            intval($_POST['producto_base_id'] ?? 0),
            intval($_POST['woocommerce_variation_id'] ?? 0)
        );
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }
        wp_send_json_success($result);
    }

    public function ajax_alerts() {
        check_ajax_referer('riverso_pos_nonce', 'nonce');
        if (!current_user_can('riverso_view_prices')) {
            wp_send_json_error(['message' => 'Sin permisos']);
        }

        global $wpdb;
        $prefix = $wpdb->prefix . 'riverso_';

        $rows = $wpdb->get_results(
            "SELECT pr.*, pb.canonical_sku, pb.nombre_canonico
             FROM {$prefix}precios pr
             INNER JOIN {$prefix}producto_base pb ON pb.id = pr.producto_base_id
             WHERE pr.alerta_margen = 1
             ORDER BY pr.updated_at DESC
             LIMIT 200",
            ARRAY_A
        );

        wp_send_json_success(['alerts' => $rows]);
    }
}
