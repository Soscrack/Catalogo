<?php
/**
 * Template: Gestión de Códigos de Barra
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap riverso-barcodes">
    <h1>
        <span class="dashicons dashicons-barcode"></span>
        Códigos de Barra
    </h1>

    <div class="notice notice-info">
        <p>
            El mapeo de confianza está en la pestaña <strong>Mapeo Interno</strong>
            (<code>wp_riverso_codigo_barra</code>). Las pestañas Todos / Sin Vincular / Importar
            siguen mostrando el catálogo <strong>legacy</strong>. También puedes revisar en
            <a href="<?php echo esc_url(home_url('/interno/barcodes/')); ?>">/interno/barcodes</a>.
        </p>
    </div>

    <!-- Stats -->
    <div class="barcode-stats">
        <div class="stat-card">
            <span class="stat-number" id="stat-total">-</span>
            <span class="stat-label">Total Códigos</span>
        </div>
        <div class="stat-card success">
            <span class="stat-number" id="stat-linked">-</span>
            <span class="stat-label">Vinculados</span>
        </div>
        <div class="stat-card warning">
            <span class="stat-number" id="stat-unlinked">-</span>
            <span class="stat-label">Sin Vincular</span>
        </div>
        <div class="stat-card">
            <span class="stat-number" id="stat-recent">-</span>
            <span class="stat-label">Últimos 7 días</span>
        </div>
    </div>

    <!-- Scanner Section -->
    <div class="scanner-section">
        <h3><span class="dashicons dashicons-screenoptions"></span> Escáner Rápido</h3>
        <div class="scanner-input">
            <input type="text" id="scanner-input" placeholder="Escanea o escribe código de barra..." autofocus>
            <button type="button" class="button button-primary" id="btn-search-scan">
                <span class="dashicons dashicons-search"></span> Buscar
            </button>
        </div>
        <div id="scanner-result" style="display: none;">
            <!-- Results appear here -->
        </div>
    </div>

    <!-- Tabs -->
    <div class="nav-tab-wrapper">
        <a href="#" class="nav-tab nav-tab-active" data-tab="todos">Todos los Códigos</a>
        <a href="#" class="nav-tab" data-tab="sin-vincular">Sin Vincular</a>
        <a href="#" class="nav-tab" data-tab="importar">Importar</a>
        <a href="#" class="nav-tab" data-tab="mapeo">Mapeo Interno</a>
    </div>

    <!-- Tab: Todos -->
    <div id="tab-todos" class="tab-content">
        <div class="toolbar">
            <div class="filters">
                <select id="filter-status">
                    <option value="all">Todos</option>
                    <option value="linked">Vinculados</option>
                    <option value="unlinked">Sin vincular</option>
                </select>
                <input type="text" id="search-barcode" placeholder="Buscar código o SKU...">
                <button type="button" class="button" id="btn-search">Buscar</button>
            </div>
            <button type="button" class="button button-primary" id="btn-add-barcode">
                <span class="dashicons dashicons-plus-alt"></span> Agregar Código
            </button>
        </div>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 150px;">Código de Barra</th>
                    <th style="width: 120px;">SKU</th>
                    <th>Producto</th>
                    <th style="width: 100px;">Tipo</th>
                    <th style="width: 100px;">Fuente</th>
                    <th style="width: 120px;">Fecha</th>
                    <th style="width: 100px;">Acciones</th>
                </tr>
            </thead>
            <tbody id="barcodes-list"></tbody>
        </table>
        
        <div class="pagination-wrap">
            <span id="pagination-info"></span>
            <div class="pagination-buttons">
                <button type="button" class="button" id="btn-prev" disabled>← Anterior</button>
                <button type="button" class="button" id="btn-next">Siguiente →</button>
            </div>
        </div>
    </div>

    <!-- Tab: Sin vincular -->
    <div id="tab-sin-vincular" class="tab-content" style="display: none;">
        <p class="description">
            Códigos de barra importados que no están vinculados a ningún producto. 
            Asigna un producto a cada código.
        </p>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 150px;">Código de Barra</th>
                    <th style="width: 120px;">SKU Sugerido</th>
                    <th style="width: 100px;">Tipo</th>
                    <th>Buscar Producto</th>
                    <th style="width: 100px;">Acción</th>
                </tr>
            </thead>
            <tbody id="unlinked-list"></tbody>
        </table>
    </div>

    <!-- Tab: Importar -->
    <div id="tab-importar" class="tab-content" style="display: none;">
        <div class="import-section">
            <h3>Importar desde CSV</h3>
            <p class="description">
                Sube un archivo CSV con columnas: <code>sku</code>, <code>barcode</code><br>
                Separador: punto y coma (;) o coma (,)
            </p>
            
            <div class="import-form">
                <input type="file" id="import-file" accept=".csv">
                <button type="button" class="button" id="btn-preview-import">Vista Previa</button>
            </div>
            
            <div id="import-preview" style="display: none;">
                <h4>Vista Previa (primeras 20 filas)</h4>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>SKU</th>
                            <th>Código de Barra</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody id="preview-list"></tbody>
                </table>
                <p id="preview-summary"></p>
                <button type="button" class="button button-primary button-large" id="btn-confirm-import">
                    Confirmar Importación
                </button>
            </div>
        </div>
    </div>

    <!-- Tab: Mapeo interno -->
    <div id="tab-mapeo" class="tab-content" style="display: none;">
        <div class="mapeo-subnav">
            <button type="button" class="button button-primary mapeo-subtab" data-sub="sku">Por SKU</button>
            <button type="button" class="button mapeo-subtab" data-sub="pending">Pendientes</button>
            <button type="button" class="button mapeo-subtab" data-sub="conflicts">Conflictos</button>
            <button type="button" class="button mapeo-subtab" data-sub="tipos">Tipos de envase</button>
        </div>

        <div id="mapeo-sub-sku">
            <div class="toolbar">
                <div class="filters">
                    <select id="mapeo-filter-estado">
                        <option value="">Todos los estados</option>
                        <option value="verificado">Verificado</option>
                        <option value="propuesto">Propuesto</option>
                        <option value="rechazado">Rechazado</option>
                    </select>
                    <input type="text" id="mapeo-search" placeholder="Buscar código o SKU...">
                    <button type="button" class="button" id="btn-mapeo-search">Buscar</button>
                </div>
                <button type="button" class="button button-primary" id="btn-mapeo-add">
                    <span class="dashicons dashicons-plus-alt"></span> Agregar al mapeo
                </button>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 140px;">SKU local</th>
                        <th>Producto</th>
                        <th style="width: 90px;">Códigos</th>
                        <th style="width: 90px;">Verificados</th>
                        <th style="width: 90px;">Propuestos</th>
                        <th style="width: 90px;">Conflictos</th>
                        <th style="width: 140px;">Modificado</th>
                        <th style="width: 90px;">Acciones</th>
                    </tr>
                </thead>
                <tbody id="mapeo-sku-list"></tbody>
            </table>
            <div id="mapeo-sku-detail" style="display:none;margin-top:16px;"></div>
        </div>

        <div id="mapeo-sub-pending" style="display:none;">
            <div id="mapeo-pending-list"></div>
        </div>
        <div id="mapeo-sub-conflicts" style="display:none;">
            <div id="mapeo-conflict-list"></div>
        </div>
        <div id="mapeo-sub-tipos" style="display:none;">
            <form id="form-envase-tipo" style="display:flex;gap:8px;align-items:flex-end;margin-bottom:16px;flex-wrap:wrap;">
                <div>
                    <label>Nombre</label>
                    <input type="text" id="tipo-nombre" required placeholder="Ej: Saco">
                </div>
                <div>
                    <label>Slug</label>
                    <input type="text" id="tipo-slug" placeholder="saco">
                </div>
                <button type="submit" class="button button-primary">Crear tipo</button>
            </form>
            <table class="wp-list-table widefat striped" style="max-width:640px;">
                <thead>
                    <tr>
                        <th>Slug</th>
                        <th>Nombre</th>
                        <th>Activo</th>
                        <th>Orden</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="mapeo-tipos-list"></tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal: Agregar Código -->
<div id="modal-add-barcode" class="riverso-modal" style="display: none;">
    <div class="riverso-modal-content" style="max-width: 500px;">
        <div class="riverso-modal-header">
            <h2>Agregar Código de Barra</h2>
            <button type="button" class="riverso-modal-close">&times;</button>
        </div>
        <div class="riverso-modal-body">
            <form id="form-add-barcode">
                <div class="form-field">
                    <label>Código de Barra *</label>
                    <input type="text" id="new-barcode" name="barcode" required placeholder="Ej: 7801234567890">
                    <span id="barcode-validation"></span>
                </div>
                
                <div class="form-field">
                    <label>Buscar Producto</label>
                    <input type="text" id="search-product" placeholder="Buscar por SKU o nombre...">
                    <div id="product-search-results"></div>
                </div>
                
                <div id="selected-product-info" style="display: none;">
                    <div class="selected-product">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <span id="selected-product-name"></span>
                        <code id="selected-product-sku"></code>
                        <button type="button" class="button button-small" id="btn-clear-product">×</button>
                    </div>
                </div>
                
                <input type="hidden" id="new-product-id">
                <input type="hidden" id="new-variation-id">
                
                <div class="form-field">
                    <label>Tipo de Código</label>
                    <select id="new-barcode-type" name="barcode_type">
                        <option value="EAN13">EAN-13</option>
                        <option value="EAN8">EAN-8</option>
                        <option value="UPC">UPC-A</option>
                        <option value="CODE128">Code 128</option>
                        <option value="INTERNAL">Interno</option>
                    </select>
                </div>
                
                <div class="form-field">
                    <label>
                        <input type="checkbox" id="new-is-primary" checked>
                        Código principal del producto
                    </label>
                </div>
                
                <div class="form-field">
                    <label>Notas</label>
                    <textarea id="new-notes" name="notes" rows="2"></textarea>
                </div>
            </form>
        </div>
        <div class="riverso-modal-footer">
            <button type="button" class="button" id="btn-cancel-add">Cancelar</button>
            <button type="button" class="button button-primary" id="btn-save-barcode">Guardar</button>
        </div>
    </div>
</div>

<!-- Modal: Producto encontrado por escáner -->
<div id="modal-scan-result" class="riverso-modal" style="display: none;">
    <div class="riverso-modal-content" style="max-width: 500px;">
        <div class="riverso-modal-header">
            <h2>Producto Encontrado</h2>
            <button type="button" class="riverso-modal-close">&times;</button>
        </div>
        <div class="riverso-modal-body">
            <div id="scan-product-details">
                <!-- Product details appear here -->
            </div>
        </div>
        <div class="riverso-modal-footer">
            <button type="button" class="button" id="btn-close-scan">Cerrar</button>
            <button type="button" class="button button-primary" id="btn-add-to-cart" style="display: none;">
                <span class="dashicons dashicons-cart"></span> Agregar a Venta
            </button>
        </div>
    </div>
</div>

<!-- Modal: resolver sugerencia / conflicto -->
<div id="modal-resolve-barcode" class="riverso-modal" style="display: none;">
    <div class="riverso-modal-content" style="max-width: 640px;">
        <div class="riverso-modal-header">
            <h2>Resolver mapeo</h2>
            <button type="button" class="riverso-modal-close">&times;</button>
        </div>
        <div class="riverso-modal-body">
            <p id="resolve-warning"></p>
            <div id="resolve-suggestions"></div>
        </div>
        <div class="riverso-modal-footer">
            <button type="button" class="button" id="btn-resolve-ignore">Ignorar</button>
        </div>
    </div>
</div>

<!-- Modal: agregar/editar mapeo interno -->
<div id="modal-mapeo-edit" class="riverso-modal" style="display: none;">
    <div class="riverso-modal-content" style="max-width: 520px;">
        <div class="riverso-modal-header">
            <h2 id="mapeo-edit-title">Código en mapeo interno</h2>
            <button type="button" class="riverso-modal-close">&times;</button>
        </div>
        <div class="riverso-modal-body">
            <input type="hidden" id="mapeo-edit-id">
            <div class="form-field">
                <label>Código de barra *</label>
                <input type="text" id="mapeo-edit-codigo">
            </div>
            <div class="form-field">
                <label>SKU local</label>
                <input type="text" id="mapeo-edit-sku">
            </div>
            <div class="form-field">
                <label>Producto (opcional)</label>
                <input type="text" id="mapeo-edit-product-q" placeholder="Buscar SKU o nombre...">
                <div id="mapeo-edit-product-results"></div>
                <input type="hidden" id="mapeo-edit-producto-base-id">
            </div>
            <div class="form-field">
                <label>Tipo de envase</label>
                <select id="mapeo-edit-tipo"></select>
            </div>
            <div class="form-field">
                <label>Cantidad</label>
                <input type="number" id="mapeo-edit-cantidad" value="1" min="1" step="1">
            </div>
            <div class="form-field">
                <label>Estado</label>
                <select id="mapeo-edit-estado">
                    <option value="propuesto">Propuesto</option>
                    <option value="verificado">Verificado</option>
                    <option value="en_desuso">En desuso</option>
                </select>
            </div>
            <label>
                <input type="checkbox" id="mapeo-edit-create-envase">
                Crear envase para este producto si no existe
            </label>
        </div>
        <div class="riverso-modal-footer">
            <button type="button" class="button" id="btn-mapeo-edit-cancel">Cancelar</button>
            <button type="button" class="button button-primary" id="btn-mapeo-edit-save">Guardar</button>
        </div>
    </div>
</div>

<style>
.barcode-stats {
    display: flex;
    gap: 15px;
    margin-bottom: 20px;
}

.stat-card {
    background: white;
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 15px 25px;
    text-align: center;
    min-width: 130px;
}

.stat-card.success {
    border-color: #4caf50;
    background: #e8f5e9;
}

.stat-card.warning {
    border-color: #ff9800;
    background: #fff8e1;
}

.stat-number {
    display: block;
    font-size: 28px;
    font-weight: 700;
    color: #333;
}

.stat-label {
    font-size: 12px;
    color: #666;
}

.scanner-section {
    background: #f0f7ff;
    border: 2px solid #2196f3;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
}

.scanner-section h3 {
    margin: 0 0 15px 0;
    color: #1565c0;
}

.scanner-input {
    display: flex;
    gap: 10px;
}

.scanner-input input {
    flex: 1;
    font-size: 18px;
    padding: 12px 15px;
    border: 2px solid #2196f3;
    border-radius: 6px;
}

.scanner-input input:focus {
    outline: none;
    border-color: #1565c0;
    box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.2);
}

.scanner-input button {
    padding: 12px 25px;
    font-size: 16px;
}

#scanner-result {
    margin-top: 15px;
    padding: 15px;
    background: white;
    border-radius: 6px;
}

.scan-found {
    display: flex;
    align-items: center;
    gap: 15px;
}

.scan-found img {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 4px;
    border: 1px solid #ddd;
}

.scan-found .product-info h4 {
    margin: 0 0 5px 0;
}

.scan-found .product-info .sku {
    font-family: monospace;
    background: #f5f5f5;
    padding: 2px 8px;
    border-radius: 3px;
}

.scan-found .product-info .price {
    font-size: 20px;
    font-weight: 700;
    color: #4caf50;
    margin-top: 5px;
}

.scan-not-found {
    color: #f44336;
    display: flex;
    align-items: center;
    gap: 10px;
}

.scan-not-found .dashicons {
    font-size: 24px;
}

.toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.filters {
    display: flex;
    gap: 10px;
}

.filters input {
    min-width: 200px;
}

.tab-content {
    background: white;
    border: 1px solid #ddd;
    border-top: none;
    padding: 20px;
}

.pagination-wrap {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid #eee;
}

.pagination-buttons {
    display: flex;
    gap: 10px;
}

.import-section {
    max-width: 600px;
}

.import-form {
    display: flex;
    gap: 15px;
    align-items: center;
    margin: 20px 0;
}

#import-preview {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #ddd;
}

.form-field {
    margin-bottom: 15px;
}

.form-field label {
    display: block;
    font-weight: 600;
    margin-bottom: 5px;
}

.form-field input[type="text"],
.form-field select,
.form-field textarea {
    width: 100%;
}

#product-search-results {
    border: 1px solid #ddd;
    border-radius: 4px;
    max-height: 200px;
    overflow-y: auto;
    margin-top: 5px;
    display: none;
}

#product-search-results .result-item {
    padding: 10px;
    cursor: pointer;
    border-bottom: 1px solid #eee;
}

#product-search-results .result-item:hover {
    background: #f5f5f5;
}

.selected-product {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    background: #e8f5e9;
    border-radius: 4px;
    margin-top: 10px;
}

.selected-product .dashicons {
    color: #4caf50;
}

#barcode-validation {
    font-size: 12px;
    margin-top: 3px;
    display: block;
}

#barcode-validation.valid {
    color: #4caf50;
}

#barcode-validation.invalid {
    color: #f44336;
}

.status-linked { color: #4caf50; }
.status-unlinked { color: #ff9800; }

.barcode-code {
    font-family: monospace;
    font-size: 14px;
    background: #f5f5f5;
    padding: 3px 8px;
    border-radius: 3px;
}

.quick-assign {
    display: flex;
    gap: 5px;
}

.quick-assign input {
    width: 120px;
    padding: 4px 8px;
    font-size: 12px;
}

.mapeo-subnav {
    display: flex;
    gap: 8px;
    margin-bottom: 16px;
}

.badge-estado {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 600;
}
.badge-verificado { background: #e8f5e9; color: #2e7d32; }
.badge-propuesto { background: #fff8e1; color: #ef6c00; }
.badge-rechazado { background: #ffebee; color: #c62828; }
.badge-conflicto { background: #fce4ec; color: #ad1457; }

.resolve-item {
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 10px 12px;
    margin-bottom: 8px;
    display: flex;
    justify-content: space-between;
    gap: 10px;
    align-items: center;
}

#mapeo-edit-product-results {
    border: 1px solid #ddd;
    max-height: 160px;
    overflow-y: auto;
    display: none;
}
#mapeo-edit-product-results .result-item {
    padding: 8px;
    cursor: pointer;
}
#mapeo-edit-product-results .result-item:hover { background: #f5f5f5; }
</style>

<script>
jQuery(function($) {
    const nonce = '<?php echo wp_create_nonce('riverso_pos_nonce'); ?>';
    let currentPage = 1;
    let totalPages = 1;
    let importData = [];

    // Load stats
    function loadStats() {
        $.post(ajaxurl, {action: 'riverso_get_barcode_stats', nonce: nonce}, function(response) {
            if (response.success) {
                $('#stat-total').text(response.data.total || 0);
                $('#stat-linked').text(response.data.linked || 0);
                $('#stat-unlinked').text(response.data.unlinked || 0);
                $('#stat-recent').text(response.data.recent || 0);
            }
        });
    }

    // Tabs
    $('.nav-tab').on('click', function(e) {
        e.preventDefault();
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        $('.tab-content').hide();
        $('#tab-' + $(this).data('tab')).show();
        
        if ($(this).data('tab') === 'sin-vincular') loadUnlinked();
        if ($(this).data('tab') === 'mapeo') loadMapeoSku();
    });

    // Scanner
    $('#scanner-input').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            searchBarcode($(this).val());
        }
    });

    $('#btn-search-scan').on('click', function() {
        searchBarcode($('#scanner-input').val());
    });

    function renderScanProduct(p) {
        let html = '<div class="scan-found">';
        if (p.image) {
            html += `<img src="${p.image}" alt="">`;
        }
        html += '<div class="product-info">';
        html += `<h4>${p.name || p.nombre || ''}</h4>`;
        html += `<code class="sku">${p.sku || ''}</code>`;
        const price = p.price ?? p.precio;
        if (price) {
            html += `<div class="price">$${parseFloat(price).toLocaleString('es-CL')}</div>`;
        }
        if (p.stock !== null && p.stock !== undefined) {
            html += `<div>Stock: ${p.stock}</div>`;
        }
        if (p.sku) {
            html += `<div style="margin-top:10px;">
                <button type="button" class="button button-primary btn-print-barcode-scan"
                    data-sku="${p.sku}"
                    data-nombre="${p.name || p.nombre || ''}"
                    data-precio="${price || 0}">
                    🖨️ Imprimir etiqueta
                </button>
            </div>`;
        }
        html += '</div></div>';
        return html;
    }

    function searchBarcode(barcode) {
        if (!barcode) return;
        
        const result = $('#scanner-result');
        result.show().html('<p>Buscando...</p>');

        $.post(ajaxurl, {
            action: 'riverso_search_barcode',
            nonce: nonce,
            barcode: barcode
        }).done(function(response) {
            if (response.success && response.data.product) {
                const p = response.data.product;
                if (p.trusted === false || !emptyFlag(response.data.conflicts) || (p.suggestions && p.suggestions.length)) {
                    showResolveModal(p, response.data.suggestions || p.suggestions || []);
                    result.html('<p>Este código no está verificado. Revisa el diálogo de resolución.</p>');
                    $('#scanner-input').val('').focus();
                    return;
                }
                result.html(renderScanProduct(p));
                $('#scanner-input').val('').focus();
                return;
            }

            // Fallback: buscar en tienda local (SKU / nombre)
            $.post(ajaxurl, {
                action: 'riverso_tienda_local_search',
                nonce: nonce,
                query: barcode
            }).done(function(localResp) {
                if (localResp.success && localResp.data.items && localResp.data.items.length) {
                    const p = localResp.data.items[0];
                    result.html(renderScanProduct({
                        sku: p.sku,
                        nombre: p.nombre,
                        precio: p.precio,
                        stock: p.stock,
                        name: p.nombre,
                        price: p.precio
                    }));
                } else {
                    result.html(`
                        <div class="scan-not-found">
                            <span class="dashicons dashicons-warning"></span>
                            <div>
                                <strong>Código no encontrado:</strong> ${barcode}<br>
                                <button class="button button-small" id="btn-create-barcode-task">
                                    Crear tarea para asignar producto
                                </button>
                            </div>
                        </div>
                    `);
                }
                $('#scanner-input').val('').focus();
            }).fail(function() {
                result.html('<div class="scan-not-found">Error buscando producto.</div>');
            });
        }).fail(function() {
            result.html('<div class="scan-not-found">Error buscando producto.</div>');
        });
    }

    // Create task for unassigned barcode
    $(document).on('click', '#btn-create-barcode-task', function() {
        const barcode = $('#scanner-input').val() || $(this).closest('.scan-not-found').find('strong').next().text().trim();
        // This would create a task - integrate with task module
        alert('Tarea creada para asignar código: ' + barcode);
    });

    // Imprimir desde escáner rápido
    $(document).on('click', '.btn-print-barcode-scan', function() {
        const $btn = $(this);
        if (typeof RiversoLabelPrint === 'undefined') {
            alert('⚠️ El módulo de impresión no está cargado. Recarga la página.');
            return;
        }
        RiversoLabelPrint.showPrintDialog({
            sku: $btn.data('sku'),
            nombre: $btn.data('nombre'),
            precio: parseInt($btn.data('precio')) || null,
            cantidad: 100,
            copias: 1,
            modo: 'BolsaCOD',
            color: 'BN'
        });
    });

    // Load barcodes
    function loadBarcodes() {
        $.post(ajaxurl, {
            action: 'riverso_get_barcodes',
            nonce: nonce,
            page: currentPage,
            per_page: 50,
            filter: $('#filter-status').val(),
            search: $('#search-barcode').val()
        }, function(response) {
            const tbody = $('#barcodes-list');
            tbody.empty();
            
            if (!response.success || !response.data.barcodes.length) {
                tbody.html('<tr><td colspan="7" style="text-align: center;">No hay códigos de barra</td></tr>');
                return;
            }
            
            totalPages = response.data.pages;
            $('#pagination-info').text(`Página ${currentPage} de ${totalPages} (${response.data.total} total)`);
            $('#btn-prev').prop('disabled', currentPage <= 1);
            $('#btn-next').prop('disabled', currentPage >= totalPages);
            
            response.data.barcodes.forEach(function(b) {
                tbody.append(`
                    <tr>
                        <td><code class="barcode-code">${b.barcode}</code></td>
                        <td>${b.sku || '-'}</td>
                        <td>${b.product_name || '<span class="status-unlinked">Sin vincular</span>'}</td>
                        <td>${b.barcode_type}</td>
                        <td>${b.source}</td>
                        <td>${b.created_at ? b.created_at.split(' ')[0] : '-'}</td>
                        <td>
                            <button class="button button-small btn-delete-barcode" data-id="${b.id}">
                                <span class="dashicons dashicons-trash"></span>
                            </button>
                        </td>
                    </tr>
                `);
            });
        });
    }

    $('#btn-search').on('click', function() {
        currentPage = 1;
        loadBarcodes();
    });

    $('#filter-status').on('change', function() {
        currentPage = 1;
        loadBarcodes();
    });

    $('#btn-prev').on('click', function() {
        if (currentPage > 1) {
            currentPage--;
            loadBarcodes();
        }
    });

    $('#btn-next').on('click', function() {
        if (currentPage < totalPages) {
            currentPage++;
            loadBarcodes();
        }
    });

    // Delete barcode
    $(document).on('click', '.btn-delete-barcode', function() {
        if (!confirm('¿Eliminar este código de barra?')) return;
        
        const id = $(this).data('id');
        $.post(ajaxurl, {
            action: 'riverso_delete_barcode',
            nonce: nonce,
            id: id
        }, function(response) {
            if (response.success) {
                loadBarcodes();
                loadStats();
            } else {
                alert(response.data.message);
            }
        });
    });

    // Load unlinked
    function loadUnlinked() {
        $.post(ajaxurl, {
            action: 'riverso_get_unassigned_barcodes',
            nonce: nonce,
            page: 1,
            per_page: 100
        }, function(response) {
            const tbody = $('#unlinked-list');
            tbody.empty();
            
            if (!response.success || !response.data.barcodes.length) {
                tbody.html('<tr><td colspan="5" style="text-align: center;">✓ No hay códigos sin vincular</td></tr>');
                return;
            }
            
            response.data.barcodes.forEach(function(b) {
                tbody.append(`
                    <tr data-barcode-id="${b.id}">
                        <td><code class="barcode-code">${b.barcode}</code></td>
                        <td>${b.sku || '-'}</td>
                        <td>${b.barcode_type}</td>
                        <td>
                            <div class="quick-assign">
                                <input type="text" class="quick-sku-input" placeholder="SKU del producto">
                                <button class="button button-small btn-quick-assign">Asignar</button>
                            </div>
                        </td>
                        <td>
                            <button class="button button-small btn-search-assign" data-id="${b.id}">
                                <span class="dashicons dashicons-search"></span>
                            </button>
                        </td>
                    </tr>
                `);
            });
        });
    }

    // Quick assign
    $(document).on('click', '.btn-quick-assign', function() {
        const row = $(this).closest('tr');
        const barcodeId = row.data('barcode-id');
        const sku = row.find('.quick-sku-input').val().trim();
        
        if (!sku) {
            alert('Ingresa un SKU');
            return;
        }
        
        // Search product by SKU first
        $.post(ajaxurl, {
            action: 'riverso_search_products_warehouse',
            nonce: nonce,
            search: sku
        }, function(response) {
            if (response.success && response.data.products.length > 0) {
                const p = response.data.products[0];
                assignBarcode(barcodeId, p.id, row);
            } else {
                alert('No se encontró producto con ese SKU');
            }
        });
    });

    function assignBarcode(barcodeId, productId, row) {
        $.post(ajaxurl, {
            action: 'riverso_assign_barcode',
            nonce: nonce,
            barcode_id: barcodeId,
            product_id: productId
        }, function(response) {
            if (response.success) {
                row.fadeOut(300, function() { $(this).remove(); });
                loadStats();
            } else {
                alert(response.data.message);
            }
        });
    }

    // Add barcode modal
    $('#btn-add-barcode').on('click', function() {
        $('#form-add-barcode')[0].reset();
        $('#selected-product-info').hide();
        $('#new-product-id, #new-variation-id').val('');
        $('#product-search-results').hide();
        $('#modal-add-barcode').show();
    });

    // Barcode validation
    $('#new-barcode').on('input', function() {
        const barcode = $(this).val().trim();
        const validation = $('#barcode-validation');
        
        if (barcode.length < 4) {
            validation.text('').removeClass('valid invalid');
            return;
        }
        
        // Simple validation
        if (barcode.length === 13 && /^\d+$/.test(barcode)) {
            validation.text('✓ EAN-13 válido').addClass('valid').removeClass('invalid');
            $('#new-barcode-type').val('EAN13');
        } else if (barcode.length === 8 && /^\d+$/.test(barcode)) {
            validation.text('✓ EAN-8 válido').addClass('valid').removeClass('invalid');
            $('#new-barcode-type').val('EAN8');
        } else if (barcode.length === 12 && /^\d+$/.test(barcode)) {
            validation.text('✓ UPC-A válido').addClass('valid').removeClass('invalid');
            $('#new-barcode-type').val('UPC');
        } else {
            validation.text('Código interno').addClass('valid').removeClass('invalid');
            $('#new-barcode-type').val('INTERNAL');
        }
    });

    // Product search in modal
    $('#search-product').on('keyup', debounce(function() {
        const search = $(this).val();
        if (search.length < 2) {
            $('#product-search-results').hide();
            return;
        }
        
        $.post(ajaxurl, {
            action: 'riverso_search_products_warehouse',
            nonce: nonce,
            search: search
        }, function(response) {
            if (response.success) {
                const results = $('#product-search-results');
                results.empty();
                
                if (!response.data.products.length) {
                    results.html('<div style="padding: 10px;">No se encontraron productos</div>');
                } else {
                    response.data.products.forEach(function(p) {
                        results.append(`
                            <div class="result-item" data-id="${p.id}" data-name="${p.name}" data-sku="${p.sku}">
                                <strong>${p.name}</strong><br>
                                <code>${p.sku}</code>
                            </div>
                        `);
                    });
                }
                results.show();
            }
        });
    }, 300));

    $(document).on('click', '#product-search-results .result-item', function() {
        $('#new-product-id').val($(this).data('id'));
        $('#selected-product-name').text($(this).data('name'));
        $('#selected-product-sku').text($(this).data('sku'));
        $('#selected-product-info').show();
        $('#product-search-results').hide();
        $('#search-product').val('');
    });

    $('#btn-clear-product').on('click', function() {
        $('#new-product-id, #new-variation-id').val('');
        $('#selected-product-info').hide();
    });

    // Save barcode
    $('#btn-save-barcode').on('click', function() {
        const barcode = $('#new-barcode').val().trim();
        if (!barcode) {
            alert('Código de barra requerido');
            return;
        }
        
        $.post(ajaxurl, {
            action: 'riverso_add_barcode',
            nonce: nonce,
            barcode: barcode,
            product_id: $('#new-product-id').val(),
            variation_id: $('#new-variation-id').val(),
            barcode_type: $('#new-barcode-type').val(),
            is_primary: $('#new-is-primary').is(':checked') ? 1 : 0,
            notes: $('#new-notes').val()
        }, function(response) {
            if (response.success) {
                $('#modal-add-barcode').hide();
                loadBarcodes();
                loadStats();
            } else {
                alert(response.data.message);
            }
        });
    });

    // Import CSV
    $('#btn-preview-import').on('click', function() {
        const file = $('#import-file')[0].files[0];
        if (!file) {
            alert('Selecciona un archivo CSV');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            const lines = e.target.result.split('\n');
            const preview = $('#preview-list');
            preview.empty();
            importData = [];
            
            // Detect separator
            const firstLine = lines[0];
            const separator = firstLine.includes(';') ? ';' : ',';
            
            // Skip header
            for (let i = 1; i < Math.min(lines.length, 21); i++) {
                const parts = lines[i].split(separator);
                if (parts.length >= 2) {
                    const sku = parts[0].trim();
                    const barcode = parts[1].trim();
                    
                    if (barcode) {
                        importData.push({sku: sku, barcode: barcode});
                        preview.append(`
                            <tr>
                                <td>${sku}</td>
                                <td><code>${barcode}</code></td>
                                <td>Pendiente</td>
                            </tr>
                        `);
                    }
                }
            }
            
            // Count total from all lines
            let total = 0;
            for (let i = 1; i < lines.length; i++) {
                const parts = lines[i].split(separator);
                if (parts.length >= 2 && parts[1].trim()) {
                    total++;
                    if (i > 20) {
                        importData.push({
                            sku: parts[0].trim(),
                            barcode: parts[1].trim()
                        });
                    }
                }
            }
            
            $('#preview-summary').text(`Total: ${total} códigos de barra para importar`);
            $('#import-preview').show();
        };
        reader.readAsText(file);
    });

    $('#btn-confirm-import').on('click', function() {
        if (!importData.length) {
            alert('No hay datos para importar');
            return;
        }
        
        $(this).prop('disabled', true).text('Importando...');
        
        $.post(ajaxurl, {
            action: 'riverso_bulk_import_barcodes',
            nonce: nonce,
            barcodes: importData
        }, function(response) {
            $('#btn-confirm-import').prop('disabled', false).text('Confirmar Importación');
            
            if (response.success) {
                alert(response.data.message);
                $('#import-preview').hide();
                $('#import-file').val('');
                importData = [];
                loadStats();
                loadBarcodes();
            } else {
                alert(response.data.message);
            }
        });
    });

    function esc(v) {
        return $('<div>').text(v == null ? '' : String(v)).html();
    }
    function emptyFlag(v) {
        return v === true || v === 1 || v === '1';
    }

    function badgeEstado(estado, conflicto) {
        if (conflicto) return '<span class="badge-estado badge-conflicto">conflicto</span>';
        const map = {verificado: 'badge-verificado', propuesto: 'badge-propuesto', rechazado: 'badge-rechazado'};
        return `<span class="badge-estado ${map[estado] || 'badge-propuesto'}">${esc(estado || '')}</span>`;
    }

    function postMap(action, extra) {
        return $.post(ajaxurl, Object.assign({action: action, nonce: nonce}, extra || {}));
    }

    let mapeoTipos = [];
    let currentSku = '';
    let skuDetailById = {};

    function loadEnvaseTipos(cb) {
        postMap('riverso_envase_tipos_list').done(function(resp) {
            mapeoTipos = (resp.success && resp.data.items) ? resp.data.items : [];
            const $sel = $('#mapeo-edit-tipo');
            $sel.empty();
            mapeoTipos.filter(t => Number(t.activo) === 1).forEach(function(t) {
                $sel.append(`<option value="${esc(t.slug)}">${esc(t.nombre)}</option>`);
            });
            if (cb) cb(mapeoTipos);
        });
    }

    function loadMapeoSku() {
        const search = $('#mapeo-search').val();
        const estado = $('#mapeo-filter-estado').val();
        $('#mapeo-sku-list').html('<tr><td colspan="8">Cargando...</td></tr>');
        postMap('riverso_barcode_list_by_sku', {search: search, estado: estado, page: 1}).done(function(resp) {
            if (!resp.success) {
                $('#mapeo-sku-list').html('<tr><td colspan="8">Error al cargar</td></tr>');
                return;
            }
            const items = resp.data.items || [];
            if (!items.length) {
                $('#mapeo-sku-list').html('<tr><td colspan="8">Sin códigos en mapeo interno. Usa el escáner o importa legacy para generar propuestas.</td></tr>');
                return;
            }
            $('#mapeo-sku-list').html(items.map(function(row) {
                return `<tr>
                    <td><code>${esc(row.sku_key)}</code></td>
                    <td>${esc(row.nombre || '')}</td>
                    <td>${esc(row.barcodes)}</td>
                    <td>${esc(row.verificados)}</td>
                    <td>${esc(row.propuestos)}</td>
                    <td>${esc(row.conflictos)}</td>
                    <td>${esc(row.last_mod || '')}</td>
                    <td><button type="button" class="button button-small btn-sku-detail" data-sku="${esc(row.sku_key)}">Ver</button></td>
                </tr>`;
            }).join(''));
        }).fail(function() {
            $('#mapeo-sku-list').html('<tr><td colspan="8">Error de red</td></tr>');
        });
        loadEnvaseTipos();
    }

    function renderBarcodeActions(item) {
        const id = item.id || 0;
        let html = '';
        if (id && item.estado === 'propuesto') {
            html += `<button type="button" class="button button-small button-primary btn-map-approve" data-id="${id}">Aprobar</button> `;
            html += `<button type="button" class="button button-small btn-map-reject" data-id="${id}">Rechazar</button> `;
        }
        html += `<button type="button" class="button button-small btn-map-edit" data-id="${id}">Editar</button>`;
        return html;
    }

    function loadSkuDetail(sku) {
        currentSku = sku;
        const $box = $('#mapeo-sku-detail').show().html('<p>Cargando detalle...</p>');
        postMap('riverso_barcode_get_sku_detail', {sku: sku}).done(function(resp) {
            if (!resp.success) {
                $box.html('<p>Error al cargar detalle</p>');
                return;
            }
            const items = resp.data.items || [];
            skuDetailById = {};
            items.forEach(function(it) { skuDetailById[it.id] = it; });
            let html = `<h3>Códigos de <code>${esc(sku)}</code></h3>
                <table class="wp-list-table widefat striped">
                <thead><tr>
                    <th>Código</th><th>Estado</th><th>Envase</th><th>Cantidad</th><th>Modificado</th><th>Acciones</th>
                </tr></thead><tbody>`;
            items.forEach(function(it) {
                const envase = it.tipo_envase ? `${it.tipo_envase} (${it.envase_cantidad || it.cantidad || 1})` : '—';
                html += `<tr>
                    <td><span class="barcode-code">${esc(it.codigo)}</span></td>
                    <td>${badgeEstado(it.estado, it.conflicto)}</td>
                    <td>${esc(envase)}</td>
                    <td>${esc(it.cantidad || 1)}</td>
                    <td>${esc(it.updated_at || '')}</td>
                    <td>${renderBarcodeActions(it)}</td>
                </tr>`;
            });
            html += '</tbody></table>';
            $box.html(html);
        });
    }

    function renderGroupList(groups, target) {
        if (!groups || !groups.length) {
            $(target).html('<p>Sin registros.</p>');
            return;
        }
        let html = '';
        groups.forEach(function(g) {
            (g.items || []).forEach(function(it) { if (it.id) skuDetailById[it.id] = it; });
            html += `<div class="resolve-item" style="flex-direction:column;align-items:stretch;">
                <strong>${esc(g.codigo)}</strong>
                ${(g.items || []).map(function(it) {
                    return `<div style="display:flex;justify-content:space-between;gap:8px;margin-top:6px;">
                        <span>${badgeEstado(it.estado, it.conflicto)} ${esc(it.sku_local || it.canonical_sku || it.pending_sku || '')} ${esc(it.nombre_canonico || '')}</span>
                        <span>${it.id ? renderBarcodeActions(it) : '<em>solo legacy</em>'}</span>
                    </div>`;
                }).join('')}
            </div>`;
        });
        $(target).html(html);
    }

    function loadMapeoPending() {
        $('#mapeo-pending-list').html('<p>Cargando...</p>');
        postMap('riverso_barcode_list_pending').done(function(resp) {
            renderGroupList(resp.success ? (resp.data.items || []) : [], '#mapeo-pending-list');
        }).fail(function() {
            $('#mapeo-pending-list').html('<p>Error al cargar pendientes.</p>');
        });
    }

    function loadMapeoConflicts() {
        $('#mapeo-conflict-list').html('<p>Cargando...</p>');
        postMap('riverso_barcode_list_conflicts').done(function(resp) {
            if (!resp.success) {
                $('#mapeo-conflict-list').html('<p>Error.</p>');
                return;
            }
            renderGroupList(resp.data.items || [], '#mapeo-conflict-list');
            const shared = resp.data.shared_sku || [];
            if (shared.length) {
                let extra = '<h4>SKUs con varios códigos</h4><ul>';
                shared.forEach(function(s) {
                    extra += `<li><code>${esc(s.sku_local)}</code> — ${esc(s.barcodes)} códigos: ${esc(s.codigos)}</li>`;
                });
                extra += '</ul>';
                $('#mapeo-conflict-list').append(extra);
            }
        }).fail(function() {
            $('#mapeo-conflict-list').html('<p>Error al cargar conflictos.</p>');
        });
    }

    function loadMapeoTipos() {
        loadEnvaseTipos(function(items) {
            if (!items.length) {
                $('#mapeo-tipos-list').html('<tr><td colspan="5">Sin tipos. Se crearán Envase, Caja y Balde al migrar.</td></tr>');
                return;
            }
            $('#mapeo-tipos-list').html(items.map(function(t) {
                const activo = Number(t.activo) === 1;
                return `<tr>
                    <td><code>${esc(t.slug)}</code></td>
                    <td>${esc(t.nombre)}</td>
                    <td>${activo ? 'Sí' : 'No'}</td>
                    <td>${esc(t.orden)}</td>
                    <td><button type="button" class="button button-small btn-tipo-toggle" data-id="${t.id}" data-activo="${activo ? 0 : 1}">${activo ? 'Desactivar' : 'Activar'}</button></td>
                </tr>`;
            }).join(''));
        });
    }

    $('.mapeo-subtab').on('click', function() {
        $('.mapeo-subtab').removeClass('button-primary');
        $(this).addClass('button-primary');
        const sub = $(this).data('sub');
        $('#mapeo-sub-sku, #mapeo-sub-pending, #mapeo-sub-conflicts, #mapeo-sub-tipos').hide();
        $('#mapeo-sub-' + sub).show();
        if (sub === 'sku') loadMapeoSku();
        if (sub === 'pending') loadMapeoPending();
        if (sub === 'conflicts') loadMapeoConflicts();
        if (sub === 'tipos') loadMapeoTipos();
    });

    $('#btn-mapeo-search').on('click', loadMapeoSku);
    $('#mapeo-search').on('keypress', function(e) {
        if (e.which === 13) { e.preventDefault(); loadMapeoSku(); }
    });

    $(document).on('click', '.btn-sku-detail', function() {
        loadSkuDetail($(this).data('sku'));
    });

    $(document).on('click', '.btn-map-approve', function() {
        const id = $(this).data('id');
        postMap('riverso_barcode_approve', {codigo_id: id}).done(function(resp) {
            alert(resp.success ? resp.data.message : (resp.data && resp.data.message) || 'Error');
            if (currentSku) loadSkuDetail(currentSku);
            loadMapeoPending();
            loadMapeoConflicts();
        });
    });
    $(document).on('click', '.btn-map-reject', function() {
        const id = $(this).data('id');
        const motivo = prompt('Motivo de rechazo', 'Rechazado desde wp-admin') || 'Rechazado desde wp-admin';
        postMap('riverso_barcode_reject', {codigo_id: id, motivo: motivo}).done(function(resp) {
            alert(resp.success ? resp.data.message : (resp.data && resp.data.message) || 'Error');
            if (currentSku) loadSkuDetail(currentSku);
        });
    });

    function openMapeoEdit(item) {
        item = item || {};
        $('#mapeo-edit-id').val(item.id || '');
        $('#mapeo-edit-codigo').val(item.codigo || '');
        $('#mapeo-edit-sku').val(item.sku_local || item.pending_sku || item.canonical_sku || '');
        $('#mapeo-edit-producto-base-id').val(item.producto_base_id || '');
        $('#mapeo-edit-cantidad').val(item.cantidad || 1);
        $('#mapeo-edit-estado').val(item.estado === 'verificado' ? 'verificado' : 'propuesto');
        $('#mapeo-edit-create-envase').prop('checked', false);
        loadEnvaseTipos(function() {
            if (item.tipo_envase) $('#mapeo-edit-tipo').val(item.tipo_envase);
        });
        $('#modal-mapeo-edit').show();
    }

    $('#btn-mapeo-add').on('click', function() { openMapeoEdit({}); });
    $(document).on('click', '.btn-map-edit', function() {
        const id = $(this).data('id');
        openMapeoEdit(skuDetailById[id] || {id: id});
    });

    $('#mapeo-edit-product-q').on('input', debounce(function() {
        const q = $(this).val();
        if (q.length < 1) { $('#mapeo-edit-product-results').hide(); return; }
        postMap('riverso_barcode_search_products', {query: q}).done(function(resp) {
            const items = resp.success ? (resp.data.items || []) : [];
            if (!items.length) { $('#mapeo-edit-product-results').hide(); return; }
            $('#mapeo-edit-product-results').show().html(items.map(function(p) {
                return `<div class="result-item" data-id="${p.id}" data-sku="${esc(p.canonical_sku)}">${esc(p.canonical_sku)} — ${esc(p.nombre_canonico)}</div>`;
            }).join(''));
        });
    }, 250));

    $(document).on('click', '#mapeo-edit-product-results .result-item', function() {
        $('#mapeo-edit-producto-base-id').val($(this).data('id'));
        $('#mapeo-edit-sku').val($(this).data('sku'));
        $('#mapeo-edit-product-results').hide();
    });

    $('#btn-mapeo-edit-save').on('click', function() {
        postMap('riverso_barcode_upsert', {
            codigo_id: $('#mapeo-edit-id').val(),
            codigo: $('#mapeo-edit-codigo').val(),
            sku_local: $('#mapeo-edit-sku').val(),
            producto_base_id: $('#mapeo-edit-producto-base-id').val(),
            tipo_envase: $('#mapeo-edit-tipo').val(),
            cantidad: $('#mapeo-edit-cantidad').val(),
            estado: $('#mapeo-edit-estado').val(),
            create_envase: $('#mapeo-edit-create-envase').is(':checked') ? 1 : 0
        }).done(function(resp) {
            if (!resp.success) {
                alert((resp.data && resp.data.message) || 'Error al guardar');
                return;
            }
            $('#modal-mapeo-edit').hide();
            loadMapeoSku();
            if (currentSku) loadSkuDetail(currentSku);
        });
    });

    $('#form-envase-tipo').on('submit', function(e) {
        e.preventDefault();
        postMap('riverso_envase_tipo_create', {
            nombre: $('#tipo-nombre').val(),
            slug: $('#tipo-slug').val()
        }).done(function(resp) {
            if (!resp.success) {
                alert((resp.data && resp.data.message) || 'Error');
                return;
            }
            $('#tipo-nombre, #tipo-slug').val('');
            loadMapeoTipos();
        });
    });
    $(document).on('click', '.btn-tipo-toggle', function() {
        postMap('riverso_envase_tipo_toggle', {id: $(this).data('id'), activo: $(this).data('activo')}).done(loadMapeoTipos);
    });

    function showResolveModal(product, suggestions) {
        const barcode = product.barcode || $('#scanner-input').val();
        const conflict = emptyFlag(product.conflicts);
        $('#resolve-warning').html(
            (conflict
                ? '<strong>Conflicto:</strong> este código puede apuntar a SKUs distintos o no coincidir con el local correcto. '
                : '<strong>Sugerencia legacy:</strong> no está en el mapeo verificado. ')
            + '¿Quieres resolverlo ahora o ignorar?'
        );
        const rows = (suggestions && suggestions.length) ? suggestions : [{
            sku: product.sku, sku_local: product.sku_local, nombre: product.name, id: product.barcode_id,
            producto_base_id: product.producto_base_id, origen: product.source
        }];
        $('#resolve-suggestions').html(rows.map(function(s, idx) {
            return `<div class="resolve-item">
                <div>
                    <code>${esc(s.sku_local || s.sku || '')}</code>
                    ${esc(s.nombre || s.nombre_canonico || '')}<br>
                    <small>${esc(s.origen || '')}</small>
                </div>
                <div>
                    <button type="button" class="button button-primary btn-resolve-approve"
                        data-id="${s.id || 0}"
                        data-codigo="${esc(barcode)}"
                        data-sku="${esc(s.sku_local || s.sku || '')}"
                        data-pb="${s.producto_base_id || 0}">Aprobar esta</button>
                    <button type="button" class="button btn-resolve-reject" data-id="${s.id || 0}">Rechazar</button>
                </div>
            </div>`;
        }).join(''));
        $('#modal-resolve-barcode').show();
    }

    $(document).on('click', '.btn-resolve-approve', function() {
        const $btn = $(this);
        const id = $btn.data('id');
        const payload = {
            codigo_id: id,
            codigo: $btn.data('codigo'),
            sku_local: $btn.data('sku'),
            producto_base_id: $btn.data('pb'),
            estado: 'verificado',
            verify: 1
        };
        const action = id ? 'riverso_barcode_approve' : 'riverso_barcode_upsert';
        const data = id ? {codigo_id: id} : payload;
        postMap(action, data).done(function(resp) {
            if (!resp.success && $btn.data('pb')) {
                postMap('riverso_barcode_assign', {
                    codigo_id: id,
                    codigo: $btn.data('codigo'),
                    producto_base_id: $btn.data('pb'),
                    verify: 1
                }).done(function(r2) {
                    alert(r2.success ? 'Código verificado' : ((r2.data && r2.data.message) || 'No se pudo aprobar'));
                    $('#modal-resolve-barcode').hide();
                });
                return;
            }
            if (!resp.success) {
                postMap('riverso_barcode_upsert', payload).done(function(r3) {
                    alert(r3.success ? 'Código guardado' : ((r3.data && r3.data.message) || 'No se pudo guardar'));
                    $('#modal-resolve-barcode').hide();
                });
                return;
            }
            alert(resp.data.message || 'Listo');
            $('#modal-resolve-barcode').hide();
        });
    });
    $(document).on('click', '.btn-resolve-reject', function() {
        const id = $(this).data('id');
        if (!id) { alert('Este código aún no está en mapeo interno; ignóralo o asígnalo primero.'); return; }
        postMap('riverso_barcode_reject', {codigo_id: id, motivo: 'Rechazado desde escáner wp-admin'}).done(function(resp) {
            alert(resp.success ? 'Rechazado' : ((resp.data && resp.data.message) || 'Error'));
            $('#modal-resolve-barcode').hide();
        });
    });
    $('#btn-resolve-ignore').on('click', function() {
        $('#modal-resolve-barcode').hide();
    });

    // Close modals
    $('.riverso-modal-close, #btn-cancel-add, #btn-close-scan, #btn-mapeo-edit-cancel').on('click', function() {
        $(this).closest('.riverso-modal').hide();
    });

    function debounce(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Initial load
    loadStats();
    loadBarcodes();
    
    // Auto-focus scanner on page load
    $('#scanner-input').focus();
});
</script>
