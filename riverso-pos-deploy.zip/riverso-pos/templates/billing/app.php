<?php
/**
 * App Facturación · Emitir (portal).
 *
 * @var array<string, mixed> $riverso_billing
 */
$surface = (isset($riverso_billing['surface']) && $riverso_billing['surface'] === 'admin') ? 'admin' : 'portal';
$asset_base = rtrim((string) (isset($riverso_billing['assetBase']) ? $riverso_billing['assetBase'] : ''), '/');
$version = defined('RIVERSO_POS_VERSION') ? RIVERSO_POS_VERSION : '0.1.0';
$js_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/js/billing.js';
$js_lines_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/js/billing-lines.js';
$js_emails_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/js/billing-emails.js';
$css_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/css/billing.css';
$css_cq_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/css/customer-quotes.css';
$js_ver = (is_string($js_path) && is_file($js_path)) ? (string) filemtime($js_path) : $version;
$js_lines_ver = (is_string($js_lines_path) && is_file($js_lines_path)) ? (string) filemtime($js_lines_path) : $version;
// Descuentos y «Otra regla» compartidos con cotizaciones.
$line_discounts_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/js/line-discounts.js';
$line_discounts_ver = (is_string($line_discounts_path) && is_file($line_discounts_path)) ? (string) filemtime($line_discounts_path) : $version;
$js_emails_ver = (is_string($js_emails_path) && is_file($js_emails_path)) ? (string) filemtime($js_emails_path) : $version;
$css_ver = (is_string($css_path) && is_file($css_path)) ? (string) filemtime($css_path) : $version;
$css_cq_ver = (is_string($css_cq_path) && is_file($css_cq_path)) ? (string) filemtime($css_cq_path) : $version;
$scanner_js_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/js/barcode-scanner.js';
$scanner_css_path = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'assets/css/barcode-scanner.css';
$scanner_js_ver = (is_string($scanner_js_path) && is_file($scanner_js_path)) ? (string) filemtime($scanner_js_path) : $version;
$scanner_css_ver = (is_string($scanner_css_path) && is_file($scanner_css_path)) ? (string) filemtime($scanner_css_path) : $version;
$issuer = isset($riverso_billing['issuer']['issuer']) && is_array($riverso_billing['issuer']['issuer'])
    ? $riverso_billing['issuer']['issuer']
    : [];
$issuer_rut = isset($issuer['tax_id_code']) ? (string) $issuer['tax_id_code'] : '';
$issuer_ok = !empty($riverso_billing['issuer']['ok']);
$comunas = [];
if (!class_exists('Riverso_Customer_Module')) {
    $cm = (defined('RIVERSO_POS_PLUGIN_DIR') ? RIVERSO_POS_PLUGIN_DIR : '') . 'sales/customers/class-customer-module.php';
    if ($cm && file_exists($cm)) {
        require_once $cm;
    }
}
if (class_exists('Riverso_Customer_Module') && method_exists('Riverso_Customer_Module', 'chile_comunas')) {
    $comunas = Riverso_Customer_Module::chile_comunas();
}

if (!function_exists('riverso_pos_billing_json')) {
    function riverso_pos_billing_json($data) {
        $flags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
        if (function_exists('wp_json_encode')) {
            $json = wp_json_encode($data, $flags);
            return is_string($json) ? $json : '{}';
        }
        $json = json_encode($data, $flags);
        return is_string($json) ? $json : '{}';
    }
}
?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/css/billing.css?ver=<?php echo htmlspecialchars($css_ver, ENT_QUOTES, 'UTF-8'); ?>">
<link rel="stylesheet" href="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/css/customer-quotes.css?ver=<?php echo htmlspecialchars($css_cq_ver, ENT_QUOTES, 'UTF-8'); ?>">
<link rel="stylesheet" href="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/css/barcode-scanner.css?ver=<?php echo htmlspecialchars($scanner_css_ver, ENT_QUOTES, 'UTF-8'); ?>">

<div class="wrap riverso-bill-wrap riverso-bill-wrap--<?php echo htmlspecialchars($surface, ENT_QUOTES, 'UTF-8'); ?>">
    <div id="riverso-billing" class="riverso-bill" data-ready="0">

        <div class="bill-seller-bar">
            <label class="cq-advanced-toggle cq-seller-toggle" for="bill-seller-view" title="Muestra margen, utilidad y stock. Mantenla apagada frente al cliente.">
                <input type="checkbox" id="bill-seller-view" autocomplete="off">
                <span>Interfaz vendedor</span>
            </label>
        </div>

        <div id="bill-alerts" class="bill-alerts" hidden></div>

        <?php if (!$issuer_ok): ?>
        <div class="bill-banner bill-banner-warn">
            Configura los datos del emisor en Ajustes → FACTO (RUT, razón social, dirección, comuna, ciudad, teléfono y giro) antes de emitir.
            <?php if (!empty($riverso_billing['issuer']['missing'])): ?>
            <br>Falta: <?php echo esc_html(implode(', ', $riverso_billing['issuer']['missing'])); ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <section id="bill-step-1" class="bill-step">
            <div class="bill-card">
                <div class="bill-card-head">
                    <h2>DATOS DEL DOCUMENTO</h2>
                    <div class="bill-folio-card" id="bill-folio-card" aria-live="polite">
                        <div class="bill-folio-rut">RUT: <strong id="bill-issuer-rut"><?php echo esc_html($issuer_rut !== '' ? $issuer_rut : '—'); ?></strong></div>
                        <div class="bill-folio-type" id="bill-folio-type">BOLETA ELECTRÓNICA</div>
                        <div class="bill-folio-num">N° <span id="bill-folio-est">—</span></div>
                        <div class="bill-folio-note">(DOC NO CREADO - FOLIO ESTIMADO)</div>
                    </div>
                </div>

                <div class="bill-grid bill-grid-3">
                    <label class="bill-field">
                        <span>Tipo de Documento (*)</span>
                        <select id="bill-doc-type">
                            <?php
                            $types = isset($riverso_billing['documentTypes']) && is_array($riverso_billing['documentTypes'])
                                ? $riverso_billing['documentTypes']
                                : [];
                            $initial_doc_type = (int) ($riverso_billing['initialDocType'] ?? 37);
                            foreach ($types as $t):
                                $tid = (int) ($t['id'] ?? 0);
                                $enabled = !empty($t['enabled']);
                                $label = (string) ($t['label'] ?? '');
                                if (!empty($t['wip'])) {
                                    $label .= ' [WIP]';
                                }
                            ?>
                            <option value="<?php echo $enabled ? (int) $tid : ''; ?>"
                                <?php echo $tid === $initial_doc_type ? 'selected' : ''; ?>
                                <?php echo $enabled ? '' : 'disabled'; ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label class="bill-field bill-field-check">
                        <span>&nbsp;</span>
                        <label class="bill-check">
                            <input type="checkbox" id="bill-folio-auto" checked disabled>
                            Folio automático
                        </label>
                    </label>
                    <label class="bill-field">
                        <span>Fecha emisión (*)</span>
                        <input type="date" id="bill-issue-date" value="<?php echo esc_attr($riverso_billing['todayDate'] ?? ''); ?>">
                    </label>
                </div>

                <div class="bill-grid bill-grid-3">
                    <label class="bill-field">
                        <span>Vendedor</span>
                        <select id="bill-seller" disabled>
                            <option selected>** Sin vendedor **</option>
                        </select>
                    </label>
                    <label class="bill-field">
                        <span>Condiciones de pago</span>
                        <select id="bill-payment">
                            <option value="0" selected>Contado</option>
                            <option value="30">30 días</option>
                            <option value="0,30">50% contado / 50% 30 días</option>
                        </select>
                    </label>
                    <label class="bill-field">
                        <span>Área de negocios / Centro de costo</span>
                        <select id="bill-cost-center" disabled>
                            <option selected>0001 - No clasificado</option>
                        </select>
                    </label>
                </div>

                <p class="bill-note-red" id="bill-cession-note">NOTA: El SII no permite CESIÓN para documentos al CONTADO</p>
                <p class="bill-hint" id="bill-folio-unused" hidden></p>
            </div>

            <div class="bill-card" id="bill-receiver-card" hidden>
                <div class="bill-card-head bill-receiver-head">
                    <h2>RECEPTOR</h2>
                    <div class="bill-receiver-actions">
                        <button type="button" class="bill-btn bill-btn-secondary" id="bill-recv-edit" hidden>Editar</button>
                        <button type="button" class="bill-btn bill-btn-danger" id="bill-recv-cancel" hidden>Cancelar</button>
                        <button type="button" class="bill-btn bill-btn-primary" id="bill-recv-save" hidden>Guardar</button>
                    </div>
                </div>
                <p class="bill-note-red">El RUT 55.555.555-5 es solo para casos especiales; para empresa extranjera emite un documento de exportación.</p>
                <p class="bill-hint">Ingrese una opción para buscar datos de facturación</p>

                <div class="bill-search-row bill-search-row-rut">
                    <label class="bill-field">
                        <span>Tipo de identificación</span>
                        <select id="bill-id-type" disabled>
                            <option selected>RUT Cliente/Proveed</option>
                        </select>
                    </label>
                    <label class="bill-field">
                        <span>RUT Cliente/Proveedor</span>
                        <input type="text" id="bill-recv-rut" placeholder="12.345.678-9" autocomplete="off">
                    </label>
                    <div class="bill-field bill-field-action">
                        <span>&nbsp;</span>
                        <button type="button" class="bill-btn bill-btn-primary" id="bill-rut-search-btn">Buscar RUT</button>
                    </div>
                </div>

                <div class="bill-search-row bill-search-row-name">
                    <label class="bill-field bill-field-grow">
                        <span>Nombre / apodo / razón social</span>
                        <input type="text" id="bill-name-search" placeholder="Buscar por nombre o razón social…" autocomplete="off">
                    </label>
                    <div class="bill-field bill-field-action">
                        <span>&nbsp;</span>
                        <button type="button" class="bill-btn bill-btn-primary" id="bill-name-search-btn">Buscar nombre</button>
                    </div>
                </div>
                <div id="bill-customer-results" class="bill-customer-results" hidden></div>

                <div id="bill-sii-panel" class="bill-sii-panel" hidden>
                    <div class="bill-sii-head">
                        <strong>Actividades económicas vigentes (SII)</strong>
                        <span id="bill-sii-status" class="bill-sii-status"></span>
                    </div>
                    <p class="bill-hint" id="bill-sii-hint">Elige una actividad para rellenar el giro. Si ya emitiste con esa actividad, se autocompleta la dirección.</p>
                    <div id="bill-sii-activities" class="bill-sii-activities"></div>
                </div>

                <input type="hidden" id="bill-customer-id" value="0">
                <input type="hidden" id="bill-recv-activity-code" value="">
                <div class="bill-grid bill-grid-3">
                    <label class="bill-field">
                        <span>RUT (confirmado)</span>
                        <input type="text" id="bill-recv-rut-display" readonly tabindex="-1" class="bill-locked" value="">
                    </label>
                    <label class="bill-field">
                        <span>Razón social</span>
                        <input type="text" id="bill-recv-name" class="bill-locked" readonly autocomplete="organization">
                    </label>
                    <label class="bill-field" id="bill-giro-field">
                        <span>Giro</span>
                        <input type="text" id="bill-recv-giro" class="bill-locked" readonly>
                        <span class="bill-giro-stale-note" hidden>Este giro no está entre las actividades vigentes del SII. Elige una de la lista.</span>
                    </label>
                </div>
                <div class="bill-grid bill-grid-3">
                    <label class="bill-field">
                        <span>Dirección</span>
                        <input type="text" id="bill-recv-address" class="bill-locked" readonly>
                    </label>
                    <div class="bill-field bill-field-comuna">
                        <div class="bill-comuna-combo bill-locked" id="bill-comuna-combo" data-locked="1">
                            <button type="button" class="bill-comuna-trigger" id="bill-comuna-trigger" aria-haspopup="listbox" aria-expanded="false" disabled>
                                <span class="bill-comuna-label">Comuna</span>
                                <span class="bill-comuna-value" id="bill-comuna-value-text"></span>
                                <span class="bill-comuna-chevron" aria-hidden="true">
                                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none"><path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </span>
                            </button>
                            <input type="hidden" id="bill-recv-comuna" value="">
                            <div class="bill-comuna-dropdown" id="bill-comuna-dropdown" hidden>
                                <input type="text" class="bill-comuna-search" id="bill-comuna-search" placeholder="Buscar comuna…" autocomplete="off" aria-label="Buscar comuna">
                                <ul class="bill-comuna-list" id="bill-comuna-list" role="listbox"></ul>
                            </div>
                        </div>
                        <script type="application/json" id="bill-comunas-data"><?php
                            echo riverso_pos_billing_json(array_values($comunas));
                        ?></script>
                    </div>
                    <label class="bill-field">
                        <span>Ciudad</span>
                        <input type="text" id="bill-recv-city" class="bill-locked" readonly>
                    </label>
                </div>
                <div class="bill-grid bill-grid-2">
                    <label class="bill-field">
                        <span>Teléfono (opcional)</span>
                        <input type="text" id="bill-recv-phone" class="bill-locked" readonly>
                    </label>
                    <label class="bill-field">
                        <span>Código postal</span>
                        <input type="text" id="bill-recv-postal" class="bill-locked" readonly value="">
                    </label>
                </div>
            </div>

            <div class="bill-step-footer">
                <span class="bill-step-label">Paso 1 de 2</span>
                <button type="button" class="bill-btn bill-btn-primary bill-btn-lg" id="bill-to-step-2">Crear documento y continuar</button>
            </div>
        </section>

        <section id="bill-step-2" class="bill-step" hidden>
            <!-- Editor borrador (boleta y factura) -->
            <div id="bill-step-2-boleta">
                <div class="bill-card bill-issuer-card">
                    <div class="bill-card-head">
                        <h2>EMISOR Y DATOS DEL DOCUMENTO</h2>
                        <div class="bill-issuer-actions">
                            <button type="button" class="bill-btn bill-btn-secondary" disabled title="WIP">Opciones [WIP]</button>
                            <button type="button" class="bill-btn bill-btn-danger" id="bill-draft-delete" hidden>Borrar</button>
                        </div>
                    </div>
                    <div class="bill-issuer-layout">
                        <div class="bill-issuer-info">
                            <div class="bill-issuer-name" id="bill-boleta-issuer-name"><?php echo esc_html($issuer['legal_name'] ?? '—'); ?></div>
                            <div class="bill-issuer-line" id="bill-boleta-issuer-addr">
                                <?php
                                $addr_bits = array_filter([
                                    $issuer['address'] ?? '',
                                    $issuer['district'] ?? '',
                                    $issuer['city'] ?? '',
                                ]);
                                echo esc_html($addr_bits ? implode(', ', $addr_bits) : '—');
                                ?>
                            </div>
                            <div class="bill-issuer-line" id="bill-boleta-issuer-giro"><?php echo esc_html($issuer['activity'] ?? '—'); ?></div>
                            <div class="bill-issuer-line">Teléfono: <span id="bill-boleta-issuer-phone"><?php echo esc_html($issuer['phone'] ?? '—'); ?></span></div>
                        </div>
                        <div class="bill-draft-badge-card">
                            <div class="bill-draft-rut">RUT: <strong><?php echo esc_html($issuer_rut !== '' ? $issuer_rut : '—'); ?></strong></div>
                            <div class="bill-draft-type" id="bill-draft-type">BOLETA ELECTRÓNICA</div>
                            <div class="bill-draft-banner" id="bill-draft-banner">
                                <span id="bill-draft-banner-text">DOC EN BORRADOR</span>
                            </div>
                            <div class="bill-draft-folio">N° <span id="bill-boleta-folio-est">—</span></div>
                        </div>
                    </div>
                    <div class="bill-grid bill-grid-4 bill-draft-meta">
                        <label class="bill-field">
                            <span>Fecha emisión</span>
                            <input type="date" id="bill-boleta-issue-date" value="<?php echo esc_attr($riverso_billing['todayDate'] ?? ''); ?>">
                        </label>
                        <label class="bill-field">
                            <span>Fecha de vencimiento</span>
                            <input type="date" id="bill-boleta-due-date" value="">
                        </label>
                        <label class="bill-field">
                            <span>Condiciones de pago</span>
                            <select id="bill-boleta-payment">
                                <option value="0" selected>Contado</option>
                                <option value="30">30 días</option>
                                <option value="0,30">50% contado / 50% 30 días</option>
                            </select>
                        </label>
                        <label class="bill-field">
                            <span>Ingresado por</span>
                            <input type="text" id="bill-boleta-user" value="<?php echo esc_attr($riverso_billing['currentUserName'] ?? ''); ?>" readonly>
                        </label>
                        <label class="bill-field">
                            <span>Fecha cierre documento</span>
                            <input type="text" value="" readonly placeholder="—" class="bill-locked">
                        </label>
                        <label class="bill-field">
                            <span>Vendedor</span>
                            <input type="text" value="" readonly placeholder="[WIP]" class="bill-locked">
                        </label>
                        <label class="bill-field">
                            <span>Centro de costo</span>
                            <input type="text" value="0001 - No clasificado" readonly class="bill-locked">
                        </label>
                        <label class="bill-field">
                            <span>Estado de venta</span>
                            <select id="bill-boleta-sale-state" disabled>
                                <option selected>VENTA: Concretada</option>
                            </select>
                        </label>
                    </div>
                    <input type="hidden" id="bill-draft-id" value="0">
                </div>

                <div class="bill-card bill-step2-receiver-card" id="bill-step2-receiver" hidden>
                    <div class="bill-card-head">
                        <h2>RECEPTOR</h2>
                        <button type="button" class="bill-btn bill-btn-secondary bill-back-step-1" title="Cambiar receptor en el paso 1">Cambiar receptor</button>
                    </div>
                    <div class="bill-grid bill-grid-4 bill-draft-meta">
                        <div class="bill-field">
                            <span>RUT</span>
                            <div class="bill-static-value" id="bill-s2-recv-rut">—</div>
                        </div>
                        <div class="bill-field">
                            <span>Razón social</span>
                            <div class="bill-static-value" id="bill-s2-recv-name">—</div>
                        </div>
                        <div class="bill-field">
                            <span>Dirección</span>
                            <div class="bill-static-with-action">
                                <div class="bill-static-value" id="bill-s2-recv-address">—</div>
                                <a class="bill-static-action" id="bill-s2-recv-map" href="#" target="_blank" rel="noopener noreferrer" title="Ver en mapa" aria-label="Ver dirección en mapa">
                                    <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm6.93 6h-2.95a15.65 15.65 0 0 0-1.38-3.56A8.03 8.03 0 0 1 18.93 8zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14a8.2 8.2 0 0 1 0-4h3.38a16.5 16.5 0 0 0 0 4H4.26zm.81 2h2.95c.32 1.25.78 2.45 1.38 3.56A8 8 0 0 1 5.07 16zm2.95-8H5.07a8 8 0 0 1 4.33-3.56A15.65 15.65 0 0 0 8.02 8zM12 19.96c-.83-1.2-1.48-2.53-1.91-3.96h3.82c-.43 1.43-1.08 2.76-1.91 3.96zM14.34 14H9.66a14.7 14.7 0 0 1 0-4h4.68a14.7 14.7 0 0 1 0 4zm.25 5.56c.6-1.11 1.06-2.31 1.38-3.56h2.95a8.03 8.03 0 0 1-4.33 3.56zM16.36 14a16.5 16.5 0 0 0 0-4h3.38a8.2 8.2 0 0 1 0 4h-3.38z"/></svg>
                                </a>
                            </div>
                        </div>
                        <div class="bill-field">
                            <span>Comuna</span>
                            <div class="bill-static-value" id="bill-s2-recv-comuna">—</div>
                        </div>
                        <div class="bill-field">
                            <span>Ciudad</span>
                            <div class="bill-static-value" id="bill-s2-recv-city">—</div>
                        </div>
                        <div class="bill-field" id="bill-s2-giro-field">
                            <span>Giro</span>
                            <div class="bill-static-value" id="bill-s2-recv-giro">—</div>
                            <span class="bill-giro-stale-note" hidden>Este giro no está entre las actividades vigentes del SII.</span>
                        </div>
                        <div class="bill-field">
                            <span>Teléfono</span>
                            <div class="bill-static-value" id="bill-s2-recv-phone">—</div>
                        </div>
                    </div>
                </div>

                <div class="bill-card bill-tabs-card">
                    <nav class="bill-tabs" id="bill-boleta-tabs" role="tablist">
                        <button type="button" class="bill-tab is-active" data-tab="detalles" role="tab" aria-selected="true">Detalles</button>
                        <button type="button" class="bill-tab" data-tab="referencias" role="tab">Referencias</button>
                        <button type="button" class="bill-tab" data-tab="pagos" role="tab">$ Pagos</button>
                        <button type="button" class="bill-tab" data-tab="comentarios" role="tab">Comentarios</button>
                        <button type="button" class="bill-tab" data-tab="observaciones" role="tab">Observaciones</button>
                        <button type="button" class="bill-tab" data-tab="periodico" role="tab">Servicio Periódico</button>
                    </nav>

                    <div class="bill-tab-panel" id="bill-tab-detalles" data-panel="detalles">
                        <div class="bill-product-search-block">
                            <div class="bill-product-search-head">
                                <label for="bill-product-search">Buscar producto</label>
                                <label class="cq-advanced-toggle" for="bill-advanced">
                                    <input type="checkbox" id="bill-advanced">
                                    <span>Modo avanzado</span>
                                </label>
                            </div>
                            <div class="bill-product-search-row">
                                <input type="search" id="bill-product-search" placeholder="SKU, nombre o código de barras — Enter o + para buscar; + vacío abre lupa" autocomplete="off" enterkeyhint="search">
                                <button type="button" class="bill-btn bill-btn-primary" id="bill-product-add" title="Agregar / búsqueda avanzada si está vacío">+</button>
                                <button type="button" class="bill-btn bill-btn-secondary" id="bill-product-scan" title="Escanear código de barras" aria-label="Escanear código de barras"><span aria-hidden="true">📷</span></button>
                                <button type="button" class="bill-btn bill-btn-secondary" id="bill-search-clear" title="Limpiar búsqueda">Limpiar búsqueda</button>
                                <button type="button" class="cq-btn cq-btn-manual" id="bill-product-manual" title="Agregar producto sin SKU">Manual</button>
                                <button type="button" class="bill-btn bill-btn-wip" disabled>Producto o servicio [WIP]</button>
                            </div>
                            <ul id="bill-product-results" class="bill-product-results" hidden></ul>
                        </div>
                        <div class="cq-table-wrap bill-cq-table-wrap">
                            <table class="cq-table bill-cq-table" id="bill-boleta-lines-table">
                                <thead>
                                    <tr>
                                        <th scope="col">Detalle</th>
                                        <th scope="col" class="cq-num">Cantidad</th>
                                        <th scope="col" class="cq-num">Total bruto</th>
                                        <th scope="col" class="cq-num cq-advanced" title="Porcentaje de descuento sobre el bruto de la línea">Dscto precio</th>
                                        <th scope="col" class="cq-num cq-advanced" title="Mismo descuento como % del margen">Dscto margen</th>
                                        <th scope="col" class="cq-num cq-advanced cq-seller-only">Utilidad</th>
                                        <th scope="col" class="cq-num cq-advanced cq-seller-only" title="Stock en bodega (live)">Stock</th>
                                        <th scope="col">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="bill-boleta-lines-body"></tbody>
                            </table>
                        </div>
                        <p id="bill-lines-empty" class="cq-empty">Agrega productos con la búsqueda o con el botón Manual.</p>
                        <div class="bill-boleta-foot">
                            <button type="button" class="bill-btn bill-btn-wip" disabled>Agregar Descuento / Recargo [WIP]</button>
                            <div class="bill-totals bill-totals-boleta" id="bill-boleta-totals">
                                <div><span>Dscto</span><strong id="bill-boleta-discount">$0</strong></div>
                                <div class="cq-seller-only"><span>Margen</span><strong id="bill-boleta-margin">—</strong></div>
                                <div class="cq-seller-only"><span>Utilidad</span><strong id="bill-boleta-profit">—</strong></div>
                                <div><span>Neto</span><strong id="bill-boleta-net">$0</strong></div>
                                <div><span>Exento</span><strong id="bill-boleta-exento">$0</strong></div>
                                <div><span>IVA</span><strong id="bill-boleta-iva">$0</strong></div>
                                <div class="bill-tot-grand"><span>Total</span><strong id="bill-boleta-total">$0</strong></div>
                            </div>
                        </div>
                    </div>

                    <div class="bill-tab-panel" id="bill-tab-referencias" data-panel="referencias" hidden>
                        <div class="bill-refs-head">
                            <h3>Referencias</h3>
                            <button type="button" class="bill-btn bill-btn-primary" id="bill-ref-add">Agregar referencias</button>
                        </div>
                        <div id="bill-refs-form" class="bill-refs-form" hidden>
                            <div class="bill-grid bill-grid-3">
                                <label class="bill-field">
                                    <span>Tipo</span>
                                    <select id="bill-ref-type">
                                        <option value="quote">Cotización Riverso</option>
                                        <option value="folio">Otro folio</option>
                                    </select>
                                </label>
                                <label class="bill-field" id="bill-ref-quote-wrap">
                                    <span>Buscar cotización</span>
                                    <input type="text" id="bill-ref-quote-q" placeholder="Número de cotización…" autocomplete="off">
                                </label>
                                <label class="bill-field" id="bill-ref-folio-wrap" hidden>
                                    <span>Tipo doc. / Folio</span>
                                    <input type="text" id="bill-ref-folio" placeholder="Ej. Factura 1234" autocomplete="off">
                                </label>
                            </div>
                            <ul id="bill-ref-quote-results" class="bill-product-results" hidden></ul>
                            <div class="bill-step-actions">
                                <button type="button" class="bill-btn bill-btn-secondary" id="bill-ref-cancel">Cancelar</button>
                                <button type="button" class="bill-btn bill-btn-primary" id="bill-ref-save">Agregar</button>
                            </div>
                        </div>
                        <p class="bill-refs-subtitle">Referenciado por</p>
                        <div class="bill-table-wrap bill-refs-table-wrap">
                            <table class="bill-refs-table">
                                <thead>
                                    <tr>
                                        <th>Tipo de Operación</th>
                                        <th>Razón</th>
                                        <th>Tipo de Documento</th>
                                        <th>Folio</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody id="bill-refs-list"></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="bill-tab-panel" id="bill-tab-pagos" data-panel="pagos" hidden>
                        <div id="bill-pagos-draft-msg" class="bill-pagos-warn">
                            ATENCIÓN: Por favor cierre el documento antes de ingresar pagos asociados
                        </div>
                        <div id="bill-pagos-emitted" hidden>
                            <div class="bill-pagos-actions">
                                <button type="button" class="bill-btn bill-btn-primary" id="bill-pago-add-charge">Agregar cobro</button>
                                <button type="button" class="bill-btn bill-btn-wip" id="bill-pago-comprobante" disabled>Comprobante de pago [WIP]</button>
                            </div>
                            <div class="bill-table-wrap">
                                <table class="bill-table" id="bill-pagos-table">
                                    <thead>
                                        <tr>
                                            <th>Tipo</th>
                                            <th>Fecha</th>
                                            <th>Tipo</th>
                                            <th>Caja</th>
                                            <th>Doc Num</th>
                                            <th>Doc Tit</th>
                                            <th>Banco Doc</th>
                                            <th>Detalles</th>
                                            <th>Cobro/Pagos</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody id="bill-pagos-body"></tbody>
                                </table>
                            </div>
                            <div class="bill-pagos-totals" id="bill-pagos-totals">
                                <span>Total cobros: <strong id="bill-pagos-cobros">$0</strong></span>
                                <span>Total Pagos: <strong id="bill-pagos-pagos">$0</strong></span>
                                <span>Monto impago: <strong id="bill-pagos-impago">$0</strong></span>
                            </div>
                        </div>
                    </div>

                    <div class="bill-tab-panel" id="bill-tab-comentarios" data-panel="comentarios" hidden>
                        <p class="bill-hint">Comentarios [WIP]</p>
                    </div>
                    <div class="bill-tab-panel" id="bill-tab-observaciones" data-panel="observaciones" hidden>
                        <p class="bill-hint">Observaciones [WIP]</p>
                    </div>
                    <div class="bill-tab-panel" id="bill-tab-periodico" data-panel="periodico" hidden>
                        <p class="bill-hint">Servicio periódico [WIP]</p>
                    </div>
                </div>

                <div class="bill-step-footer bill-boleta-footer">
                    <button type="button" class="bill-btn bill-btn-secondary bill-back-step-1">Volver</button>
                    <span class="bill-step-label">Paso 2 de 2</span>
                    <div class="bill-step-actions bill-boleta-actions">
                        <button type="button" class="bill-btn bill-btn-primary bill-btn-lg" id="bill-boleta-emit">Emitir documento</button>
                        <div class="bill-preview-wrap">
                            <div class="bill-preview-menu" id="bill-preview-menu-boleta" hidden role="menu">
                                <button type="button" class="bill-preview-item" role="menuitem" data-preview="pdf">Previsualizar: PDF oficial</button>
                                <button type="button" class="bill-preview-item" role="menuitem" data-preview="thermal50">Previsualizar: Formato térmico 50mm</button>
                                <button type="button" class="bill-preview-item" role="menuitem" data-preview="family">Previsualizar: Carta por familia</button>
                                <button type="button" class="bill-preview-item" role="menuitem" data-preview="product">Previsualizar: Carta por producto</button>
                                <button type="button" class="bill-preview-item" role="menuitem" data-preview="family_detail">Previsualizar: Carta por familia – detalle</button>
                                <button type="button" class="bill-preview-item" role="menuitem" data-preview="product_detail">Previsualizar: Carta por producto – detalle</button>
                            </div>
                            <button type="button" class="bill-btn bill-btn-primary bill-preview-toggle" id="bill-boleta-preview" aria-haspopup="menu" aria-expanded="false" aria-controls="bill-preview-menu-boleta">
                                <svg class="bill-preview-icon" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>
                                <span>Previsualizar</span>
                                <span class="bill-preview-caret" aria-hidden="true">▾</span>
                            </button>
                        </div>
                        <button type="button" class="bill-btn bill-btn-secondary" id="bill-draft-save">Guardar borrador</button>
                    </div>
                </div>
            </div>
        </section>

        <section id="bill-done" class="bill-step" hidden>
            <div class="bill-card bill-card-success">
                <h2 id="bill-done-title">Documento emitido</h2>
                <p id="bill-done-msg"></p>
                <p id="bill-done-folio" class="bill-done-folio"></p>
                <div id="bill-done-pagos" class="bill-done-pagos" hidden>
                    <h3>$ Pagos</h3>
                    <div class="bill-table-wrap">
                        <table class="bill-table">
                            <thead>
                                <tr>
                                    <th>Tipo</th>
                                    <th>Fecha</th>
                                    <th>Tipo</th>
                                    <th>Caja</th>
                                    <th>Doc Num</th>
                                    <th>Doc Tit</th>
                                    <th>Banco Doc</th>
                                    <th>Detalles</th>
                                    <th>Cobro/Pagos</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="bill-done-pagos-body"></tbody>
                        </table>
                    </div>
                    <div class="bill-pagos-totals">
                        <span>Total cobros: <strong id="bill-done-pagos-cobros">$0</strong></span>
                        <span>Total Pagos: <strong id="bill-done-pagos-pagos">$0</strong></span>
                        <span>Monto impago: <strong id="bill-done-pagos-impago">$0</strong></span>
                    </div>
                    <div class="bill-step-actions">
                        <button type="button" class="bill-btn bill-btn-primary" id="bill-done-pago-open">Registrar pago</button>
                    </div>
                </div>
                <div class="bill-step-actions">
                    <a class="bill-btn bill-btn-secondary" id="bill-done-quotes" href="<?php echo esc_url($riverso_billing['quotesUrl'] ?? '#'); ?>">Ir a cotizaciones</a>
                    <button type="button" class="bill-btn bill-btn-primary" id="bill-done-new">Emitir otro</button>
                </div>
            </div>
        </section>
    </div>

    <div id="bill-missing-modal" class="riverso-bill bill-modal-overlay bill-missing-overlay" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="bill-missing-title">
        <div class="bill-modal bill-missing-dialog" role="document">
            <div class="bill-missing-hero">
                <span class="bill-missing-icon" aria-hidden="true">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/>
                        <path d="M12 7.5v5.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                        <circle cx="12" cy="16.2" r="1" fill="currentColor"/>
                    </svg>
                </span>
                <div class="bill-missing-copy">
                    <h3 id="bill-missing-title">Datos incompletos</h3>
                    <p id="bill-missing-msg"></p>
                </div>
            </div>
            <p id="bill-missing-count" class="bill-missing-count" hidden></p>
            <ul id="bill-missing-list" class="bill-missing-list" hidden></ul>
            <div class="bill-modal-footer">
                <button type="button" class="bill-btn bill-btn-primary" id="bill-missing-ok">Entendido</button>
            </div>
        </div>
    </div>

    <div id="bill-draft-delete-modal" class="riverso-bill bill-modal-overlay" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="bill-draft-delete-title" aria-describedby="bill-draft-delete-msg">
        <div class="bill-modal bill-modal-confirm" role="document">
            <div class="bill-modal-header bill-confirm-header">
                <span class="bill-confirm-icon" aria-hidden="true">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                        <path d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span>
                <h3 id="bill-draft-delete-title">BORRAR DOCUMENTO</h3>
            </div>
            <div class="bill-modal-body">
                <p id="bill-draft-delete-msg">¿Está seguro que desea borrar este documento? Esta acción es <strong>PERMANENTE</strong>.</p>
            </div>
            <div class="bill-modal-footer">
                <button type="button" class="bill-btn bill-btn-secondary" id="bill-draft-delete-cancel">Cancelar</button>
                <button type="button" class="bill-btn bill-btn-danger" id="bill-draft-delete-ok">Borrar</button>
            </div>
        </div>
    </div>

    <div id="bill-pago-modal" class="bill-modal-overlay" hidden aria-hidden="true" role="dialog" aria-modal="true">
        <div class="bill-modal bill-modal-lg" role="document">
            <div class="bill-modal-header">
                <h3>Registrar pago</h3>
                <button type="button" class="bill-modal-x" id="bill-pago-close" aria-label="Cerrar">×</button>
            </div>
            <div class="bill-modal-body">
                <div class="bill-grid bill-grid-2">
                    <label class="bill-field">
                        <span>Fecha (*)</span>
                        <input type="date" id="bill-pago-fecha" value="<?php echo esc_attr($riverso_billing['todayDate'] ?? ''); ?>">
                    </label>
                    <label class="bill-field">
                        <span>Caja (*)</span>
                        <select id="bill-pago-caja">
                            <option value="">Cargando cajas…</option>
                        </select>
                    </label>
                    <label class="bill-field">
                        <span>Monto a pagar</span>
                        <input type="text" id="bill-pago-due" readonly>
                    </label>
                    <label class="bill-field">
                        <span>Método de pago (*)</span>
                        <select id="bill-pago-method"></select>
                    </label>
                    <label class="bill-field">
                        <span>Monto pagado (*)</span>
                        <input type="number" id="bill-pago-paid" min="0" step="1" value="">
                    </label>
                    <label class="bill-field">
                        <span>Vuelto</span>
                        <input type="text" id="bill-pago-vuelto" readonly value="0">
                    </label>
                </div>
                <div id="bill-pago-cheque" class="bill-grid bill-grid-3" hidden>
                    <label class="bill-field">
                        <span>Doc Num (*)</span>
                        <input type="text" id="bill-pago-cheque-num">
                    </label>
                    <label class="bill-field">
                        <span>Doc Tit (*)</span>
                        <input type="text" id="bill-pago-cheque-tit">
                    </label>
                    <label class="bill-field">
                        <span>Banco Doc (*)</span>
                        <input type="text" id="bill-pago-cheque-banco">
                    </label>
                </div>
                <label class="bill-field">
                    <span>Observaciones</span>
                    <textarea id="bill-pago-notes" rows="3"></textarea>
                </label>
            </div>
            <div class="bill-modal-footer">
                <button type="button" class="bill-btn bill-btn-danger" id="bill-pago-cancel">Anular</button>
                <button type="button" class="bill-btn bill-btn-primary" id="bill-pago-save">Registrar pago</button>
            </div>
        </div>
    </div>

</div>

<div id="bill-emit-modal" class="riverso-bill bill-modal-overlay bill-emit-overlay" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="bill-emit-title">
    <div class="bill-modal bill-modal-emit" role="document">
        <div class="bill-modal-header">
            <h3 id="bill-emit-title">Emitir documento</h3>
            <button type="button" class="bill-modal-x" id="bill-emit-close" aria-label="Cerrar">×</button>
        </div>
        <div class="bill-modal-body bill-emit-split">
            <div class="bill-emit-col">
                <h4>Emitir y enviar al S.I.I.</h4>
                <label class="bill-field">
                    <span>Certificado digital</span>
                    <select id="bill-emit-cert" disabled>
                        <option value="facto">Certificado configurado en FACTO</option>
                    </select>
                </label>
                <div id="bill-emit-emails"></div>
                <label class="bill-field">
                    <span>Casilla de intercambio del cliente [WIP]</span>
                    <input type="text" disabled placeholder="No disponible">
                </label>
                <label class="bill-check bill-check-wip">
                    <input type="checkbox" disabled>
                    <span>Enlace de pago [WIP]</span>
                </label>
                <label class="bill-check">
                    <input type="checkbox" id="bill-emit-print">
                    <span>Impresión rápida</span>
                </label>
            </div>
            <div class="bill-emit-col">
                <h4>PAGO DE DOCUMENTO</h4>
                <label class="bill-check">
                    <input type="checkbox" id="bill-emit-mark-paid">
                    <span>Marcar como pagado inmediatamente</span>
                </label>
                <label class="bill-check">
                    <input type="checkbox" id="bill-emit-atajo" checked>
                    <span>Atajo</span>
                </label>
                <div id="bill-emit-atajo-fields" class="bill-emit-atajo-fields">
                    <div class="bill-emit-shortcuts" role="group" aria-label="Métodos de cobro rápido">
                        <button type="button" class="bill-btn bill-shortcut-btn is-active" data-shortcut="efectivo">Efectivo</button>
                        <button type="button" class="bill-btn bill-shortcut-btn" data-shortcut="mercado_pago">Mercado Pago</button>
                        <button type="button" class="bill-btn bill-shortcut-btn" data-shortcut="debito">Tarjeta Débito</button>
                        <button type="button" class="bill-btn bill-shortcut-btn" data-shortcut="credito">Tarjeta Crédito</button>
                        <button type="button" class="bill-btn bill-shortcut-btn" data-shortcut="transferencia">Transferencia Bancaria</button>
                    </div>
                    <ul id="bill-emit-cobros" class="bill-emit-cobros" hidden></ul>
                    <div class="bill-emit-monto-row">
                        <label class="bill-field bill-emit-monto-field">
                            <span>Monto</span>
                            <input type="number" id="bill-emit-atajo-monto" min="0" step="1" value="">
                        </label>
                        <button type="button" class="bill-btn bill-btn-primary" id="bill-emit-add-cobro" hidden>Agregar cobro</button>
                    </div>
                    <p id="bill-emit-atajo-hint" class="bill-emit-atajo-hint" role="status"></p>
                </div>
                <div id="bill-emit-pay-fields" class="bill-emit-pay-fields" hidden>
                    <label class="bill-field">
                        <span>Caja (*)</span>
                        <select id="bill-emit-caja"></select>
                    </label>
                    <label class="bill-field">
                        <span>Método de pago (*)</span>
                        <select id="bill-emit-method"></select>
                    </label>
                    <div id="bill-emit-cheque" class="bill-emit-cheque" hidden>
                        <label class="bill-field"><span>Doc Num (*)</span><input type="text" id="bill-emit-cheque-num"></label>
                        <label class="bill-field"><span>Doc Tit (*)</span><input type="text" id="bill-emit-cheque-tit"></label>
                        <label class="bill-field"><span>Banco Doc (*)</span><input type="text" id="bill-emit-cheque-banco"></label>
                    </div>
                    <label class="bill-field">
                        <span>Comentarios</span>
                        <textarea id="bill-emit-notes" rows="3"></textarea>
                    </label>
                </div>
            </div>
        </div>
        <div class="bill-modal-footer bill-emit-footer">
            <button type="button" class="bill-btn bill-btn-success bill-emit-btn-full" id="bill-emit-confirm">Emitir y enviar al S.I.I.</button>
            <button type="button" class="bill-btn bill-btn-danger bill-emit-btn-full" id="bill-emit-close-local">Cerrar y NO enviar al S.I.I.</button>
        </div>
    </div>
</div>

<div id="bill-advanced-modal" class="cq-modal" hidden aria-hidden="true">
    <div class="cq-modal-backdrop" data-bill-adv-close="1"></div>
    <div class="cq-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="bill-adv-title">
        <header class="cq-modal-head">
            <h3 id="bill-adv-title">Búsqueda avanzada</h3>
            <button type="button" class="cq-modal-close" aria-label="Cerrar" data-bill-adv-close="1">×</button>
        </header>
        <div class="cq-modal-body">
            <div class="cq-scope-chips" role="tablist" aria-label="Alcance de búsqueda">
                <button type="button" class="cq-chip is-active" data-scope="todo" role="tab" aria-selected="true">Todo</button>
                <button type="button" class="cq-chip" data-scope="descripcion" role="tab" aria-selected="false">Descripción</button>
                <button type="button" class="cq-chip" data-scope="codigos" role="tab" aria-selected="false">Códigos</button>
            </div>
            <div class="cq-contains-filter">
                <label class="cq-contains-label" for="bill-adv-contains">Contiene palabra:</label>
                <div class="cq-contains-row">
                    <input type="text" id="bill-adv-contains" autocomplete="off" placeholder="Escribe y Enter…" enterkeyhint="done">
                    <button type="button" class="cq-btn" id="bill-adv-contains-add">Agregar</button>
                </div>
                <div id="bill-adv-contains-tags" class="cq-contains-tags" aria-live="polite"></div>
            </div>
            <div class="cq-search-row">
                <input type="search" id="bill-adv-q" autocomplete="off" placeholder="Buscar…" enterkeyhint="search">
                <button type="button" class="cq-btn cq-btn-primary" id="bill-adv-search-btn">Buscar</button>
            </div>
            <p id="bill-adv-hint" class="cq-modal-hint" role="status"></p>
            <ul id="bill-adv-results" class="cq-results cq-modal-results"></ul>
        </div>
    </div>
</div>

<div id="bill-family-modal" class="cq-modal" hidden aria-hidden="true">
    <div class="cq-modal-backdrop" data-bill-family-close="1"></div>
    <div class="cq-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="bill-family-title">
        <header class="cq-modal-head">
            <h3 id="bill-family-title">Cambiar presentación</h3>
            <button type="button" class="cq-modal-close" aria-label="Cerrar" data-bill-family-close="1">×</button>
        </header>
        <div class="cq-modal-body">
            <p id="bill-family-hint" class="cq-modal-hint" role="status"></p>
            <ul id="bill-family-members" class="cq-results cq-modal-results"></ul>
        </div>
        <footer class="cq-modal-foot cq-family-modal-foot">
            <button type="button" class="cq-btn cq-btn-primary" id="bill-family-open-admin" disabled title="Abrir editor de familia en Categorías">
                Abrir Familia
            </button>
        </footer>
    </div>
</div>

<div id="bill-line-modal" class="cq-modal" hidden aria-hidden="true">
    <div class="cq-modal-backdrop" data-bill-line-close="1"></div>
    <div class="cq-modal-dialog cq-line-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="bill-line-title">
        <header class="cq-modal-head">
            <div>
                <h3 id="bill-line-title">Editar línea</h3>
                <p id="bill-line-subtitle" class="cq-line-modal-sub"></p>
            </div>
            <button type="button" class="cq-modal-close" aria-label="Cerrar" data-bill-line-close="1">×</button>
        </header>
        <div class="cq-modal-body cq-line-modal-body">
            <div class="cq-line-tax-toggle" role="group" aria-label="Visualización Neto o Bruto">
                <button type="button" class="cq-tax-btn" id="bill-line-tax-neto" data-tax-view="neto">Neto</button>
                <button type="button" class="cq-tax-btn is-active" id="bill-line-tax-bruto" data-tax-view="bruto">Bruto</button>
            </div>
            <p id="bill-line-family-note" class="cq-modal-hint" hidden></p>
            <div class="cq-line-price-modes" id="bill-line-price-modes">
                <label class="cq-line-mode-check" id="bill-line-mode-manual-wrap">
                    <input type="checkbox" id="bill-line-mode-manual">
                    <span>Precio manual</span>
                </label>
                <div class="cq-line-mode-radios" id="bill-line-mode-radios" hidden>
                    <label><input type="radio" name="bill-line-mode" value="auto"> <span id="bill-line-mode-auto-label">Usar regla</span></label>
                    <label id="bill-line-mode-std-wrap" hidden><input type="radio" name="bill-line-mode" value="std"> <span id="bill-line-mode-std-label">Regla estándar ferretería (R-1)</span></label>
                    <label><input type="radio" name="bill-line-mode" value="rule"> Otra regla</label>
                    <div class="cq-line-rule-picker" id="bill-line-rule-picker" hidden>
                        <div class="cq-line-rule-picker-row">
                            <input type="text" id="bill-line-rule-input" autocomplete="off" placeholder="Buscar regla por código o nombre" aria-label="Buscar regla">
                            <button type="button" class="cq-btn cq-btn-customer-action" id="bill-line-rule-search-btn" title="Buscar reglas" aria-label="Buscar reglas">
                                <span aria-hidden="true">🔍</span>
                            </button>
                        </div>
                        <ul id="bill-line-rule-suggest" class="cq-results cq-rule-results" hidden></ul>
                        <p id="bill-line-rule-chosen" class="cq-modal-hint" role="status"></p>
                    </div>
                    <label><input type="radio" name="bill-line-mode" value="ref"> Cambiar precio de referencia (P)</label>
                    <label><input type="radio" name="bill-line-mode" value="manual"> Ignorar regla — precio final</label>
                </div>
            </div>
            <p id="bill-line-rule-info" class="cq-line-rule-info" hidden></p>
            <div class="cq-line-fields">
                <label class="cq-float-field cq-manual-full" id="bill-line-desc-field">
                    <span>Nombre en documento</span>
                    <input type="text" id="bill-line-desc" maxlength="255" autocomplete="off">
                    <em class="cq-float-hint">Así aparecerá en el PDF y en el documento emitido</em>
                </label>
                <label class="cq-float-field" id="bill-line-qty-field">
                    <span>Cantidad</span>
                    <input type="text" id="bill-line-qty" inputmode="decimal" autocomplete="off">
                    <em id="bill-line-qty-hint" class="cq-float-hint"></em>
                </label>
                <label class="cq-float-field" id="bill-line-pref-field" hidden>
                    <span>Precio de referencia (P)</span>
                    <input type="text" id="bill-line-pref" inputmode="decimal" autocomplete="off">
                    <em id="bill-line-pref-hint" class="cq-float-hint"></em>
                </label>
                <label class="cq-float-field" id="bill-line-unit-field">
                    <span id="bill-line-unit-label">Precio unitario</span>
                    <input type="text" id="bill-line-unit" inputmode="decimal" autocomplete="off">
                    <em id="bill-line-unit-hint" class="cq-float-hint"></em>
                </label>
                <label class="cq-float-field" id="bill-line-total-field">
                    <span id="bill-line-total-label">Precio total</span>
                    <input type="text" id="bill-line-total" inputmode="decimal" autocomplete="off">
                    <em id="bill-line-total-hint" class="cq-float-hint"></em>
                </label>
            </div>
            <details class="cq-discounts" id="bill-line-discounts">
                <summary class="cq-discounts-summary">
                    <span class="cq-discounts-title">Descuentos</span>
                    <span class="cq-discounts-brief" id="bill-line-discounts-brief"></span>
                </summary>
                <div class="cq-discounts-body">
                    <div class="cq-line-fields cq-discounts-ref">
                        <label class="cq-float-field">
                            <span>Costo unitario</span>
                            <input type="text" id="bill-dm-cost" readonly tabindex="-1" autocomplete="off">
                        </label>
                        <label class="cq-float-field">
                            <span>Factor anterior</span>
                            <input type="text" id="bill-dm-factor-before" readonly tabindex="-1" autocomplete="off">
                            <em class="cq-float-hint">Precio de lista / costo</em>
                        </label>
                    </div>
                    <p class="cq-modal-hint cq-discounts-help">Todos son el mismo descuento. El campo que escribes queda <strong>fijado</strong>: si cambia la cantidad o el precio, se mantiene ese valor.</p>
                    <div class="cq-line-fields cq-discounts-fields">
                        <label class="cq-float-field" data-anchor="price_pct">
                            <span>Descuento precio %</span>
                            <input type="text" id="bill-line-price-discount" inputmode="decimal" autocomplete="off">
                        </label>
                        <label class="cq-float-field" data-anchor="margin_pct">
                            <span>Descuento margen %</span>
                            <input type="text" id="bill-line-margin-discount" inputmode="decimal" autocomplete="off">
                            <em class="cq-margin-na-text cq-dm-na" title="Costo no encontrado" hidden>— sin costo</em>
                        </label>
                        <label class="cq-float-field" data-anchor="amount">
                            <span>Monto de descuento</span>
                            <input type="text" id="bill-line-discount-amount" inputmode="decimal" autocomplete="off">
                        </label>
                        <label class="cq-float-field" data-anchor="factor">
                            <span>Factor objetivo</span>
                            <input type="text" id="bill-dm-factor" inputmode="decimal" autocomplete="off">
                            <em class="cq-margin-na-text cq-dm-na" title="Costo no encontrado" hidden>— sin costo</em>
                            <em class="cq-float-hint">Final unitario / costo</em>
                        </label>
                        <label class="cq-float-field" data-anchor="final_unit">
                            <span>Monto final unitario objetivo</span>
                            <input type="text" id="bill-dm-final-unit" inputmode="decimal" autocomplete="off">
                            <em class="cq-float-hint">Por unidad</em>
                        </label>
                        <label class="cq-float-field" data-anchor="final_total">
                            <span>Monto final objetivo</span>
                            <input type="text" id="bill-line-final-amount" inputmode="decimal" autocomplete="off">
                        </label>
                    </div>
                    <p id="bill-line-discount-hint" class="cq-line-preview cq-discounts-status" role="status"></p>
                </div>
            </details>
            <div class="cq-line-by-amount" id="bill-line-by-amount">
                <p class="cq-line-by-amount-row">
                    <strong>Por monto:</strong>
                    Monto $ <input type="text" id="bill-line-monto" class="cq-line-monto-input" inputmode="decimal" autocomplete="off" placeholder="1000">
                    <button type="button" class="cq-btn cq-btn-small" id="bill-line-by-amount-btn">¿Cuánto entregar?</button>
                </p>
                <p class="cq-modal-hint">Total deseado antes de descuentos. Calcula la cantidad a entregar con la regla activa.</p>
                <div id="bill-line-by-amount-result" class="cq-line-by-amount-result"></div>
            </div>
            <p id="bill-line-preview" class="cq-line-preview" role="status"></p>
        </div>
        <footer class="cq-modal-foot cq-line-modal-foot">
            <button type="button" class="cq-btn" data-bill-line-close="1">Cancelar</button>
            <button type="button" class="cq-btn cq-btn-save-line" id="bill-line-save">Guardar cambios</button>
        </footer>
    </div>
</div>

<div id="bill-rule-search-modal" class="cq-modal" hidden aria-hidden="true">
    <div class="cq-modal-backdrop" data-rule-search-close="1"></div>
    <div class="cq-modal-dialog cq-rule-search-dialog" role="dialog" aria-modal="true" aria-labelledby="bill-rule-search-title">
        <header class="cq-modal-head">
            <h3 id="bill-rule-search-title">Buscar regla</h3>
            <button type="button" class="cq-modal-close" aria-label="Cerrar" data-rule-search-close="1">×</button>
        </header>
        <div class="cq-modal-body">
            <label class="cq-field cq-field-wide">
                <span>Código o nombre</span>
                <input type="text" id="bill-rule-search-q" autocomplete="off" placeholder="Ej.: R-3, mayorista">
            </label>
            <p id="bill-rule-search-hint" class="cq-modal-hint" role="status">Reglas aprobadas (última versión de cada código).</p>
            <ul id="bill-rule-search-results" class="cq-results cq-modal-results cq-rule-results"></ul>
        </div>
    </div>
</div>

<div id="bill-manual-modal" class="cq-modal" hidden aria-hidden="true">
    <div class="cq-modal-backdrop" data-bill-manual-close="1"></div>
    <div class="cq-modal-dialog cq-manual-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="bill-manual-title">
        <header class="cq-modal-head">
            <h3 id="bill-manual-title">Agregar detalle</h3>
            <button type="button" class="cq-modal-close" id="bill-manual-close" aria-label="Cerrar" data-bill-manual-close="1">×</button>
        </header>
        <div class="cq-modal-body cq-manual-modal-body">
            <label class="cq-float-field cq-manual-full">
                <span>Afecto a IVA (*)</span>
                <select id="bill-manual-iva" disabled>
                    <option value="si" selected>SI</option>
                </select>
            </label>
            <label class="cq-float-field cq-manual-full">
                <span>Impuesto adicional</span>
                <select id="bill-manual-extra-tax" disabled>
                    <option value="" selected>** Ninguno **</option>
                </select>
            </label>
            <div class="cq-manual-row">
                <label class="cq-float-field">
                    <span>Cantidad (*)</span>
                    <input type="text" id="bill-manual-qty" inputmode="decimal" autocomplete="off" value="1">
                </label>
                <label class="cq-float-field">
                    <span>Unidad</span>
                    <select id="bill-manual-unit">
                        <option value="">** Unidad (opcional) **</option>
                        <option value="Unidad">Unidad</option>
                        <option value="Kg">Kg</option>
                        <option value="Metro">Metro</option>
                        <option value="Hora">Hora</option>
                        <option value="Servicio">Servicio</option>
                        <option value="Caja">Caja</option>
                        <option value="Pack">Pack</option>
                    </select>
                </label>
            </div>
            <div class="cq-manual-row cq-manual-concepto-row">
                <label class="cq-float-field cq-manual-concepto-field">
                    <span>Concepto (*)</span>
                    <input type="text" id="bill-manual-concepto" autocomplete="off" maxlength="500">
                </label>
                <button type="button" class="cq-btn cq-btn-desc-larga" id="bill-manual-desc-toggle" title="Descripción larga" aria-expanded="false" aria-controls="bill-manual-desc-wrap">Desc. Larga</button>
            </div>
            <div id="bill-manual-desc-wrap" class="cq-manual-desc-wrap" hidden>
                <label class="cq-float-field cq-manual-full">
                    <span>Descripción larga</span>
                    <textarea id="bill-manual-desc-larga" rows="3" maxlength="500"></textarea>
                </label>
            </div>
            <label class="cq-float-field cq-manual-full">
                <span>Precio unitario</span>
                <input type="text" id="bill-manual-unit-neto" inputmode="decimal" autocomplete="off" value="0">
            </label>
            <label class="cq-float-field cq-manual-full">
                <span>Precio unitario con impuestos</span>
                <input type="text" id="bill-manual-unit-bruto" inputmode="decimal" autocomplete="off" value="0">
            </label>
            <div class="cq-manual-row">
                <label class="cq-float-field">
                    <span>Descuento/Recargo</span>
                    <select id="bill-manual-adj-type">
                        <option value="descuento" selected>Descuento</option>
                        <option value="recargo">Recargo</option>
                    </select>
                </label>
                <label class="cq-float-field cq-manual-pct-field">
                    <span>Porcentaje</span>
                    <div class="cq-manual-pct-wrap">
                        <input type="text" id="bill-manual-pct" inputmode="decimal" autocomplete="off" value="0">
                        <span class="cq-manual-pct-suffix" aria-hidden="true">%</span>
                    </div>
                </label>
            </div>
            <label class="cq-float-field cq-manual-full">
                <span>Precio total</span>
                <input type="text" id="bill-manual-total-neto" inputmode="decimal" autocomplete="off" value="0" readonly>
            </label>
            <label class="cq-float-field cq-manual-full">
                <span>Precio total con impuestos</span>
                <input type="text" id="bill-manual-total-bruto" inputmode="decimal" autocomplete="off" value="0" readonly>
            </label>
            <p id="bill-manual-hint" class="cq-modal-hint" role="status"></p>
        </div>
        <footer class="cq-modal-foot cq-manual-modal-foot">
            <button type="button" class="cq-btn cq-btn-manual-add" id="bill-manual-add">Agregar</button>
        </footer>
    </div>
</div>

<script>
window.RIVERSO_BILLING = <?php echo riverso_pos_billing_json($riverso_billing); ?>;
</script>
<script src="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/js/barcode-scanner.js?ver=<?php echo htmlspecialchars($scanner_js_ver, ENT_QUOTES, 'UTF-8'); ?>"></script>
<script src="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/js/line-discounts.js?ver=<?php echo htmlspecialchars($line_discounts_ver, ENT_QUOTES, 'UTF-8'); ?>"></script>
<script src="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/js/billing-lines.js?ver=<?php echo htmlspecialchars($js_lines_ver, ENT_QUOTES, 'UTF-8'); ?>"></script>
<script src="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/js/billing-emails.js?ver=<?php echo htmlspecialchars($js_emails_ver, ENT_QUOTES, 'UTF-8'); ?>"></script>
<script src="<?php echo htmlspecialchars($asset_base, ENT_QUOTES, 'UTF-8'); ?>/js/billing.js?ver=<?php echo htmlspecialchars($js_ver, ENT_QUOTES, 'UTF-8'); ?>"></script>
