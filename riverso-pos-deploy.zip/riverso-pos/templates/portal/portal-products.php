<?php
/**
 * Sección de Productos del Portal Interno
 * Incluida desde portal-main.php
 */

if (!defined('ABSPATH')) {
    exit;
}

// Verificar permisos
if (!current_user_can('riverso_view_products')) {
    echo '<div style="padding:20px; color:#d32f2f;">Sin permisos para acceder a esta sección</div>';
    return;
}

$can_manage = current_user_can('riverso_manage_products');
$can_manage_categories = current_user_can('riverso_manage_categories');
$can_manage_families = current_user_can('riverso_manage_families');
?>

<div class="portal-products-section">
    <style>
        .portal-products-section { max-width: 1400px; margin: 0 auto; }
        .products-toolbar { display: flex; gap: 10px; margin-bottom: 15px; flex-wrap: wrap; align-items: center; }
        .products-toolbar select, .products-toolbar input { padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        .products-table { width: 100%; border-collapse: collapse; background: white; border-radius: 4px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .products-table thead { background: #f5f5f5; font-weight: bold; }
        .products-table th, .products-table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        .products-table tr:hover { background: #fafafa; }
        .btn-small { padding: 6px 10px; background: #2196f3; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; }
        .btn-small:hover { background: #1976d2; }
        #product-detail-panel { display: none; margin-top: 20px; background: white; padding: 20px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .product-detail-tabs { display: flex; gap: 10px; border-bottom: 2px solid #eee; margin-bottom: 15px; }
        .product-detail-tabs a { padding: 10px 15px; cursor: pointer; border-bottom: 3px solid transparent; text-decoration: none; color: #666; }
        .product-detail-tabs a.active { border-bottom-color: #2196f3; color: #2196f3; font-weight: bold; }
        .product-tab-content { display: none; }
        .product-tab-content.active { display: block; }
        .form-row { margin-bottom: 15px; }
        .form-row label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 13px; }
        .form-row input, .form-row select, .form-row textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-family: inherit; }
        .alert { padding: 12px; border-radius: 4px; margin-bottom: 15px; }
        .alert-warning { background: #fff3cd; color: #856404; border: 1px solid #ffc107; }
    </style>

    <div style="margin-bottom: 20px;">
        <h2 style="margin: 0 0 15px 0;">Productos</h2>
        
        <div class="products-toolbar">
            <select id="products-status">
                <option value="active">Estado: Activos</option>
                <option value="archived">Estado: Archivados</option>
            </select>
            <input type="text" id="products-search" placeholder="Buscar por SKU, nombre o código..." style="flex: 1; min-width: 200px;">
            <?php if ($can_manage): ?>
            <button class="btn-small" id="btn-new-product">+ Nuevo Producto</button>
            <?php endif; ?>
            <button class="btn-small" id="btn-reload-products" style="background: #666;">🔄 Actualizar</button>
        </div>

        <div id="products-list">
            <p style="color: #999; text-align: center; padding: 20px;">Cargando productos...</p>
        </div>
    </div>

    <div id="product-detail-panel">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h3 id="detail-title" style="margin: 0;">Detalle del Producto</h3>
            <div style="display: flex; gap: 8px;">
                <?php if ($can_manage): ?>
                <button class="btn-small" id="btn-detail-edit" style="display: none;">✎ Editar</button>
                <button class="btn-small" id="btn-detail-save" style="display: none; background: #28a745;">✓ Guardar</button>
                <button class="btn-small" id="btn-detail-cancel" style="display: none; background: #d32f2f;">✕ Cancelar</button>
                <?php endif; ?>
                <button class="btn-small" id="btn-detail-close" style="background: #999;">✕ Cerrar</button>
            </div>
        </div>

        <div class="product-detail-tabs">
            <a class="active" data-tab="local">Local</a>
            <a data-tab="online">Online</a>
            <a data-tab="codes">Códigos</a>
            <a data-tab="barcodes">Barcodes</a>
            <a data-tab="tasks">Tareas</a>
            <?php if ($can_manage_families): ?>
            <a data-tab="families">Familias</a>
            <?php endif; ?>
        </div>

        <!-- TAB: LOCAL -->
        <div class="product-tab-content active" data-tab-content="local">
            <div class="form-row">
                <label>SKU Local</label>
                <input type="text" id="detail-sku" readonly>
            </div>
            <div class="form-row">
                <label>Nombre</label>
                <input type="text" id="detail-name" readonly>
            </div>
            <div class="form-row">
                <label>Unidad Base</label>
                <input type="text" id="detail-unit" readonly>
            </div>
            <div class="form-row">
                <label>Familia</label>
                <div id="detail-family" style="padding: 8px; background: #f5f5f5; border-radius: 3px;">-</div>
            </div>
        </div>

        <!-- TAB: ONLINE -->
        <div class="product-tab-content" data-tab-content="online">
            <div class="form-row">
                <label>ID WooCommerce</label>
                <input type="text" id="detail-woo-id" readonly>
            </div>
            <div class="form-row">
                <label>Estado de Matching</label>
                <input type="text" id="detail-match-estado" readonly>
            </div>
            <div id="detail-online-details">
                <p style="color: #999; text-align: center; padding: 20px;">Sin producto WooCommerce asociado</p>
            </div>
        </div>

        <!-- TAB: CÓDIGOS -->
        <div class="product-tab-content" data-tab-content="codes">
            <div id="detail-codes">
                <p style="color: #999; text-align: center; padding: 20px;">Cargando códigos...</p>
            </div>
        </div>

        <!-- TAB: BARCODES -->
        <div class="product-tab-content" data-tab-content="barcodes">
            <div id="detail-barcodes">
                <p style="color: #999; text-align: center; padding: 20px;">Cargando barcodes...</p>
            </div>
        </div>

        <!-- TAB: TAREAS -->
        <div class="product-tab-content" data-tab-content="tasks">
            <div id="detail-tasks">
                <p style="color: #999; text-align: center; padding: 20px;">Cargando tareas...</p>
            </div>
        </div>

        <!-- TAB: FAMILIAS -->
        <?php if ($can_manage_families): ?>
        <div class="product-tab-content" data-tab-content="families">
            <div id="detail-families">
                <p style="color: #999; text-align: center; padding: 20px;">Cargando familias...</p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
jQuery(function($) {
    const nonce = '<?php echo esc_js($nonce); ?>';
    const ajaxUrl = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
    const canManage = <?php echo $can_manage ? 'true' : 'false'; ?>;
    const canManageCategories = <?php echo $can_manage_categories ? 'true' : 'false'; ?>;
    const canManageFamilies = <?php echo $can_manage_families ? 'true' : 'false'; ?>;
    
    let currentProduct = null;
    let currentOffset = 0;
    const LIMIT = 20;

    function esc(v) { return $('<div>').text(v === null || v === undefined ? '' : v).html(); }

    function post(action, data) {
        return $.post(ajaxUrl, { action, nonce, ...data });
    }

    function loadProducts(offset = 0) {
        const status = $('#products-status').val();
        const search = $('#products-search').val();

        post('riverso_products_list', {
            offset: offset || 0,
            limit: LIMIT,
            status: status,
            search: search || ''
        }).done(function(r) {
            if (!r.success) {
                $('#products-list').html('<div style="color: #d32f2f; padding: 20px;">Error: ' + esc(r.data.message) + '</div>');
                return;
            }

            const products = r.data.items || [];
            let html = '<table class="products-table"><thead><tr><th>SKU Local</th><th>Nombre</th><th>Completitud</th><th>Acciones</th></tr></thead><tbody>';
            
            if (products.length === 0) {
                html += '<tr><td colspan="4" style="text-align: center; color: #999;">No hay productos</td></tr>';
            } else {
                products.forEach(p => {
                    html += '<tr><td>' + esc(p.canonical_sku || '-') + '</td><td>' + esc(p.nombre_canonico || '-') + '</td><td>' + esc(p.completitud || '-') + '</td><td><button class="btn-small" onclick="window.portalProducts.openDetail(' + p.id + ')">Ver</button></td></tr>';
                });
            }
            
            html += '</tbody></table>';
            $('#products-list').html(html);
            currentOffset = offset || 0;
        });
    }

    function openDetail(productId) {
        post('riverso_products_get', { producto_id: productId }).done(function(r) {
            if (!r.success) {
                alert('Error: ' + r.data.message);
                return;
            }
            currentProduct = r.data.product;
            renderDetail();
            $('#product-detail-panel').show();
        });
    }

    function renderDetail() {
        const p = currentProduct;
        $('#detail-title').text('Detalle: ' + (p.nombre_canonico || p.canonical_sku || 'Sin nombre'));
        $('#detail-sku').val(p.canonical_sku || '');
        $('#detail-name').val(p.nombre_canonico || '');
        $('#detail-unit').val(p.unidad_base || '');
        $('#detail-family').html(p.familia ? esc(p.familia.nombre) : '<em style="color: #999;">Sin familia</em>');
        $('#detail-woo-id').val(p.woocommerce_product_id || '-');
        $('#detail-match-estado').val(p.match_estado_online || 'UNMATCHED');

        // Tasks
        const tasks = (p.tasks || []).filter(t => t.estado !== 'completada');
        let tasksHtml = tasks.length ? '<ul style="margin: 0; padding-left: 20px;">' + tasks.map(t => '<li style="margin: 8px 0;">' + esc(t.titulo) + ' <small style="color: #999;">(' + esc(t.tipo) + ')</small></li>').join('') + '</ul>' : '<p style="color: #999;">Sin tareas pendientes</p>';
        $('#detail-tasks').html(tasksHtml);

        // Barcodes (placeholder)
        $('#detail-barcodes').html('<p style="color: #999;">Ver en wp-admin para gestionar barcodes</p>');

        // Codes (placeholder)
        $('#detail-codes').html('<p style="color: #999;">Ver en wp-admin para gestionar códigos</p>');

        if (canManageFamilies) {
            $('#detail-families').html('<p style="color: #999;">Ver en wp-admin para gestionar familias</p>');
        }

        if (p.woocommerce_product_id) {
            $('#detail-online-details').html('<p style="color: #999;">Ver en wp-admin para detalles online</p>');
        }
    }

    // Event listeners
    $('#products-status').change(() => loadProducts(0));
    $('#products-search').on('input', () => loadProducts(0));
    $('#btn-reload-products').click(() => loadProducts(0));
    
    $('.product-detail-tabs a').click(function(e) {
        e.preventDefault();
        const tab = $(this).data('tab');
        $('.product-detail-tabs a').removeClass('active');
        $(this).addClass('active');
        $('.product-tab-content').removeClass('active');
        $('.product-tab-content[data-tab-content="' + tab + '"]').addClass('active');
    });

    $('#btn-detail-close').click(() => {
        $('#product-detail-panel').hide();
        currentProduct = null;
    });

    // Expose globally for inline onclick
    window.portalProducts = {
        openDetail: openDetail
    };

    // Initial load
    loadProducts(0);
});
</script>
