<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Riverso - Portal Interno</title>
    <?php wp_head(); ?>
    <style>
        :root {
            --primary: #1976d2;
            --primary-dark: #1565c0;
            --secondary: #424242;
            --success: #4caf50;
            --warning: #ff9800;
            --danger: #f44336;
            --bg-light: #f5f5f5;
            --bg-white: #ffffff;
            --text-primary: #212121;
            --text-secondary: #757575;
            --border: #e0e0e0;
            --sidebar-width: 240px;
        }
        
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-light);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        /* Layout */
        .portal-wrapper {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .portal-sidebar {
            width: var(--sidebar-width);
            background: var(--secondary);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }
        
        .sidebar-header {
            padding: 20px;
            background: rgba(0,0,0,0.2);
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .sidebar-logo {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
        }
        
        .sidebar-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        .sidebar-subtitle {
            font-size: 12px;
            opacity: 0.7;
        }
        
        .sidebar-nav {
            padding: 15px 0;
        }
        
        .nav-section {
            padding: 10px 20px 5px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            opacity: 0.5;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.2s;
            cursor: pointer;
        }
        
        .nav-item:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .nav-item.active {
            background: var(--primary);
            color: white;
        }
        
        .nav-item .dashicons {
            font-size: 20px;
            width: 20px;
            height: 20px;
        }
        
        .sidebar-footer {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 15px 20px;
            background: rgba(0,0,0,0.2);
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .user-avatar {
            width: 36px;
            height: 36px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .user-name {
            font-size: 14px;
            font-weight: 500;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.7;
        }
        
        .btn-logout {
            display: block;
            width: 100%;
            padding: 8px;
            background: rgba(255,255,255,0.1);
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 4px;
            font-size: 13px;
            text-align: center;
            text-decoration: none;
        }
        
        .btn-logout:hover {
            background: rgba(255,255,255,0.2);
        }
        
        /* Main Content */
        .portal-main {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 30px;
        }
        
        /* Header */
        .portal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 28px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
        
        /* Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .stat-card .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }
        
        .stat-card .stat-icon.blue { background: #e3f2fd; color: #1976d2; }
        .stat-card .stat-icon.green { background: #e8f5e9; color: #4caf50; }
        .stat-card .stat-icon.orange { background: #fff3e0; color: #ff9800; }
        .stat-card .stat-icon.purple { background: #f3e5f5; color: #9c27b0; }
        
        .stat-card .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1;
        }
        
        .stat-card .stat-label {
            font-size: 14px;
            color: var(--text-secondary);
            margin-top: 5px;
        }
        
        /* Content Sections */
        .content-section {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .section-header {
            padding: 20px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        .section-body {
            padding: 20px;
        }
        
        /* Tasks List */
        .task-item {
            display: flex;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid var(--border);
        }
        
        .task-item:last-child {
            border-bottom: none;
        }
        
        .task-priority {
            width: 4px;
            height: 40px;
            border-radius: 2px;
            margin-right: 15px;
        }
        
        .task-priority.urgente { background: #f44336; }
        .task-priority.alta { background: #ff9800; }
        .task-priority.normal { background: #2196f3; }
        .task-priority.baja { background: #9e9e9e; }
        
        .task-content {
            flex: 1;
        }
        
        .task-title {
            font-weight: 500;
            margin-bottom: 3px;
        }
        
        .task-meta {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .task-actions {
            display: flex;
            gap: 8px;
        }
        
        /* Buttons */
        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
        }
        
        .btn-secondary {
            background: var(--bg-light);
            color: var(--text-primary);
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        
        .quick-action {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background: var(--bg-light);
            border-radius: 8px;
            text-decoration: none;
            color: var(--text-primary);
            transition: all 0.2s;
        }
        
        .quick-action:hover {
            background: var(--primary);
            color: white;
        }
        
        .quick-action .dashicons {
            font-size: 32px;
            width: 32px;
            height: 32px;
            margin-bottom: 10px;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }
        
        .empty-state .dashicons {
            font-size: 48px;
            width: 48px;
            height: 48px;
            opacity: 0.5;
            margin-bottom: 10px;
        }
        
        /* Loading */
        .loading {
            text-align: center;
            padding: 60px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .portal-sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .portal-main {
                margin-left: 0;
            }
            
            .sidebar-footer {
                position: relative;
            }
        }
    </style>
</head>
<body>
<?php
// Obtener datos del usuario
$user = wp_get_current_user();
$user_role = Riverso_POS_Permissions::get_riverso_role();
$role_name = Riverso_POS_Permissions::ROLES[$user_role]['name'] ?? ($user_role === 'administrator' ? 'Administrador' : 'Usuario');
$modules = Riverso_POS_Permissions::get_accessible_modules();
$current_page = get_query_var('riverso_portal', 'dashboard');
$nonce = wp_create_nonce('riverso_pos_nonce');

// Obtener estadísticas
global $wpdb;
$prefix = $wpdb->prefix . 'riverso_';
$user_id = get_current_user_id();

$stats = [
    'tareas_pendientes' => $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$prefix}tareas WHERE (asignado_a = %d OR asignado_a IS NULL) AND estado NOT IN ('completada', 'cancelada')",
        $user_id
    )) ?? 0,
    'tareas_hoy' => $wpdb->get_var(
        "SELECT COUNT(*) FROM {$prefix}tareas WHERE completado_en >= CURDATE() AND estado = 'completada'"
    ) ?? 0,
];

if (current_user_can('riverso_view_invoices')) {
    $stats['facturas_pendientes'] = $wpdb->get_var("SELECT COUNT(*) FROM {$prefix}facturas WHERE estado = 'pendiente'") ?? 0;
}

if (current_user_can('riverso_view_warehouse')) {
    $stats['ubicaciones_activas'] = $wpdb->get_var("SELECT COUNT(*) FROM {$prefix}ubicaciones WHERE activo = 1") ?? 0;
}

// Obtener tareas pendientes
$tareas = $wpdb->get_results($wpdb->prepare(
    "SELECT t.*, u.display_name as creador_nombre FROM {$prefix}tareas t
     LEFT JOIN {$wpdb->users} u ON t.creado_por = u.ID
     WHERE (t.asignado_a = %d OR t.asignado_a IS NULL) AND t.estado NOT IN ('completada', 'cancelada')
     ORDER BY FIELD(t.prioridad, 'urgente', 'alta', 'normal', 'baja'), t.created_at DESC LIMIT 5",
    $user_id
), ARRAY_A) ?? [];
?>

<div class="portal-wrapper">
    <!-- Sidebar -->
    <aside class="portal-sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">R</div>
            <div>
                <div class="sidebar-title">Riverso</div>
                <div class="sidebar-subtitle">Portal Interno</div>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <div class="nav-section">Menú</div>
            
            <?php foreach ($modules as $key => $module): ?>
            <a href="<?php echo home_url('/interno/' . $key . '/'); ?>" 
               class="nav-item <?php echo $current_page === $key ? 'active' : ''; ?>">
                <span class="dashicons dashicons-<?php echo esc_attr($module['icon']); ?>"></span>
                <?php echo esc_html($module['label']); ?>
            </a>
            <?php endforeach; ?>
            
            <div class="nav-section" style="margin-top: 20px;">WordPress</div>
            <a href="<?php echo admin_url(); ?>" class="nav-item" target="_blank">
                <span class="dashicons dashicons-admin-generic"></span>
                Ir a WP Admin
            </a>
        </nav>
        
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($user->display_name, 0, 1)); ?></div>
                <div>
                    <div class="user-name"><?php echo esc_html($user->display_name); ?></div>
                    <div class="user-role"><?php echo esc_html($role_name); ?></div>
                </div>
            </div>
            <a href="<?php echo wp_logout_url(home_url()); ?>" class="btn-logout">
                <span class="dashicons dashicons-exit" style="font-size: 16px; vertical-align: middle;"></span>
                Cerrar Sesión
            </a>
        </div>
    </aside>
    
    <!-- Main Content -->
    <main class="portal-main">
        <div class="portal-header">
            <h1 class="page-title">
                <?php
                switch ($current_page) {
                    case 'dashboard': echo 'Dashboard'; break;
                    case 'tasks': echo 'Mis Tareas'; break;
                    case 'warehouse': echo 'Bodega'; break;
                    case 'invoices': echo 'Facturas'; break;
                    case 'pos': echo 'Punto de Venta'; break;
                    case 'quotes': echo 'Cotizaciones'; break;
                    default: echo 'Dashboard';
                }
                ?>
            </h1>
            <div class="header-actions">
                <span style="color: var(--text-secondary); font-size: 14px;">
                    <?php echo date_i18n('l, j \d\e F Y'); ?>
                </span>
            </div>
        </div>
        
        <?php if ($current_page === 'dashboard'): ?>
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <span class="dashicons dashicons-clipboard"></span>
                </div>
                <div class="stat-value"><?php echo intval($stats['tareas_pendientes']); ?></div>
                <div class="stat-label">Tareas Pendientes</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon green">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <div class="stat-value"><?php echo intval($stats['tareas_hoy']); ?></div>
                <div class="stat-label">Completadas Hoy</div>
            </div>
            
            <?php if (isset($stats['facturas_pendientes'])): ?>
            <div class="stat-card">
                <div class="stat-icon orange">
                    <span class="dashicons dashicons-media-spreadsheet"></span>
                </div>
                <div class="stat-value"><?php echo intval($stats['facturas_pendientes']); ?></div>
                <div class="stat-label">Facturas Pendientes</div>
            </div>
            <?php endif; ?>
            
            <?php if (isset($stats['ubicaciones_activas'])): ?>
            <div class="stat-card">
                <div class="stat-icon purple">
                    <span class="dashicons dashicons-store"></span>
                </div>
                <div class="stat-value"><?php echo intval($stats['ubicaciones_activas']); ?></div>
                <div class="stat-label">Ubicaciones Activas</div>
            </div>
            <?php endif; ?>
        </div>
        
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
            <!-- Tareas Pendientes -->
            <div class="content-section">
                <div class="section-header">
                    <h2 class="section-title">Tareas Pendientes</h2>
                    <a href="<?php echo home_url('/interno/tasks/'); ?>" class="btn btn-secondary btn-sm">Ver todas</a>
                </div>
                <div class="section-body">
                    <?php if (empty($tareas)): ?>
                    <div class="empty-state">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <p>No tienes tareas pendientes</p>
                    </div>
                    <?php else: ?>
                        <?php foreach ($tareas as $tarea): ?>
                        <div class="task-item">
                            <div class="task-priority <?php echo esc_attr($tarea['prioridad']); ?>"></div>
                            <div class="task-content">
                                <div class="task-title"><?php echo esc_html($tarea['titulo']); ?></div>
                                <div class="task-meta">
                                    <?php echo esc_html($tarea['tipo']); ?> 
                                    • <?php echo date_i18n('j M', strtotime($tarea['created_at'])); ?>
                                    <?php if ($tarea['fecha_limite']): ?>
                                        • Límite: <?php echo date_i18n('j M', strtotime($tarea['fecha_limite'])); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="task-actions">
                                <button class="btn btn-primary btn-sm" onclick="alert('TODO: Completar tarea')">
                                    Completar
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Accesos Rápidos -->
            <div class="content-section">
                <div class="section-header">
                    <h2 class="section-title">Accesos Rápidos</h2>
                </div>
                <div class="section-body">
                    <div class="quick-actions">
                        <?php if (current_user_can('riverso_use_pos')): ?>
                        <a href="<?php echo home_url('/interno/pos/'); ?>" class="quick-action">
                            <span class="dashicons dashicons-cart"></span>
                            <span>Nueva Venta</span>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (current_user_can('riverso_create_tasks')): ?>
                        <a href="<?php echo admin_url('admin.php?page=riverso-tasks'); ?>" class="quick-action">
                            <span class="dashicons dashicons-plus-alt"></span>
                            <span>Nueva Tarea</span>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (current_user_can('riverso_view_invoices')): ?>
                        <a href="<?php echo admin_url('admin.php?page=riverso-invoices'); ?>" class="quick-action">
                            <span class="dashicons dashicons-upload"></span>
                            <span>Subir Factura</span>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (current_user_can('riverso_view_warehouse')): ?>
                        <a href="<?php echo admin_url('admin.php?page=riverso-warehouse'); ?>" class="quick-action">
                            <span class="dashicons dashicons-store"></span>
                            <span>Ver Bodega</span>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <?php else: ?>
        <!-- Página en construcción -->
        <div class="content-section">
            <div class="section-body">
                <div class="empty-state">
                    <span class="dashicons dashicons-hammer"></span>
                    <h3>Módulo en Construcción</h3>
                    <p>Esta sección estará disponible pronto.</p>
                    <p style="margin-top: 15px;">
                        <a href="<?php echo admin_url('admin.php?page=riverso-' . $current_page); ?>" class="btn btn-primary">
                            Ir a WP Admin
                        </a>
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>

<?php wp_footer(); ?>
</body>
</html>
